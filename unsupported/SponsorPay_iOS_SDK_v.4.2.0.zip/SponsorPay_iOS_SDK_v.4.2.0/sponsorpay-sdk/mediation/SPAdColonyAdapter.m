//
//  SPAdColonyAdapter.m
//  SponsorPay iOS SDK
//
//  Created by David Davila on 5/17/13.
//  Copyright (c) 2013 SponsorPay. All rights reserved.
//

#import "SPAdColonyAdapter.h"
#import "SPLogger.h"

@interface SPAdColonyAdapter()

@property (retain) NSString *appId;
@property (retain) NSString *zoneId;
@property (retain) NSString *secretKey;

@property (assign) SPTPNValidationResult validationResult;
@property (assign) BOOL adColonySDKInitialized;
@property (assign) SPTPNProviderPlayingState playingState;

@property (copy) SPTPNVideoEventsHandlerBlock videoEventsCallback;

@end

@implementation SPAdColonyAdapter

- (id)initWithAppId:(NSString *)appId
             zoneId:(NSString *)zoneId
          secretKey:(NSString *)secretKey
{
    self = [super init];

    if (self) {
        self.appId = appId;
        self.zoneId = zoneId;
        self.secretKey = secretKey;
    }

    return self;
}

- (NSString *)providerName
{
    return @"adcolony";
}

- (void)startProvider
{
#ifdef SPAdColonySDKAvailable_2_0_1_33

    if (!self.adColonySDKInitialized) {

        [SPLogger log:@"Initializing AdColony SDK"];

        [AdColony initAdColonyWithDelegate:self];
        self.adColonySDKInitialized = YES;
    }
#endif
}

- (void)videosAvailable:(SPTPNValidationResultBlock)callback
{
    callback(self.providerName, self.validationResult);
}

- (void)playVideoWithParentViewController:(UIViewController *) parentVC
                        notifyingCallback:(SPTPNVideoEventsHandlerBlock)eventsCallback
{
#ifdef SPAdColonySDKAvailable_2_0_1_33

    self.videoEventsCallback = eventsCallback;

    [AdColony playVideoAdForZone:self.zoneId
                    withDelegate:self
                withV4VCPrePopup:NO
                andV4VCPostPopup:NO];

    self.playingState = SPTPNProviderPlayingStateWaitingForPlayStart;
    [self startTimeoutChecker];
#endif
}

- (void)startTimeoutChecker
{
#ifdef SPAdColonySDKAvailable_2_0_1_33
    void(^timeoutBlock)(void) = ^(void) {
        if (self.playingState == SPTPNProviderPlayingStateWaitingForPlayStart) {
            [AdColony cancelAd];
            self.playingState = SPTPNProviderPlayingStateNotPlaying;
        }
    };

    double delayInSeconds = SPTPNTimeoutInterval;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), timeoutBlock);
#endif
}


#pragma mark - AdColonyDelegate protocol implementation

- (NSString*)adColonyApplicationID
{
    return self.appId;
}

- (NSDictionary*)adColonyAdZoneNumberAssociation
{
    return [NSDictionary dictionaryWithObjectsAndKeys:
            self.zoneId, [NSNumber numberWithInt:1],
            nil];
}

- (void)adColonyNoVideoFillInZone:(NSString *)zone
{
    if ([zone isEqualToString:self.zoneId])
        self.validationResult = SPTPNValidationNoVideoAvailable;
}

- (void)adColonyVideoAdsNotReadyInZone:(NSString *)zone
{
    if ([zone isEqualToString:self.zoneId])
        self.validationResult = SPTPNValidationNoVideoAvailable;
}

- (void)adColonyVideoAdsReadyInZone:(NSString *)zone
{
    if ([zone isEqualToString:self.zoneId])
        self.validationResult = SPTPNValidationSuccess;
}

#pragma mark - AdColonyTakeoverAdDelegate protocol implementation

- (void)adColonyTakeoverBeganForZone:(NSString *)zone
{
    [SPLogger log:@"%s", __PRETTY_FUNCTION__];
    //Should implement any app-specific code that should be run when an ad that takes over the screen begins
    //(for example, pausing a game if a video ad is being served in the middle of a session).
    self.playingState = SPTPNProviderPlayingStatePlaying;
    self.videoEventsCallback(self.providerName, SPTPNVideoEventStarted);
}

- (void)adColonyTakeoverEndedForZone:(NSString *)zone withVC:(BOOL)withVirtualCurrencyAward
{
    [SPLogger log:@"%s withVirtualCurrencyAward:%d", __PRETTY_FUNCTION__, withVirtualCurrencyAward];
    //Should implement any app-specific code that should be run when an ad that takes over the screen ends
    //(for example, resuming a game if a video ad was served in the middle of a session).

    self.playingState = SPTPNProviderPlayingStateNotPlaying;

    if (withVirtualCurrencyAward) {
        self.videoEventsCallback(self.providerName, SPTPNVideoEventFinished);
        self.videoEventsCallback(self.providerName, SPTPNVideoEventClosed);
    } else {
        self.videoEventsCallback(self.providerName, SPTPNVideoEventAborted);
    }
}

- (void)adColonyVideoAdNotServedForZone:(NSString *)zone
{
    [SPLogger log:@"%s", __PRETTY_FUNCTION__];
    //Should implement any app-specific code that should be run when AdColony is unable to play a video ad
    //or virtual currency video ad

    self.playingState = SPTPNProviderPlayingStateNotPlaying;

    self.videoEventsCallback(self.providerName, SPTPNVideoEventNoVideo);
}

@end
