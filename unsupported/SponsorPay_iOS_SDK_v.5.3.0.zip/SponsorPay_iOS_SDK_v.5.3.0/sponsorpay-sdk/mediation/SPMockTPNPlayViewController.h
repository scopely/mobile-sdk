//
//  MockTPNPlayViewController.h
//  SponsorPay iOS SDK
//
//  Created by David Davila on 6/14/13.
// Copyright 2011-2013 SponsorPay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SPMockTPNPlayViewController : UIViewController

@end
