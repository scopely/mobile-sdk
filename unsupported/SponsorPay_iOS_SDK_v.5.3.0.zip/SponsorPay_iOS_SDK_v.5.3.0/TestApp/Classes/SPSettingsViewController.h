//
//  SPSettingsViewController.h
//  SponsorPay Sample App
//
//  Created by David on 9/14/12.
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SPUrlUtil.h"

@interface SPSettingsViewController : UIViewController <UITextFieldDelegate, UITableViewDataSource, UITableViewDelegate> {

//    SPCustomParamsUtil *additionalParameters;
    
    UITextField *keyTextField;
    UITextField *valueTextField;
    
    UITableView *paramsTableView;
    
    UITextField *urlOverriderTextField;
    UISwitch *overrideSwitch;
}

//@property (assign) SPCustomParamsUtil *additionalParameters;

@property (strong) IBOutlet UITextField *keyTextField;
@property (strong) IBOutlet UITextField *valueTextField;
@property (strong) IBOutlet UITableView *paramsTableView;
@property (strong) IBOutlet UITextField *urlOverriderTextField;
@property (strong) IBOutlet UISwitch *overrideSwitch;

-(IBAction)doneButtonTapped:(id)sender;
-(IBAction)addButtonTapped:(id)sender;
-(IBAction)textFieldReturn:(id)sender;
-(IBAction)urlOverriderSwitchValueChanged:(UISwitch *)sender;
-(IBAction)urlOverrideTextFiledChanged:(UITextField *)sender;

@end
