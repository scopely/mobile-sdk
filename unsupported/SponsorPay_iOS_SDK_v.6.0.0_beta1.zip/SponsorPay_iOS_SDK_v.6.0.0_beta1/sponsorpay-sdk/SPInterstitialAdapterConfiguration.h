//
//  SPInterstitialAdapterConfiguration.h
//  SponsorPay iOS SDK
//
//  Copyright (c) 2013 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>

/** Encloses the name of an SDK-wrapping interstitial adapter class and the configuration parameters and credentials used to start it.
 */
@interface SPInterstitialAdapterConfiguration : NSObject

/**
 Name of the Objective-C class corresponding to the interstitial adapter.
 */
@property (readonly, strong, nonatomic) NSString *adapterClassName;

/**
 Parameters and credentials that will be used to configure the interstitial adapter.
 */
@property (readonly, strong, nonatomic) NSDictionary *parameters;


/**
 Returns an instance configured with the provided adapter class name and parameters.
 */
+ (instancetype)configurationWithAdapterName:(NSString *)name parameters:(NSDictionary *)parameters;

/**
 Initializes an instance configured with the provided adapter class name and parameters.
*/
- (instancetype)initWithAdapterName:(NSString *)name parameters:(NSDictionary *)parameters;

/**
 Attempts to extract an array of SPInterstitialAdapterConfiguration instances from the application bundle's plist file.
 */
+ (NSArray *)configurationsFromApplicationBundle;

@end
