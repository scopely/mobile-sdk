//
//  SPInterstitialEvent.h
//  SponsorPayTestApp
//
//  Created by Daniel Barden on 07/11/13.
//  Copyright (c) 2013 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SPUrlParametersProvider.h"

/** Available Interstitials event types */
typedef NS_ENUM(NSUInteger, SPInterstitialEventType) {
    SPInterstitialEventTypeRequest,
    SPInterstitialEventTypeFill,
    SPInterstitialEventTypeNoFill,
    SPInterstitialEventTypeImpression,
    SPInterstitialEventTypeClick,
    SPInterstitialEventTypeClose,
    SPInterstitialEventTypeError
};

/**
 * Represents an interstitial event.
 * Stores an event of type SPInterstitialEventType and the network responsible for firing the event
 */
@interface SPInterstitialEvent : NSObject <SPURLParametersProvider>

@property (nonatomic, copy) NSString *network;
@property (nonatomic, assign) SPInterstitialEventType type;
@property (nonatomic, copy) NSString *adId;

- (id)initWithEventType:(SPInterstitialEventType)eventType network:(NSString *)network adId:(NSString *)adId;

@end
