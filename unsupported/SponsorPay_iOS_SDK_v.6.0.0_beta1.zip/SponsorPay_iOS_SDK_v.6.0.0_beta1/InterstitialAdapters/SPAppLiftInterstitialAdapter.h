//
//  SPAppLiftInterstitialAdapter.h
//  SponsorPayTestApp
//
//  Created by Daniel Barden on 20/11/13.
//  Copyright (c) 2013 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <PlayAdsSDK.h>
#import "SPInterstitialNetworkAdapter.h"

@interface SPAppLiftInterstitialAdapter : NSObject <SPInterstitialNetworkAdapter, PlayAdsSDKDelegate>

@end
