
# SponsorPay SDK - PhoneGap Plugin

SponsorPay Android SDK is at version 1.9.1

## What you get

* Offerwal
* Unlock Offerwal
* Virtual Currency Server
* Advertiser callback

## What you need

* Eclipse 3.4 or higher
* Android Development Tools installed
* PhoneGap library

## How to proceed

* Download the SponsorPay Android SDK
* Download the latest version of PhoneGap for Android
* Create a new Android project
* Follow the [PhoneGap tutorial] (http://docs.phonegap.com/en/2.1.0/guide_getting-started_android_index.md.html#Getting%20Started%20with%20Android)
* Add the SponsorPaySDKPhoneGapAndroidPlugin.jar and the sponsorpay-android-sdk.jar to your classpath
* Add either SponsorPayPublisher.js or SponsorPayAdvertiser.js (or both) to your /assets/www/ directory
* Add in the Android manifest file
    * the following permissions
        * 

				<uses-permission android:name="android.permission.INTERNET" />

        * 

				<uses-permission android:name="android.permission.READ_PHONE_STATE" />

        * 

				<uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
    * the following activities (if you need publisher related features)
        * 
						
				<activity android:configChanges="orientation" android:name="com.sponsorpay.sdk.android.publisher.OfferWallActivity"/>
        * 

				<activity android:configChanges="orientation" android:name="com.sponsorpay.sdk.android.publisher.InterstitialActivity" android:theme="@android:style/Theme.Dialog"/>
* Add the plugins you are using in your plugin.xml file located at /res/xml/
    * 

			<plugin name="SponsorPayPublisher" value="com.sponsorpay.sdk.android.phonegap.publisher.SponsorPayPublisherPlugin"/>
    * 

	 		<plugin name="SponsorPayAdvertiser" value="com.sponsorpay.sdk.android.phonegap.advertiser.SponsorPayAdvertiserPlugin"/>

## Note

For more information on how to use the plugin, you can have a look at the SponsorPay PhoneGap test application.
