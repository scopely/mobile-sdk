/**
 *  
 * @return Object literal singleton instance of SponsorPayAdvertiser
 */

var SponsorPayAdvertiser = function() {
};

/**
 * Get the SponsorPay SDK version.
 * @param callback
 *            The callback which will be called with the returning value
 */
SponsorPayAdvertiser.prototype.showVersion = function (callback) {
	return PhoneGap.exec(callback,
			null,
			'SponsorPayAdvertiser', 
			'showVersion', 
			[]); 
}

/**
 * Triggers the Advertiser callback. If passed a non-null and non-empty Application ID, it will
 * be used. Otherwise the Application ID will be retrieved from the value defined in the host
 * application's Android Manifest XML file.
 * 
 * @param overrideAppId
 *            The App ID to use.
 * @param customParams
 *            A map of extra key/value pairs to add to the request URL.
 */
SponsorPayAdvertiser.prototype.sendAdvertiserCallback = function(overridingAppId, customParams) {
	return PhoneGap.exec(null,
			null,
			'SponsorPayAdvertiser', 
			'sendAdvertiserCallback', 
			[  overridingAppId, customParams ]); 
};

/**
 * Triggers the Advertiser callback after the specified delay has passed. Will use the provided
 * App ID (if provided) instead of trying to retrieve the one defined in the host application's manifest.
 * 
 * @param delayMin
 *            The delay in minutes for triggering the Advertiser callback.
 * @param overrideAppId
 *            The App ID to use.
 * @param customParams
 *            Map of custom key/values to add to the parameters on the requests to the REST API.
 */
SponsorPayAdvertiser.prototype.sendAdvertiserCallbackWithDelay = function(delay, 
		overridingAppId, customParams ) {
	return PhoneGap.exec(null,
			null,
			'SponsorPayAdvertiser', 
			'sendAdvertiserCallbackWithDelay', 
			[ delay, overridingAppId, customParams ]); 
};


PhoneGap.addConstructor(function() {
	PhoneGap.addPlugin("SponsorPayAdvertiser", new SponsorPayAdvertiser());
});
