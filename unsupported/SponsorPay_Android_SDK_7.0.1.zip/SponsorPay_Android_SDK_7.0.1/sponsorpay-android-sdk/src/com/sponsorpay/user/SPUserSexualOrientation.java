/**
 * SponsorPay Android SDK
 *
 * Copyright 2011 - 2014 SponsorPay. All rights reserved.
 */

package com.sponsorpay.user;

public enum SPUserSexualOrientation{
	straight,
	bisexual,
	gay,
	unknown
}