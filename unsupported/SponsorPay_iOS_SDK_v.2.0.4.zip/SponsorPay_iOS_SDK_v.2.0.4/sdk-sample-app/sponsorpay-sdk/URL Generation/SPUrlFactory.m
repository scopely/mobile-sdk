//
//  SPUrlFactory.m
//  SponsorPay iOS SDK
//
//  Copyright 2012 SponsorPay. All rights reserved.
//


#import "SPUrlFactory.h"
#import "SPJailbreakDetection.h"
#import "SPSignature.h"
#import "SPLogger.h"

#import "SP_SDK_versions.h"
 
#import "OpenUDID.h"
#import "SecureUDID.h"
#import "NSString+Escaping.h"

#import <SystemConfiguration/SystemConfiguration.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import <CoreTelephony/CTCarrier.h>

#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 60000
#import <AdSupport/ASIdentifierManager.h>
#endif

#pragma mark url parameters definition
// URL parameters to pass on the query string
#define URL_PARAM_OS_NAME                           @"os_name"
#define URL_PARAM_OS_VERSION                        @"os_version"
#define URL_PARAM_PHONE_MODEL                       @"phone_model"
#define URL_PARAM_LANGUAGE                          @"language"
#define URL_PARAM_JAILBROKEN                        @"jailbroken"

#define URL_PARAM_JAILBROKEN_YES                    @"true"
#define URL_PARAM_JAILBROKEN_NO                     @"false"

#define URL_PARAM_SIGNATURE                         @"signature"
#define URL_PARAM_SDK_VERSION                       @"sdk_version"

#define URL_PARAM_SCREEN_WIDTH                      @"screen_width"
#define URL_PARAM_SCREEN_HEIGHT                     @"screen_height"

#define URL_PARAM_NETWORK_CONNECTION_TYPE           @"network_connection_type"
#define URL_PARAM_NETWORK_CONNECTION_TYPE_CELLULAR  @"cellular"
#define URL_PARAM_NETWORK_CONNECTION_TYPE_WIFI      @"wifi"

#define URL_PARAM_CARRIER_NAME                      @"carrier_name"
#define URL_PARAM_CARRIER_COUNTRY                   @"carrier_country"

#define URL_PARAM_APP_BUNDLE_NAME                   @"app_bundle_name"
#define URL_PARAM_APP_VERSION                       @"app_version"

#define URL_PARAM_MANUFACTURER                      @"manufacturer"
#define URL_PARAM_MANUFACTURER_APPLE                @"Apple Inc."

#define URL_PARAM_ADVERTISER_ID                     @"apple_idfa"
#define URL_PARAM_ADVERTISER_ID_TRACKING_ENABLED    @"apple_idfa_tracking_enabled"

#pragma mark -

#pragma mark private interface definition
@interface SPUrlFactory()
@property (readonly, retain) NSMutableDictionary *urlParamsDictionary;
- (NSString *)paramsString;
- (NSString *)paramsSignatureForToken:(NSString *)token;
- (void)addReleaseVersionString;
@end
#pragma mark -

@implementation SPUrlFactory

- (NSMutableDictionary *)urlParamsDictionary {
    if (!_urlParamsDictionary) {
        _urlParamsDictionary = [[NSMutableDictionary dictionaryWithCapacity:10] retain];
    }
    return _urlParamsDictionary;
}

- (id)initWithBaseUrl:(NSString *)theUrl {
    if ((self = [super init])) {
        _baseUrl = [theUrl retain];
        [self addReleaseVersionString];
    }
    return self;
}

- (void)addReleaseVersionString
{
    NSString *sdkVersionString = [NSString stringWithFormat:@"%d.%d.%d",
                                  SP_SDK_MAJOR_RELEASE_VERSION_NUMBER,
                                  SP_SDK_MINOR_RELEASE_VERSION_NUMBER,
                                  SP_SDK_FIX_RELEASE_VERSION_NUMBER];

    [self addKey:URL_PARAM_SDK_VERSION withValue:sdkVersionString];
}

- (void)addKey:(NSString *)key withValue:(NSString *)value {
    if (value)
        [self.urlParamsDictionary setObject:value forKey:key];
}

- (void)addKey:(NSString *)key withIntegerValue:(int)intValue {
    [self addKey:key
       withValue:[NSString stringWithFormat:@"%d", intValue]];
}

- (void)addKeyValuePairsFromDictionary:(NSDictionary *)dictionary {
    [self.urlParamsDictionary addEntriesFromDictionary:dictionary];
}

- (void)addParametersProvider:(id<SPUrlParametersProvider>)paramsProvider {
    if (!_urlParamsProviders) {
        _urlParamsProviders = [[NSMutableSet alloc] initWithCapacity:3];
    }
    [_urlParamsProviders addObject:paramsProvider];
}

- (void)addDeviceInfo {
    for (id paramsProvider in _urlParamsProviders) {
        if ([paramsProvider respondsToSelector:@selector(dictionaryWithKeyValueParameters)]) {
            [self.urlParamsDictionary addEntriesFromDictionary:[paramsProvider dictionaryWithKeyValueParameters]];
        }
    }
    
    // Gather information about the device
    UIDevice *device = [UIDevice currentDevice];

    [self.urlParamsDictionary setObject:device.systemName forKey:URL_PARAM_OS_NAME];
    [self.urlParamsDictionary setObject:device.systemVersion forKey:URL_PARAM_OS_VERSION];
    [self.urlParamsDictionary setObject:device.model forKey:URL_PARAM_PHONE_MODEL];
    [self.urlParamsDictionary setObject:[[NSLocale currentLocale] localeIdentifier]
                                 forKey:URL_PARAM_LANGUAGE];
 
    
    if(customParamsProvider) {
        [self.urlParamsDictionary setValuesForKeysWithDictionary:[customParamsProvider dictionaryWithKeyValueParameters]];
    }
    
    UIScreen *mainScreen = [UIScreen mainScreen];
    CGFloat screenScale = [mainScreen scale] ? mainScreen.scale : 1.0;
    int actualScreenWidth = round(mainScreen.bounds.size.width * screenScale);
    int actualScreenHeight = round(mainScreen.bounds.size.height * screenScale);
    
    [self.urlParamsDictionary setObject:[NSString stringWithFormat:@"%d", actualScreenWidth]
                                 forKey:URL_PARAM_SCREEN_WIDTH];
    [self.urlParamsDictionary setObject:[NSString stringWithFormat:@"%d", actualScreenHeight]
                                 forKey:URL_PARAM_SCREEN_HEIGHT];

    NSString *jailBreakValue = [SPJailbreakDetection isJailBroken] ? URL_PARAM_JAILBROKEN_YES : URL_PARAM_JAILBROKEN_NO;
    [self.urlParamsDictionary setObject:jailBreakValue forKey:URL_PARAM_JAILBROKEN];
    
    SCNetworkReachabilityRef spReachability = SCNetworkReachabilityCreateWithName(NULL, "sponsorpay.com");
    SCNetworkReachabilityFlags spReachabilityFlags;
    SCNetworkReachabilityGetFlags(spReachability, &spReachabilityFlags);
    BOOL connectionIsWan = spReachabilityFlags & ((1 << 18) != 0);
    CFRelease(spReachability);
    
    NSString *connectionTypeValue = connectionIsWan ? URL_PARAM_NETWORK_CONNECTION_TYPE_CELLULAR : URL_PARAM_NETWORK_CONNECTION_TYPE_WIFI;
    
    [self.urlParamsDictionary setObject:connectionTypeValue forKey:URL_PARAM_NETWORK_CONNECTION_TYPE];
    
    CTTelephonyNetworkInfo *networkInfo = [[[CTTelephonyNetworkInfo alloc] init] autorelease];
    CTCarrier *currentCarrier = [networkInfo subscriberCellularProvider];
    if (currentCarrier && currentCarrier.carrierName && currentCarrier.isoCountryCode) {
        [self.urlParamsDictionary setObject:currentCarrier.carrierName forKey:URL_PARAM_CARRIER_NAME];
        [self.urlParamsDictionary setObject:currentCarrier.isoCountryCode forKey:URL_PARAM_CARRIER_COUNTRY];
    } else {
        [self.urlParamsDictionary setObject:@"" forKey:URL_PARAM_CARRIER_NAME];
        [self.urlParamsDictionary setObject:@"" forKey:URL_PARAM_CARRIER_COUNTRY];
    }

    
    NSString *appBundleName = [[NSBundle mainBundle] bundleIdentifier];
    NSString *appVersion = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    if (!appVersion) {
        appVersion = @"";
    }
    [self.urlParamsDictionary setObject:appBundleName forKey:URL_PARAM_APP_BUNDLE_NAME];
    [self.urlParamsDictionary setObject:appVersion forKey:URL_PARAM_APP_VERSION];
    
    [self.urlParamsDictionary setObject:URL_PARAM_MANUFACTURER_APPLE forKey:URL_PARAM_MANUFACTURER];
    
    NSString *idfaValue = @"";
    NSString *idfaTrackingEnabled = @"";

#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 60000
    if (NSClassFromString(@"ASIdentifierManager")){
        NSUUID *advertiserId = [[ASIdentifierManager sharedManager] advertisingIdentifier];
        if (advertiserId) {
            idfaValue = [advertiserId UUIDString];
        }
        idfaTrackingEnabled = [[ASIdentifierManager sharedManager] isAdvertisingTrackingEnabled] ? @"true" : @"false";
    }
#endif

    [self.urlParamsDictionary setObject:idfaValue forKey:URL_PARAM_ADVERTISER_ID];
    [self.urlParamsDictionary setObject:idfaTrackingEnabled forKey:URL_PARAM_ADVERTISER_ID_TRACKING_ENABLED];
        
}

- (NSString *)urlString {
    return [_baseUrl stringByAppendingString:[self paramsString]];
}

- (NSString *)paramsString {
    NSMutableString *returnValue = [NSMutableString stringWithCapacity:100];
    [returnValue appendString:@"?"];
    for (NSString *currKey in _urlParamsDictionary) {
        NSString *currValue = [[_urlParamsDictionary objectForKey:currKey] stringWithPercentEscape];
        [returnValue appendFormat:@"%@=%@&", currKey, currValue];
    }
    
    return returnValue;
}

- (NSString *)urlStringWithSignatureForSecretKey:(NSString *)secretToken {
    return [NSString stringWithFormat:@"%@%@=%@", [self urlString],
            URL_PARAM_SIGNATURE, [self paramsSignatureForToken:secretToken]];
}

- (NSString *)paramsSignatureForToken:(NSString *)token
{
    NSArray *paramKeys = [_urlParamsDictionary allKeys];
    NSArray *orderedParamKeys = [paramKeys sortedArrayUsingSelector:@selector(compare:)];
    
    NSMutableString *concatenatedOrderedParams = [[NSMutableString alloc] initWithCapacity:255];
    NSEnumerator *e = [orderedParamKeys objectEnumerator];
    for (NSString *paramKey = [e nextObject]; nil!=paramKey; paramKey = [e nextObject]) {
        NSString *paramValue = [_urlParamsDictionary objectForKey:paramKey];
        NSString *keyValueParam = [NSString stringWithFormat:@"%@=%@&", paramKey, paramValue];
        [concatenatedOrderedParams appendString:keyValueParam];
    }
    
    NSString *signature  = [SPSignature signatureForString:concatenatedOrderedParams secretToken:token];
    [concatenatedOrderedParams release];
    return signature;
}

- (void)dealloc {
    [_baseUrl release];
    [_urlParamsDictionary release];
    [_urlParamsProviders release];
    [super dealloc];
}

static id<SPUrlParametersProvider> customParamsProvider;

+(void)customParametersProvider:(id<SPUrlParametersProvider>)provider
{
    customParamsProvider = provider;
}

+ (SPUrlFactory *)urlFactoryWithDefaultParametersProvidersWithBaseUrl:(NSString *)baseUrl
                                      shouldUseSystemDeviceIdentifier:(BOOL)useSystemDeviceIdentifier {
    SPUrlFactory *urlFactory = [[SPUrlFactory alloc] initWithBaseUrl:baseUrl];
    
#ifndef kSPShouldNotSendPlainMACAddress
    SPMacAddressProvider *macAddressProvider = [[SPMacAddressProvider alloc] init];
    [urlFactory addParametersProvider:macAddressProvider];
    [macAddressProvider release];
#endif
    
#ifndef kSPShouldNotSendMD5MacAddress
    SPMD5MacAddressProvider *md5MacAddressProvider = [[SPMD5MacAddressProvider alloc] init];
    [urlFactory addParametersProvider:md5MacAddressProvider];
    [md5MacAddressProvider release];
#endif
    
#ifndef kSPShouldNotSendSHA1MacAddress
    SPSHA1MacAddressProvider *sha1MacAddressProvider = [[SPSHA1MacAddressProvider alloc] init];
    [urlFactory addParametersProvider:sha1MacAddressProvider];
    [sha1MacAddressProvider release];
#endif

#ifndef kSPShouldNotSendOpenUDID
    SPOpenUDIDProvider *openUDIDProvider = [[SPOpenUDIDProvider alloc] init];
    [urlFactory addParametersProvider:openUDIDProvider];
    [openUDIDProvider release];
#endif
    
#ifndef kSPShouldNotSendSecureUDID
    SPSecureUDIDProvider *secureUDIDProvider = [[SPSecureUDIDProvider alloc] init];
    [urlFactory addParametersProvider:secureUDIDProvider];
    [secureUDIDProvider release];
#endif

#ifndef kSPShouldNotSendSystemDeviceIdentifier
    if (useSystemDeviceIdentifier) {
        SPSystemUDIDProvider *systemUDIDProvider = [[SPSystemUDIDProvider alloc] init];
        [urlFactory addParametersProvider:systemUDIDProvider];
        [systemUDIDProvider release];
    }
#endif
    
    return [urlFactory autorelease];
}

@end

#include <sys/socket.h>
#include <sys/sysctl.h>
#include <net/if.h>
#include <net/if_dl.h>

@implementation SPMacAddressProvider

- (NSString *)macAddressPlain {
    if (!_macAddressPlain) {
        NSError *errorFetchingMacAddress = nil;
        _macAddressPlain = [self fetchPlainMacAddressOrFailWithError:&errorFetchingMacAddress];
        if (!_macAddressPlain) {
            [SPLogger log:@"Error fetching MAC address: %@",
                  [errorFetchingMacAddress.userInfo objectForKey:kSPErrorLoggableDescription]];
        } else {
            [_macAddressPlain retain];
        }
    }
    return _macAddressPlain;
}

- (NSString *)fetchPlainMacAddressOrFailWithError:(NSError **)error {
    int                 mib[6];
    size_t              len;
    char                *buf;
    unsigned char       *ptr;
    struct if_msghdr    *ifm;
    struct sockaddr_dl  *sdl;
    
    mib[0] = CTL_NET;
    mib[1] = AF_ROUTE;
    mib[2] = 0;
    mib[3] = AF_LINK;
    mib[4] = NET_RT_IFLIST;
    
    if ((mib[5] = if_nametoindex("en0")) == 0) {
        if (error)
            *error = [NSError errorWithDomain:kSPErrorDomain code:-1 userInfo:[NSDictionary dictionaryWithObject:@"if_nametoindex error" forKey:kSPErrorLoggableDescription]];
        return nil;
    }
    
    if (sysctl(mib, 6, NULL, &len, NULL, 0) < 0) {
        if (error)
            *error = [NSError errorWithDomain:kSPErrorDomain code:-1 userInfo:[NSDictionary dictionaryWithObject:@"sysctl 1 error" forKey:kSPErrorLoggableDescription]];
        return nil;
    }
    
    if ((buf = malloc(len)) == NULL) {
        if (error) 
            *error = [NSError errorWithDomain:kSPErrorDomain code:-1 userInfo:[NSDictionary dictionaryWithObject:@"malloc error" forKey:kSPErrorLoggableDescription]];
        return nil;
    }
    
    if (sysctl(mib, 6, buf, &len, NULL, 0) < 0) {
        if (error)
            *error = [NSError errorWithDomain:kSPErrorDomain code:-1 userInfo:[NSDictionary dictionaryWithObject:@"sysctl 2 error" forKey:kSPErrorLoggableDescription]];
        return nil;
    }
    
    ifm = (struct if_msghdr *)buf;
    sdl = (struct sockaddr_dl *)(ifm + 1);
    ptr = (unsigned char *)LLADDR(sdl);
    
    NSString *macAddress = [[NSString alloc]
                            initWithFormat:@"%02X:%02X:%02X:%02X:%02X:%02X",
                            *ptr, *(ptr+1), *(ptr+2), *(ptr+3), *(ptr+4), *(ptr+5)];
    
    free(buf);
    
    return [macAddress autorelease];
}

- (void) dealloc {
    [_macAddressPlain release];
    [super dealloc];
}

- (NSDictionary *)dictionaryWithKeyValueParameters {
    return [NSDictionary dictionaryWithObject:self.macAddressPlain forKey:URL_PARAM_MAC_ADDRESS];
}

@end

@implementation SPSHA1MacAddressProvider

- (NSString *)macAddressSHA1 {
    if (!_macAddressSHA1)
        _macAddressSHA1 = [[SPSignature formattedSHA1forString:self.macAddressPlain] retain];
    return _macAddressSHA1;
}

- (void)dealloc {
    [_macAddressSHA1 release];
    [super dealloc];
}

- (NSDictionary *)dictionaryWithKeyValueParameters {
    return [NSDictionary dictionaryWithObject:self.macAddressSHA1 forKey:URL_PARAM_MAC_ADDRESS_SHA1];
}

@end

@implementation SPMD5MacAddressProvider
- (NSString *)macAddressMD5 {
    if (!_macAddressMD5)
        _macAddressMD5 = [[SPSignature formattedMD5forString:self.macAddressPlain] retain];
    return _macAddressMD5;
}

- (void)dealloc {
    [_macAddressMD5 release];
    [super dealloc];
}

- (NSDictionary *)dictionaryWithKeyValueParameters {
    return [NSDictionary dictionaryWithObject:self.macAddressMD5 forKey:URL_PARAM_MAC_ADDRESS_MD5];
}

@end

@implementation SPOpenUDIDProvider
- (NSDictionary *)dictionaryWithKeyValueParameters {
    return [NSDictionary dictionaryWithObject:[OpenUDID value] forKey:URL_PARAM_OPENUDID];
}
@end

@implementation SPSecureUDIDProvider
- (NSDictionary *)dictionaryWithKeyValueParameters {
#define kSPSecureUDIDDomain @"com.sponsorpay.sdk"
#define kSPSecureUDIDKey @"WHX9h4Gc4FNR78IlUPLtBqYfyf1QygszrKbgnQmsBRpKaKjH6ZdEKN94Wo40hbQ"
    return [NSDictionary dictionaryWithObject:[SecureUDID UDIDForDomain:kSPSecureUDIDDomain
                                                               usingKey:kSPSecureUDIDKey]
                                       forKey:URL_PARAM_SECUREUDID];
}
@end

@implementation SPSystemUDIDProvider
- (NSDictionary *)dictionaryWithKeyValueParameters {
    UIDevice *device = [UIDevice currentDevice];

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    return [NSDictionary dictionaryWithObject:device.uniqueIdentifier forKey:URL_PARAM_DEVICE_ID];
#pragma clang diagnostic pop

}
@end
