//
//  SPPublishAppDelegate.m
//  SponsorPay iOS Test App
//
//  Copyright 2011 SponsorPay. All rights reserved.
//

#import "SPSampleAppDelegate.h"
#import "SPSampleViewController.h"
#import "SPAdvertiserManager.h"

@implementation SPSampleAppDelegate

@synthesize window;
@synthesize viewController;


#pragma mark -
#pragma mark Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    
    // Add the view controller's view to the window and display.
    [self.window addSubview:viewController.view];
    [self.window makeKeyAndVisible];

    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *fetchedAppId = [defaults stringForKey:ENTERED_APPID_KEY];
    
    if (fetchedAppId && ![fetchedAppId isEqualToString:@""]) {
        
        if ([defaults boolForKey:ENTERED_STAGING_URLS_KEY])
            [SPAdvertiserManager overrideBaseUrlWithUrl:ADVERTISER_BASE_STAGING_URL];
        else
            [SPAdvertiserManager restoreBaseUrlToDefault];
        
        [[SPAdvertiserManager sharedManager] reportOfferCompleted:fetchedAppId];
    }
    
    return YES;
}

#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {

}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
