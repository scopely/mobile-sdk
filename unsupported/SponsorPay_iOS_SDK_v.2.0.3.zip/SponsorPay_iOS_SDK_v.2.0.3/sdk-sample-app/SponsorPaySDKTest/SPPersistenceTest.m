//
//  SPPersistenceTest.m
//  SponsorPaySample
//
//  Created by David Davila on 7/18/12.
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import "SPPersistenceTest.h"
#import "SPPersistence.h"

@implementation SPPersistenceTest

- (void)setUp
{
    [super setUp];
    [SPPersistence resetAllSDKValues];
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testDidAdvertiserCallbackSucceedPersistence
{
    // Test for NO after reset
    BOOL initialValue = [SPPersistence didAdvertiserCallbackSucceed];
    STAssertEquals(initialValue, NO, @"didAdvertiserCallbackSucceed should be equal to NO");
    
    // Test change to YES
    [SPPersistence setDidAdvertiserCallbackSucceed:YES];
    BOOL afterChangeValue = [SPPersistence didAdvertiserCallbackSucceed];
    STAssertEquals(afterChangeValue, YES, @"didAdvertiserCallbackSucceed should be equal to YES");
}

- (void)testChangingUDIDAccessPermissionToNOPersistsUserAnsweredAboutPermission
{
    // Test for NO after reset
    BOOL initialValue = [SPPersistence userDidAnswerAboutPermissionForSystemDeviceIdentifier];
    STAssertEquals(initialValue, NO, @"userDidAnswerAboutPermissionForSystemDeviceIdentifier should be equal to NO");
    
    // Set UDID access permissions to NO and test that userDidAnswerAboutPermissionForSystemDeviceIdentifier is set to YES
    [SPPersistence setMayAccessSystemDeviceIdentifier:NO];
    BOOL afterChangeValue = [SPPersistence userDidAnswerAboutPermissionForSystemDeviceIdentifier];
    STAssertEquals(afterChangeValue, YES, @"userDidAnswerAboutPermissionForSystemDeviceIdentifier should be equal to YES after setting UDID access permissions");
}

- (void)testChangingUDIDAccessPermissionToYESPersistsUserAnsweredAboutPermission
{
    // Test for NO after reset
    BOOL initialValue = [SPPersistence userDidAnswerAboutPermissionForSystemDeviceIdentifier];
    STAssertEquals(initialValue, NO, @"userDidAnswerAboutPermissionForSystemDeviceIdentifier should be equal to NO");
    
    // Set UDID access permissions to NO and test that userDidAnswerAboutPermissionForSystemDeviceIdentifier is set to YES
    [SPPersistence setMayAccessSystemDeviceIdentifier:YES];
    BOOL afterChangeValue = [SPPersistence userDidAnswerAboutPermissionForSystemDeviceIdentifier];
    STAssertEquals(afterChangeValue, YES, @"userDidAnswerAboutPermissionForSystemDeviceIdentifier should be equal to YES after setting UDID access permissions");
}

- (void)testChangingUDIDAccessPermissionToNO
{
    // Test for NO after reset
    BOOL initialValue = [SPPersistence mayAccessSystemDeviceIdentifier];
    STAssertEquals(initialValue, NO, @"didAdvertiserCallbackSucceed should be equal to NO");
    
    // Test set to NO
    [SPPersistence setMayAccessSystemDeviceIdentifier:NO];
    BOOL afterSetValue = [SPPersistence mayAccessSystemDeviceIdentifier];
    STAssertEquals(afterSetValue, NO, @"didAdvertiserCallbackSucceed should be equal to NO");
}

- (void)testChangingUDIDAccessPermissionToYES
{
    // Test for NO after reset
    BOOL initialValue = [SPPersistence mayAccessSystemDeviceIdentifier];
    STAssertEquals(initialValue, NO, @"didAdvertiserCallbackSucceed should be equal to NO");
    
    // Test set to YES
    [SPPersistence setMayAccessSystemDeviceIdentifier:YES];
    BOOL afterSetValue = [SPPersistence mayAccessSystemDeviceIdentifier];
    STAssertEquals(afterSetValue, YES, @"didAdvertiserCallbackSucceed should be equal to YES");
}

- (void)testSettingMultipleLatestTransactionIds
{
#define APP_ID_1 @"1273"
#define USER_ID_1 @"userTester1"
#define LTID_1 @"6192384"
    
#define APP_ID_2 @"3172"
#define USER_ID_2 @"testerUZDA4"
#define LTID_2 @"7178943"
    
    // Test for nil after reset
    NSString *initialValue1 = [SPPersistence latestVCSTransactionIdForAppId:APP_ID_1 userId:USER_ID_1];
    STAssertTrue([initialValue1 isEqualToString:SP_VCS_LATEST_TRANSACTION_ID_VALUE_NO_TRANSACTION],
                 @"Non set transaction ID value should be %@ after reset",
                 SP_VCS_LATEST_TRANSACTION_ID_VALUE_NO_TRANSACTION);
    
    NSString *initialValue2 = [SPPersistence latestVCSTransactionIdForAppId:APP_ID_1 userId:USER_ID_1];
    STAssertTrue([initialValue2 isEqualToString:SP_VCS_LATEST_TRANSACTION_ID_VALUE_NO_TRANSACTION],
                 @"Non set transaction ID value should be %@ after reset",
                 SP_VCS_LATEST_TRANSACTION_ID_VALUE_NO_TRANSACTION);
    
    // Set transaction IDs
    [SPPersistence setLatestVCSTransactionId:LTID_1 forAppId:APP_ID_1 userId:USER_ID_1];
    NSString *afterSetValue1 = [SPPersistence latestVCSTransactionIdForAppId:APP_ID_1 userId:USER_ID_1];
    STAssertTrue([afterSetValue1 isEqualToString:LTID_1],
                 @"Set transaction id for the first time for app ID %@ and user ID %@", APP_ID_1, USER_ID_1);
    
    
    [SPPersistence setLatestVCSTransactionId:LTID_2 forAppId:APP_ID_2 userId:USER_ID_2];
    NSString *afterSetValue2 = [SPPersistence latestVCSTransactionIdForAppId:APP_ID_2 userId:USER_ID_2];
    STAssertTrue([afterSetValue2 isEqualToString:LTID_2],
                 @"Set transaction id for the first time for app ID %@ and user ID %@", APP_ID_2, USER_ID_2);
    
    // Modify (swap) transaction IDs
    [SPPersistence setLatestVCSTransactionId:LTID_2 forAppId:APP_ID_1 userId:USER_ID_1];
    NSString *afterSwapValue1 = [SPPersistence latestVCSTransactionIdForAppId:APP_ID_1 userId:USER_ID_1];
    STAssertTrue([afterSwapValue1 isEqualToString:LTID_2],
                  @"Modified transaction ID for app ID %@ and user ID %@", APP_ID_1, USER_ID_1);
    
    [SPPersistence setLatestVCSTransactionId:LTID_1 forAppId:APP_ID_2 userId:USER_ID_2];
    NSString *afterSwapValue2 = [SPPersistence latestVCSTransactionIdForAppId:APP_ID_2 userId:USER_ID_2];
    STAssertTrue([afterSwapValue2 isEqualToString:LTID_1],
                 @"Modified transaction ID for app ID %@ and user ID %@", APP_ID_2, USER_ID_2);
    
}

@end
