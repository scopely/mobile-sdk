//
//  SPSampleViewController.m
//  SponsorPay iOS Test App
//
//  Copyright 2011 SponsorPay. All rights reserved.
//

#import "SPSampleViewController.h"
#import "SPAdvertiserManager.h"
#import "SPInterstitialViewController.h"
#import "SPSettingsViewController.h"
#import "SPUrlFactory.h"

@interface SPSampleViewController()
@property (readonly) NSString *userEnteredAppId;
@property (readonly) NSString *userEnteredUserId;
@property (readonly) NSString *userEnteredSecurityToken;

@property (readonly) SPCustomParamsUtil *additionalParameters;

- (void)removeAndReleaseInterstitialViewController;
- (void)didFinishVCSRequest;
- (void)persistUseEnteredValues;
@end

@implementation SPSampleViewController

#pragma mark properties
@synthesize scrollView;
@synthesize contentView;
@synthesize appIdTextField;
@synthesize userIdTextField;
@synthesize backgroundUrlTextField;
@synthesize skinNameTextField;
@synthesize securityTokenTextField;
@synthesize closeAfterClickingOffer;
@synthesize useStagingUrlsSwitch;
@synthesize sendVCSDeltaRequestButton;
@synthesize settingsButton;

@synthesize latestUsedVCSTransactionId;

-(SPCustomParamsUtil *)additionalParameters {
    if(!additionalParameters) {
        additionalParameters = [[SPCustomParamsUtil alloc] init];
        [SPUrlFactory customParametersProvider:additionalParameters];
    }
    return additionalParameters;
}

- (NSString *)userEnteredAppId {
    return self.appIdTextField.text;
}

- (NSString *)userEnteredUserId {
    return self.userIdTextField.text;
}

- (NSString *)userEnteredSecurityToken {
    return self.securityTokenTextField.text;
}
#pragma mark -

- (IBAction)launchOfferWall:(id)sender {
    if (offerWallViewController) {
        [offerWallViewController.view removeFromSuperview];
        [offerWallViewController release];
        offerWallViewController = nil;
    }
    offerWallViewController = [[SPOfferWallViewController alloc] initWithUserId:self.userEnteredUserId
                                                                          appId:self.userEnteredAppId];
    offerWallViewController.delegate = self;
    offerWallViewController.shouldFinishOnRedirect = closeAfterClickingOffer.on;
    
    [self.view addSubview:offerWallViewController.view];
}

- (IBAction)launchInterstitial:(id)sender {
    if (nil != interstitialViewController) {
        [interstitialViewController cancelInterstitialRequest];
        [interstitialViewController.view removeFromSuperview];
        [interstitialViewController release];
        interstitialViewController = nil;
    }
    interstitialViewController = [[SPInterstitialViewController alloc] initWithUserId:self.userEnteredUserId
                                                                        appId:self.userEnteredAppId
                                                                backgroundUrl:backgroundUrlTextField.text
                                                                         skin:skinNameTextField.text];
    interstitialViewController.delegate = self;
    interstitialViewController.shouldFinishOnRedirect = closeAfterClickingOffer.on;
    [self.view addSubview:interstitialViewController.view];
}

- (IBAction)triggerAdvertiserCall:(id)sender {
    @try {
        [[SPAdvertiserManager sharedManager] reportOfferCompleted:self.userEnteredAppId];
    }
    @catch (NSException *exception) {
        UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"The SDK threw an exception" 
                                                         message:exception.reason 
                                                        delegate:self cancelButtonTitle:@"OK" 
                                               otherButtonTitles:nil] autorelease];
        [alert show];	
    }
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return YES;
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.scrollView addSubview:self.contentView];
    self.scrollView.contentSize = self.contentView.bounds.size;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    
    return NO;
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)offerWallViewController:(SPOfferWallViewController *)offerwallVC
         isFinishedWithStatus:(int)status {
	//NSLog(@"SPSampleViewController did receive SPOfferWallViewController callback with status: %@", status);
	[offerWallViewController.view removeFromSuperview];
	[offerWallViewController autorelease];
    offerWallViewController = nil;
}

- (void)interstitialViewController:(SPInterstitialViewController *)theInterstitialViewController
               didChangeStatus:(SPInterstitialViewControllerStatus)status {
    
    NSString *statusAsString;
    
    switch (status) {
        case AD_SHOWN:
            statusAsString = @"AD_SHOWN";
            break;
        case NO_INTERSTITIAL_AVAILABLE:
            statusAsString = @"NO_INTERSTITIAL_AVAILABLE";
            [self removeAndReleaseInterstitialViewController];
            break;
        case ERROR_NETWORK:
            statusAsString = @"ERROR_NETWORK";
            [self removeAndReleaseInterstitialViewController];
            break;
        case ERROR_TIMEOUT:
            statusAsString = @"ERROR_TIMEOUT";
            [self removeAndReleaseInterstitialViewController];
            break;
        case CLOSED:
            statusAsString = @"CLOSED";
            [self removeAndReleaseInterstitialViewController];
            break;
    }
    
    NSLog(@"SPSampleViewController did receive InterstitialViewController callback with status %@", statusAsString);
}

- (void)removeAndReleaseInterstitialViewController {
    if (interstitialViewController) {
        [interstitialViewController.view removeFromSuperview];
        [interstitialViewController autorelease];
        interstitialViewController = nil;
    }
}

- (IBAction)sendVCSDeltaRequest:(id)sender
{
    if (!virtualCurrencyConnector) {
        virtualCurrencyConnector =
        [[SPVirtualCurrencyServerConnector alloc] initWithUserId:self.userEnteredUserId
                                                   appId:self.userEnteredAppId
                                              secretToken:self.userEnteredSecurityToken];
        virtualCurrencyConnector.shouldLogVerbosely = YES;
        virtualCurrencyConnector.delegate = self;
    } else {
        virtualCurrencyConnector.userId = self.userEnteredUserId;
        virtualCurrencyConnector.appId = self.userEnteredAppId;
        virtualCurrencyConnector.secretToken = self.userEnteredSecurityToken;
    }
        
    self.latestUsedVCSTransactionId = virtualCurrencyConnector.latestTransactionId;
    
    [virtualCurrencyConnector fetchDeltaOfCoins];
    
    UIApplication* app = [UIApplication sharedApplication];
	app.networkActivityIndicatorVisible = YES;
}

- (void)virtualCurrencyConnector:(SPVirtualCurrencyServerConnector *)vcConnector
  didReceiveDeltaOfCoinsResponse:(double)deltaOfCoins
             latestTransactionId:(NSString *)transactionId
{
    [self didFinishVCSRequest];
    
    NSString *formattedMessage = [NSString stringWithFormat:
                                  @"Sent Latest Transaction ID:%@ Delta of Coins:%f\nReturned Latest Transaction ID:%@",
                                  self.latestUsedVCSTransactionId, deltaOfCoins, transactionId];
    
    UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"VCS Response Received" 
                                                     message:formattedMessage 
                                                    delegate:self cancelButtonTitle:@"OK" 
                                           otherButtonTitles:nil] autorelease];
    [alert show];	
}

- (void)virtualCurrencyConnector:(SPVirtualCurrencyServerConnector *)vcConnector
                 failedWithError:(SPVirtualCurrencyRequestErrorType)error
                       errorCode:(NSString *)errorCode
                    errorMessage:(NSString *)errorMessage
{
    [self didFinishVCSRequest];
    
    NSString *errorType;
    
    switch (error) {
        case NO_ERROR:
            errorType = @"NO_ERROR";
            break;
        case ERROR_NO_INTERNET_CONNECTION:
            errorType = @"ERROR_NO_INTERNET_CONNECTION";
            break;
        case ERROR_INVALID_RESPONSE:
            errorType = @"ERROR_INVALID_RESPONSE";
            break;
        case ERROR_INVALID_RESPONSE_SIGNATURE:
            errorType = @"ERROR_INVALID_RESPONSE_SIGNATURE";
            break;
        case SERVER_RETURNED_ERROR:
            errorType = @"SERVER_RETURNED_ERROR";
            break;
        case ERROR_OTHER:
            errorType = @"ERROR_OTHER";
            break;
        default:
            errorType = [NSString stringWithFormat:@"%d", error];
            break;
    }
    
    NSString *formattedError = [NSString stringWithFormat:@"%@\n%@\n%@", errorType, errorCode, errorMessage];
    
    UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"Error in VCS Request / Response" 
                                                     message:formattedError 
                                                    delegate:self cancelButtonTitle:@"OK" 
                                           otherButtonTitles:nil] autorelease];
    [alert show];	
}

- (void)didFinishVCSRequest
{
    UIApplication* app = [UIApplication sharedApplication];
	app.networkActivityIndicatorVisible = NO;        
}

- (IBAction)textFieldReturn:(id)sender
{
    [sender resignFirstResponder];
}

- (IBAction)useStagingUrlsValueChanged:(UISwitch *)sender {
    if (sender.on) {
        [SPAdvertiserManager overrideBaseUrlWithUrl:ADVERTISER_BASE_STAGING_URL];
        [SPOfferWallViewController overrideBaseUrlWithUrl:OFFERWALL_BASE_STAGING_URL];
        [SPInterstitialViewController overrideBaseUrlWithUrl:INTERSTITIAL_BASE_STAGING_URL];
        NSLog(@"SPSampleViewController did set staging URLs");
    } else {
        [SPAdvertiserManager restoreBaseUrlToDefault];
        [SPOfferWallViewController restoreBaseUrlToDefault];
        [SPInterstitialViewController restoreBaseUrlToDefault];
        NSLog(@"SPSampleViewController did restore production URLs");
    }
}

- (IBAction)goToSettings:(id)sender
{
    
    SPSettingsViewController *settingsViewController = [[SPSettingsViewController alloc] init];
    settingsViewController.additionalParameters = self.additionalParameters;
    
    if ([self respondsToSelector:@selector(presentViewController:animated:completion:)]) {
        [self presentViewController:settingsViewController animated:YES completion:nil];
    } else {
        [self presentModalViewController:settingsViewController animated:YES];
    }
    
    [settingsViewController release];
}

- (void)viewDidAppear:(BOOL)animated
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];

    self.appIdTextField.text = [defaults stringForKey:ENTERED_APPID_KEY];
    self.userIdTextField.text = [defaults stringForKey:ENTERED_USERID_KEY];
    self.backgroundUrlTextField.text = [defaults stringForKey:ENTERED_BACKGROUND_URL_KEY];
    self.skinNameTextField.text = [defaults stringForKey:ENTERED_SKIN_NAME_KEY];
    self.useStagingUrlsSwitch.on = [defaults boolForKey:ENTERED_STAGING_URLS_KEY];
    [self useStagingUrlsValueChanged:self.useStagingUrlsSwitch];
    self.closeAfterClickingOffer.on = [defaults boolForKey:ENTERED_CLOSE_AFTER_CLICKING_ON_OFFER_KEY];

    NSString *retrievedSecurityToken = [defaults stringForKey:ENTERED_SECURITY_TOKEN_KEY];

    self.securityTokenTextField.text =
        retrievedSecurityToken ? retrievedSecurityToken : DEFAULT_SECURITY_TOKEN;
    
    [[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(appWillResignActiveNotification:) 
												 name:UIApplicationWillResignActiveNotification 
											   object:nil];

    
    [super viewDidAppear:animated];
}

- (void)persistUseEnteredValues
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    [defaults setValue:self.appIdTextField.text forKey:ENTERED_APPID_KEY];
    [defaults setValue:self.userIdTextField.text forKey:ENTERED_USERID_KEY];
    [defaults setValue:self.backgroundUrlTextField.text forKey:ENTERED_BACKGROUND_URL_KEY];
    [defaults setValue:self.skinNameTextField.text forKey:ENTERED_SKIN_NAME_KEY];
    [defaults setValue:self.securityTokenTextField.text forKey:ENTERED_SECURITY_TOKEN_KEY];
    [defaults setBool:self.useStagingUrlsSwitch.on forKey:ENTERED_STAGING_URLS_KEY];
    [defaults setBool:self.closeAfterClickingOffer.on forKey:ENTERED_CLOSE_AFTER_CLICKING_ON_OFFER_KEY];
    
    [defaults synchronize];
    
}

-(void)appWillResignActiveNotification:(NSNotification *)notification
{
    [self persistUseEnteredValues];
}

-(void)viewWillDisappear:(BOOL)animated
{
    [self persistUseEnteredValues];
    [super viewWillDisappear:animated];
}


- (void)dealloc {
    [offerWallViewController release];
    [interstitialViewController release];

    [super dealloc];
}

@end
