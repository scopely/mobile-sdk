//
//  SPPublishAppDelegate.h
//  SponsorPay iOS Test App
//
//  Copyright 2011 SponsorPay. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SPOfferWallViewController.h"
#import "SPInterstitialViewController.h"

@class SPSampleViewController;

@interface SPSampleAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    SPSampleViewController *viewController;

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet SPSampleViewController *viewController;

@end

