package com.sponsorpay.sdk.android.extensions;

import com.adobe.fre.FREFunction;
import com.adobe.fre.FREInvalidObjectException;
import com.adobe.fre.FREObject;
import com.adobe.fre.FRETypeMismatchException;
import com.adobe.fre.FREWrongThreadException;

public abstract class AbstractFunction implements FREFunction {

	public static final String NULL_ARGUMENT = "null.argument";
	
	protected String getNullFromString(FREObject argument)
			throws IllegalStateException, FRETypeMismatchException,
			FREInvalidObjectException, FREWrongThreadException {
		return argument.getAsString().equals(NULL_ARGUMENT) ? null : argument
				.getAsString();
	}
	
	
}
