package com.sponsorpay.sdk.android.extensions.publisher.functions;

import android.content.Context;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREInvalidObjectException;
import com.adobe.fre.FREObject;
import com.adobe.fre.FRETypeMismatchException;
import com.adobe.fre.FREWrongThreadException;
import com.sponsorpay.sdk.android.extensions.AbstractFunction;
import com.sponsorpay.sdk.android.extensions.publisher.PublisherExtensionContext;
import com.sponsorpay.sdk.android.publisher.SponsorPayPublisher;

public class LaunchOfferWallFunction extends AbstractFunction {

	@Override
	public FREObject call(FREContext context, FREObject[] passedArgs) {
		PublisherExtensionContext pubContext = (PublisherExtensionContext) context;
		Context appContext = pubContext.getActivity().getApplicationContext();
		
		//args passed in that order
		try {
			String userId = passedArgs[0].getAsString();
			boolean shouldStayOpen = passedArgs[1].getAsBool();
			String overridingAppId = getNullFromString(passedArgs[2]);
			//FIXME
			pubContext.getActivity().startActivity(
					SponsorPayPublisher.getIntentForOfferWallActivity(appContext, userId,
					shouldStayOpen, overridingAppId));
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (FRETypeMismatchException e) {
			e.printStackTrace();
		} catch (FREInvalidObjectException e) {
			e.printStackTrace();
		} catch (FREWrongThreadException e) {
			e.printStackTrace();
		}
		
		return null;
	}

}
