package com.sponsorpay.sdk.android.extensions.advertiser;

import java.util.HashMap;
import java.util.Map;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.sponsorpay.sdk.android.extensions.advertiser.functions.SendCallbackFunction;
import com.sponsorpay.sdk.android.extensions.advertiser.functions.SendCallbackWithDelayFunction;

public class AdvertiserExtensionContext extends FREContext {

	@Override
	public void dispose() {
	}

	@Override
	public Map<String, FREFunction> getFunctions() {
		Map<String, FREFunction> functionMap = new HashMap<String, FREFunction>();
		functionMap.put("sendAdvertiserCallback", new SendCallbackFunction());
		functionMap.put("sendAdvertiserCallbackWithDelay", new SendCallbackWithDelayFunction());
	    return functionMap;
	}

}
