package com.sponsorpay.sdk.android.extensions;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREExtension;
import com.sponsorpay.sdk.android.extensions.advertiser.AdvertiserExtensionContext;
import com.sponsorpay.sdk.android.extensions.publisher.PublisherExtensionContext;

public class SponsorPaySDKExtension implements FREExtension {
	
	private static final String PUBLISHER_CONTEXT = "publisher.extension.context";
	private static final String ADVERTISER_CONTEXT = "advertiser.extension.context";

	@Override
	public FREContext createContext(String contextType) {
		if (contextType.equals(PUBLISHER_CONTEXT)) {
			return new PublisherExtensionContext();
		} else if (contextType.equals(ADVERTISER_CONTEXT)) {
			return new AdvertiserExtensionContext();
		}
		return null;
	}

	@Override
	public void dispose() {
	}

	@Override
	public void initialize() {
	}

}
