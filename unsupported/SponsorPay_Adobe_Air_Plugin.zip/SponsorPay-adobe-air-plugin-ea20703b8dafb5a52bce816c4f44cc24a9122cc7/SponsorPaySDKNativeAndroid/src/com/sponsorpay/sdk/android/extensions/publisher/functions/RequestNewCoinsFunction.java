package com.sponsorpay.sdk.android.extensions.publisher.functions;

import android.content.Context;
import android.util.Log;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREInvalidObjectException;
import com.adobe.fre.FREObject;
import com.adobe.fre.FRETypeMismatchException;
import com.adobe.fre.FREWrongThreadException;
import com.sponsorpay.sdk.android.extensions.AbstractFunction;
import com.sponsorpay.sdk.android.extensions.publisher.PublisherExtensionContext;
import com.sponsorpay.sdk.android.publisher.SponsorPayPublisher;
import com.sponsorpay.sdk.android.publisher.currency.CurrencyServerAbstractResponse;
import com.sponsorpay.sdk.android.publisher.currency.CurrencyServerDeltaOfCoinsResponse;
import com.sponsorpay.sdk.android.publisher.currency.SPCurrencyServerListener;
import com.sponsorpay.sdk.android.publisher.currency.VirtualCurrencyConnector;

public class RequestNewCoinsFunction extends AbstractFunction {

	@Override
	public FREObject call(FREContext context, FREObject[] passedArgs) {

		final PublisherExtensionContext pubContext = (PublisherExtensionContext) context;
		Context appContext = pubContext.getActivity().getApplicationContext();

		try {
			String userId = passedArgs[0].getAsString();

			String overridingAppId = getNullFromString(passedArgs[1]);
			String securityToken = passedArgs[2].getAsString();
			
			String lastTranscationID = getNullFromString(passedArgs[3]);

			final String usedTransactionId = VirtualCurrencyConnector
					.fetchLatestTransactionId(appContext, overridingAppId,
							userId);
			SPCurrencyServerListener requestListener = new SPCurrencyServerListener() {
				@Override
				public void onSPCurrencyServerError(
						CurrencyServerAbstractResponse response) {
					String code = String.format("%s\n%s\n%s",
							response.getErrorType(), response.getErrorCode(),
							response.getErrorMessage());

					pubContext.dispatchStatusEventAsync(code, "RequestNewCoins:error");
				}

				@Override
				public void onSPCurrencyDeltaReceived(
						CurrencyServerDeltaOfCoinsResponse response) {
					String code = String.format("%s\n%s\n%s",
							response.getDeltaOfCoins(), usedTransactionId,
							response.getLatestTransactionId());
					pubContext.dispatchStatusEventAsync(code, "RequestNewCoins:response");
				}
			};

			try {
				SponsorPayPublisher.requestNewCoins(appContext, userId,
						requestListener, lastTranscationID, securityToken,
						overridingAppId);
			} catch (RuntimeException ex) {
				pubContext.dispatchStatusEventAsync(ex.getMessage(), "error");
				Log.e(this.getClass().toString(), "SponsorPay SDK Exception: ",
						ex);
			}
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (FRETypeMismatchException e) {
			e.printStackTrace();
		} catch (FREInvalidObjectException e) {
			e.printStackTrace();
		} catch (FREWrongThreadException e) {
			e.printStackTrace();
		}
		return null;
	}

}
