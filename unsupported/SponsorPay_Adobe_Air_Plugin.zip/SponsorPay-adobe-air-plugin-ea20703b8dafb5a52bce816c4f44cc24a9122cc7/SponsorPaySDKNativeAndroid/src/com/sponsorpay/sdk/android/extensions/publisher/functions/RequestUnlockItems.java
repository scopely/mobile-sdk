package com.sponsorpay.sdk.android.extensions.publisher.functions;

import org.json.JSONObject;

import android.content.Context;
import android.util.Log;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREInvalidObjectException;
import com.adobe.fre.FREObject;
import com.adobe.fre.FRETypeMismatchException;
import com.adobe.fre.FREWrongThreadException;
import com.sponsorpay.sdk.android.extensions.AbstractFunction;
import com.sponsorpay.sdk.android.extensions.publisher.PublisherExtensionContext;
import com.sponsorpay.sdk.android.publisher.AbstractResponse;
import com.sponsorpay.sdk.android.publisher.SponsorPayPublisher;
import com.sponsorpay.sdk.android.publisher.unlock.SPUnlockResponseListener;
import com.sponsorpay.sdk.android.publisher.unlock.UnlockedItemsResponse;

public class RequestUnlockItems extends AbstractFunction {

	@Override
	public FREObject call(FREContext context, FREObject[] passedArgs) {
		
		final PublisherExtensionContext pubContext = (PublisherExtensionContext) context;
		Context appContext = pubContext.getActivity().getApplicationContext();

		try {
			String userId = passedArgs[0].getAsString();
			String overridingAppId = getNullFromString(passedArgs[1]);
			String securityToken = passedArgs[2].getAsString();
			
			SPUnlockResponseListener listener = new SPUnlockResponseListener() {
				@Override
				public void onSPUnlockRequestError(AbstractResponse response) {
					String code = String.format("%s\n%s\n%s",
							response.getErrorType(), response.getErrorCode(), response
							.getErrorMessage());
					pubContext.dispatchStatusEventAsync(code, "RequestUnlockItems:error");
				}

				@Override
				public void onSPUnlockItemsStatusResponseReceived(UnlockedItemsResponse response) {
					JSONObject json = new JSONObject(response.getItems());					
					String code = json.toString(); 
					pubContext.dispatchStatusEventAsync(code, "RequestUnlockItems:response");
				}
			};

			try {
				// FIXME additional parameters
				SponsorPayPublisher.requestUnlockItemsStatus(appContext, userId,
						listener, securityToken, overridingAppId, null);
			} catch (RuntimeException ex) {
				pubContext.dispatchStatusEventAsync(ex.getMessage(), "error");
				Log.e(this.getClass().toString(), "SponsorPay SDK Exception: ",
						ex);
			}			
			

		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (FRETypeMismatchException e) {
			e.printStackTrace();
		} catch (FREInvalidObjectException e) {
			e.printStackTrace();
		} catch (FREWrongThreadException e) {
			e.printStackTrace();
		}
		

		return null;
	}

}
