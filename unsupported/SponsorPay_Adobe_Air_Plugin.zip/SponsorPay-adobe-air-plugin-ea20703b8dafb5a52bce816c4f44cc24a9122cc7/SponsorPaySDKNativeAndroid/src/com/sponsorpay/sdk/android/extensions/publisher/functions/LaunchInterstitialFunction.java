package com.sponsorpay.sdk.android.extensions.publisher.functions;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREInvalidObjectException;
import com.adobe.fre.FREObject;
import com.adobe.fre.FRETypeMismatchException;
import com.adobe.fre.FREWrongThreadException;
import com.sponsorpay.sdk.android.extensions.AbstractFunction;
import com.sponsorpay.sdk.android.extensions.publisher.PublisherExtensionContext;
import com.sponsorpay.sdk.android.publisher.InterstitialLoader.InterstitialLoadingStatusListener;
import com.sponsorpay.sdk.android.publisher.SponsorPayPublisher;

public class LaunchInterstitialFunction extends AbstractFunction {

	@Override
	public FREObject call(FREContext context, FREObject[] passedArgs) {
		final PublisherExtensionContext pubContext = (PublisherExtensionContext) context;
		
		try {
			//args passed in that order
			String userId = passedArgs[0].getAsString();
			boolean shouldStayOpen = passedArgs[1].getAsBool();
			String backgroundUrl = getNullFromString(passedArgs[2]);
			
			String skinName = getNullFromString(passedArgs[3]);
			
			int loadingTimeout = passedArgs[4].getAsInt();
			String overridingAppId = getNullFromString(passedArgs[5]);
			
			SponsorPayPublisher.loadShowInterstitial(pubContext.getActivity(), userId,
					new InterstitialLoadingStatusListener() {

						@Override
						public void onInterstitialLoadingTimeOut() {
							pubContext.dispatchStatusEventAsync("onInterstitialLoadingTimeOut", "Interstitial");
						}

						@Override
						public void onInterstitialRequestError() {
							pubContext.dispatchStatusEventAsync("onInterstitialRequestError", "Interstitial");
						}

						@Override
						public void onNoInterstitialAvailable() {
							pubContext.dispatchStatusEventAsync("onNoInterstitialAvailable", "Interstitial");
						}

						@Override
						public void onWillShowInterstitial() {
							pubContext.dispatchStatusEventAsync("onWillShowInterstitial", "Interstitial");
						}

					}, shouldStayOpen, backgroundUrl, skinName, loadingTimeout, overridingAppId);
			
			
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (FRETypeMismatchException e) {
			e.printStackTrace();
		} catch (FREInvalidObjectException e) {
			e.printStackTrace();
		} catch (FREWrongThreadException e) {
			e.printStackTrace();
		}
		
		return null;
	}

}
