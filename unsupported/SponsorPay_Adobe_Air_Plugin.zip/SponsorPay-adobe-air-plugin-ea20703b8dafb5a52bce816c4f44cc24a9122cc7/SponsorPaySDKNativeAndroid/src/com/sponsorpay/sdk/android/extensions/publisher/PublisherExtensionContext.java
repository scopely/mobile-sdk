package com.sponsorpay.sdk.android.extensions.publisher;

import java.util.HashMap;
import java.util.Map;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.sponsorpay.sdk.android.extensions.publisher.functions.LaunchUnlockOfferWall;
import com.sponsorpay.sdk.android.extensions.publisher.functions.RequestNewCoinsFunction;
import com.sponsorpay.sdk.android.extensions.publisher.functions.LaunchInterstitialFunction;
import com.sponsorpay.sdk.android.extensions.publisher.functions.LaunchOfferWallFunction;
import com.sponsorpay.sdk.android.extensions.publisher.functions.RequestUnlockItems;

public class PublisherExtensionContext extends FREContext {

	@Override
	public void dispose() {
	}

	@Override
	public Map<String, FREFunction> getFunctions() {
		Map<String, FREFunction> functionMap = new HashMap<String, FREFunction>();
		
		functionMap.put("launchOfferWall", new LaunchOfferWallFunction());
		functionMap.put("launchInterstitial", new LaunchInterstitialFunction());
		functionMap.put("requestNewCoins", new RequestNewCoinsFunction());
		functionMap.put("launchUnlockOfferWall", new LaunchUnlockOfferWall());
		functionMap.put("requestUnlockItems", new RequestUnlockItems());
	    return functionMap;
	}

}
