package com.sponsorpay.sdk.android.extensions.advertiser.functions;

import android.content.Context;
import android.util.Log;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREInvalidObjectException;
import com.adobe.fre.FREObject;
import com.adobe.fre.FRETypeMismatchException;
import com.adobe.fre.FREWrongThreadException;
import com.sponsorpay.sdk.android.advertiser.SponsorPayAdvertiser;
import com.sponsorpay.sdk.android.extensions.AbstractFunction;
import com.sponsorpay.sdk.android.extensions.advertiser.AdvertiserExtensionContext;

public class SendCallbackFunction extends AbstractFunction {

	@Override
	public FREObject call(FREContext context, FREObject[] passedArgs) {
		
		AdvertiserExtensionContext advertiserContext = (AdvertiserExtensionContext) context;
		Context appContext = advertiserContext.getActivity().getApplicationContext();
		
		//args passed in that order
		try {
			String overridingAppId = getNullFromString(passedArgs[0]);

			SponsorPayAdvertiser.register(appContext, overridingAppId);
			
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (FRETypeMismatchException e) {
			e.printStackTrace();
		} catch (FREInvalidObjectException e) {
			e.printStackTrace();
		} catch (FREWrongThreadException e) {
			e.printStackTrace();
		} catch (RuntimeException ex) {
			advertiserContext.dispatchStatusEventAsync(ex.getMessage(), "error");
			Log.e(this.getClass().toString(), "SponsorPay SDK Exception: ",
					ex);
		}
		return null;
	}

}
