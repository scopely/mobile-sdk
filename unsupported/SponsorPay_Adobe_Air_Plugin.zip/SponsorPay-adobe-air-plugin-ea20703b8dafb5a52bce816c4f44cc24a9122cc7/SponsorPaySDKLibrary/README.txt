SponsorPaySDKLibrary is a native extension for use with Adobe AIR.
It provides the following features from the native SDK:
- Offerwall
- Unlock Offerwall
- Vicrtual Currency Server
- Advertiser Callback


Requirements:
=============

Adobe Flash Builder 4.6 IDE


Getting Started:
================

1) Download the latest SponsorPaySDKLibrary.ane

2) On your Flex project, click on "Porperties"

3) Go to "Flex Build Path" and "NAtive Exetnsions" tab 

4) Click on "Add ANE..." and browse to the download location of the SponsorPaySDKLibrary.ane file, select and click "Finish".

5) Check that the Native extension is exported when you package your application. On the project's properties, select "Flex Build Packaging" and "Google Android". On the "Native Extensions" tab, SponsorPaySDKLibrary should be present and check "Package". Click "OK".