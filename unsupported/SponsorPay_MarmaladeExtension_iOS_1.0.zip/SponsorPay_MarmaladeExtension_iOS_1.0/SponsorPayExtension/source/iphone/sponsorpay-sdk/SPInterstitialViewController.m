//
//  SPInterstitialViewController.m
//  SponsorPay iOS SDK
//
//  Copyright 2011 SponsorPay. All rights reserved.
//

#import "SPInterstitialViewController.h"
#import "SPUrlFactory.h"
#import "SP_SDK_versions.h"
#import "SP_URL_scheme.h"
#import "SPPersistence.h"
#import "NSURL+Parsing.h"
#import "NSString+Escaping.h"

#define DEFAULT_SKIN_VALUE @"DEFAULT"

#pragma mark url params exclusive to the interstitial
#define URL_PARAM_INTERSTITIAL_TRAILING_KEY     @"interstitial"
#define URL_PARAM_INTERSTITIAL_TRAILING_VALUE   @"on"
#pragma mark -

#pragma mark animation parameters
#define INTRO_ANIMATION_LENGTH_FOR_INTERSTITIAL_WEBVIEW (1.0)
#define OUTRO_ANIMATION_LENGTH_FOR_INTERSTITIAL_WEBVIEW (0.5)
#define INTERSTITIAL_WEBVIEW_OUTRO_ANIMATION_ID @"INTERSTITIAL_WEBVIEW_OUTRO_ANIMATION_ID"
#pragma mark -

#define DEFAULT_LOADING_TIMEOUT_SECONDS (5.0)

// The base url to retrieve the interstitial from
#define INTERSTITIAL_BASE_URL @"https://iframe.sponsorpay.com/mobile"

#define SHOULD_INTERSTITIAL_FINISH_ON_REDIRECT_DEFAULT YES

static int offsetCounter = 0;
static NSString *interstitialBaseUrl = INTERSTITIAL_BASE_URL;

#pragma mark private methods and properties
@interface SPInterstitialViewController()
- (void)loadInterstitialWithTimeout:(NSTimeInterval)timeout;
- (void)loadUrl:(NSString *) urlAddress;
- (void)animateLoadingViewIn;
- (void)animateLoadingViewOut;
- (void)animateInterstitialWebViewIn;
- (void)animateInterstitialWebViewOut;
- (void)animationDidStop:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context;
- (void)closeInterstitialViewWithAnimation:(BOOL)shouldAnimate;
- (CGRect)frameForInterstitial;
- (CGPoint)centerForInterstitial;
- (void)notifyDelegateOfStatus:(SPInterstitialViewControllerStatus)status;
- (void)cancelInterstitialRequestDueToTimeout;
+ (BOOL)isInterstitialAvailableAccordingToHttpStatusCode:(int)statusCode;

@property (readonly) UIWebView *interstitialWebView;
@property (readonly) SPLoadingProgressViewController *loadingProgressView;

@end
#pragma mark -

@implementation SPInterstitialViewController

#pragma mark synthesized properties
@synthesize appId;
@synthesize userId;
@synthesize skin;
@synthesize backgroundImageUrl;

@synthesize delegate;
@synthesize shouldFinishOnRedirect;

@synthesize customParameters;

#pragma mark -

#pragma mark manually implemented property accesors
- (SPLoadingProgressViewController *)loadingProgressView {
    if (nil == loadingProgressView)
        loadingProgressView = [[SPLoadingProgressViewController alloc] init];
    return loadingProgressView;
}

/**
 * Initializes, configures, caches and returns the WebView.
 */
- (UIWebView *)interstitialWebView {
    if (nil == interstitialWebView) {
        interstitialWebView = [[UIWebView alloc]
                               initWithFrame:[self frameForInterstitial]];
        interstitialWebView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;

        interstitialWebView.delegate = self;
    }
    return interstitialWebView;
}
#pragma mark -

#pragma mark public methods
- (id)initWithUserId:(NSString *)theUserId
               appId:(NSString *)theAppId {
    
    return [self initWithUserId:theUserId
                          appId:theAppId
                  backgroundUrl:nil
                           skin:DEFAULT_SKIN_VALUE
                  loadingTimeout:DEFAULT_LOADING_TIMEOUT_SECONDS];
}

- (id)initWithUserId:(NSString *)theUserId
               appId:(NSString *)theAppId 
       backgroundUrl:(NSString *)theBackgroundUrl
                skin:(NSString *)theSkinName {
	
	return [self initWithUserId:theUserId
                          appId:theAppId
                  backgroundUrl:theBackgroundUrl
                           skin:theSkinName 
                  loadingTimeout:DEFAULT_LOADING_TIMEOUT_SECONDS];
}

- (id)initWithUserId:(NSString *)theUserId
               appId:(NSString *)theAppId
       backgroundUrl:(NSString *)theBackgroundUrl
                skin:(NSString *)theSkinName
      loadingTimeout:(NSTimeInterval)loadingTimeOut {

	if ((self = [super init])) {
        self.userId = theUserId;
        self.appId = theAppId;
        self.skin = theSkinName;
        
        
        self.backgroundImageUrl = theBackgroundUrl;
        self.shouldFinishOnRedirect = SHOULD_INTERSTITIAL_FINISH_ON_REDIRECT_DEFAULT;
        requestStatus = NOT_WAITING;
        [self loadInterstitialWithTimeout:loadingTimeOut];
    }
    
    return self;
}

- (BOOL)cancelInterstitialRequest {
    BOOL didCancelRequestOrLoading;
    switch (requestStatus) {
        case WAITING_FOR_INITIAL_REQUEST_RESPONSE:
            [initialRequestConnection cancel];
            [initialRequestConnection release];
            initialRequestConnection = nil;
            [self animateLoadingViewOut];
            didCancelRequestOrLoading = YES;
            break;
        case WAITING_FOR_WEBVIEW_TO_LOAD_INITIAL_CONTENTS:
            [self.interstitialWebView stopLoading];
            [self animateLoadingViewOut];
            didCancelRequestOrLoading = YES;
            break;
        default:
        case NOT_WAITING:
            didCancelRequestOrLoading = NO;
            break;
    }
    return didCancelRequestOrLoading;
}

#pragma mark -

#pragma mark loading

/**
 * Sends the initial request for the interstitial and registers a cancel on timeout timer. 
 */
- (void)loadInterstitialWithTimeout:(NSTimeInterval)timeout {
    
    [self animateLoadingViewIn];
    
    isRedirecting = NO;
    
    SPUrlFactory *urlFactory = [SPUrlFactory urlFactoryWithDefaultParametersProvidersWithBaseUrl:interstitialBaseUrl
                                                                 shouldUseSystemDeviceIdentifier:[SPPersistence mayAccessSystemDeviceIdentifier]];
    
    [urlFactory addKey:URL_PARAM_APP_ID withValue:self.appId];
    [urlFactory addKey:URL_PARAM_USER_ID withValue:self.userId];
    [urlFactory addKey:URL_PARAM_SKIN withValue:self.skin];
    
    [urlFactory addKey:URL_PARAM_INTERSTITIAL_TRAILING_KEY
             withValue:URL_PARAM_INTERSTITIAL_TRAILING_VALUE];    
    [urlFactory addKey:URL_PARAM_ALLOW_CAMPAIGN
             withValue:URL_PARAM_ALLOW_CAMPAIGN_VALUE_ON];
    [urlFactory addKey:URL_PARAM_OFFSET withIntegerValue:offsetCounter];
    
    [urlFactory addKeyValuePairsFromDictionary:customParameters];
    
    if (self.backgroundImageUrl && [self.backgroundImageUrl length]) {
        [urlFactory addKey:URL_PARAM_BACKGROUND
                 withValue:self.backgroundImageUrl];
    }
    
    [urlFactory addDeviceInfo];
    
    NSString *urlString = [urlFactory urlString];
	    
    NSLog(@"SponsorPay Mobile Interstitial will be requested using url: %@", urlString);

	[self loadUrl:urlString];
    [self performSelector:@selector(cancelInterstitialRequestDueToTimeout)
               withObject:nil
               afterDelay:timeout];
}

/**
 * Starts the asynchronous load of a URL (as initial request for the interstitial)
 * through a NSURLRequest object, registering this instance as a delegate of the request. 
 */
-(void)loadUrl:(NSString *) urlAddress {
	if (initialRequestConnection) {
        [initialRequestConnection cancel];
        [initialRequestConnection release];
    }
    NSURL *url = [NSURL URLWithString:urlAddress];
	NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
	initialRequestConnection = [NSURLConnection connectionWithRequest:requestObj delegate:self];
    [initialRequestConnection retain];
    requestStatus = WAITING_FOR_INITIAL_REQUEST_RESPONSE;
}

/**
 * Called when the timeout timer for the loading of the interstitial goes off. 
 * Cancels the loading request and notifies the SPInterstitialViewControllerDelegate.
 */
-(void)cancelInterstitialRequestDueToTimeout {
    if (requestStatus != NOT_WAITING) {
        [self cancelInterstitialRequest];
        [self notifyDelegateOfStatus:ERROR_TIMEOUT];
    }
 }

#pragma mark -

#pragma mark animation and view hierarchy manipulation methods
- (void)animateLoadingViewIn {
    [self.view addSubview: self.loadingProgressView.view];

    loadingProgressView.view.alpha = INITIAL_ALPHA_FOR_LOADING_VIEW;
    CGPoint animOriginPoint;
    animOriginPoint.x = [self centerForInterstitial].x;
    animOriginPoint.y = [self frameForInterstitial].size.height;
    loadingProgressView.view.center = animOriginPoint;
    
    if ([[UIView class] respondsToSelector:@selector(animateWithDuration:animations:)]) {
        // Apply block-based animations
        [UIView animateWithDuration:INTRO_ANIMATION_LENGTH_FOR_LOADING_VIEW
                         animations:^{
                             loadingProgressView.view.center = [self centerForInterstitial];  
                             loadingProgressView.view.alpha = FINAL_ALPHA_FOR_LOADING_VIEW;
                         }
         ];
    } else {
        // Use beginAnimations:context: / commitAnimations animation methods
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:INTRO_ANIMATION_LENGTH_FOR_LOADING_VIEW];
        loadingProgressView.view.center = [self centerForInterstitial];  
        loadingProgressView.view.alpha = FINAL_ALPHA_FOR_LOADING_VIEW;
        [UIView commitAnimations];
    }
    
}

- (void)animateLoadingViewOut {
    if ([[UIView class] respondsToSelector:@selector(animateWithDuration:animations:)]) {
        // Apply block-based animations
        [UIView animateWithDuration:OUTRO_ANIMATION_LENGTH_FOR_LOADING_VIEW
                         animations:^{
                             self.loadingProgressView.view.alpha = INITIAL_ALPHA_FOR_LOADING_VIEW;
                         }
                         completion:^(BOOL finished){
                             [self.loadingProgressView.view removeFromSuperview];
                         }
         ];
    } else {
        // Use beginAnimations:context: / commitAnimations animation methods
        [UIView beginAnimations:LOADING_VIEW_OUTRO_ANIMATION_ID context:NULL];
        [UIView setAnimationDuration:OUTRO_ANIMATION_LENGTH_FOR_LOADING_VIEW];
        
        self.loadingProgressView.view.alpha = INITIAL_ALPHA_FOR_LOADING_VIEW;
        
        [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
        [UIView commitAnimations];
    }
}

- (void)animateInterstitialWebViewIn {
    [self.view addSubview:self.interstitialWebView];
    
    CGPoint animInitCenterPoint;
    CGPoint center = [self centerForInterstitial];
    CGRect frame = [self frameForInterstitial];
    
    animInitCenterPoint.x = center.x;
    animInitCenterPoint.y = frame.size.height + (self.interstitialWebView.frame.size.height / 2);
    
    self.interstitialWebView.center = animInitCenterPoint;
    if ([[UIView class] respondsToSelector:@selector(animateWithDuration:animations:)]) {
        // Apply block-based animations
        [UIView animateWithDuration:INTRO_ANIMATION_LENGTH_FOR_INTERSTITIAL_WEBVIEW
                         animations:^{
                             self.interstitialWebView.center = [self centerForInterstitial];
                         }
         ];
    } else {
        // Use beginAnimations:context: / commitAnimations animation methods
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:INTRO_ANIMATION_LENGTH_FOR_INTERSTITIAL_WEBVIEW];
        
        self.interstitialWebView.center = [self centerForInterstitial];
        
        [UIView commitAnimations];
    }
}

- (void)animateInterstitialWebViewOut {
    CGPoint hideInterstitialCenterPoint;
    CGPoint center = [self centerForInterstitial];
    CGRect frame = [self frameForInterstitial];
    
    hideInterstitialCenterPoint.x = center.x;
    hideInterstitialCenterPoint.y = frame.size.height + (self.interstitialWebView.frame.size.height / 2);
    
    if ([[UIView class] respondsToSelector:@selector(animateWithDuration:animations:)]) {
        // Apply block-based animations
        [UIView animateWithDuration:OUTRO_ANIMATION_LENGTH_FOR_INTERSTITIAL_WEBVIEW
                         animations:^{
                             self.interstitialWebView.center = hideInterstitialCenterPoint;
                         }
                         completion:^(BOOL finished){
                             [self closeInterstitialViewWithAnimation:NO];
                         }
         ];
    } else {
        // Use beginAnimations:context: / commitAnimations animation methods
        [UIView beginAnimations:INTERSTITIAL_WEBVIEW_OUTRO_ANIMATION_ID context:NULL];
        [UIView setAnimationDuration:OUTRO_ANIMATION_LENGTH_FOR_INTERSTITIAL_WEBVIEW];

        self.interstitialWebView.center = hideInterstitialCenterPoint;
        
        [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
        [UIView commitAnimations];

    }
}

-(void)animationDidStop:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context {
    if ([animationID isEqualToString:LOADING_VIEW_OUTRO_ANIMATION_ID]) {
        [self.loadingProgressView.view removeFromSuperview];
    } else if ([animationID isEqualToString:INTERSTITIAL_WEBVIEW_OUTRO_ANIMATION_ID]) {
        [self closeInterstitialViewWithAnimation:NO];
    }
}

-(void)closeInterstitialViewWithAnimation:(BOOL)shouldAnimate {
    NSLog(@"closeInterstitialViewWithAnimation: %d called", shouldAnimate);
    
    if (shouldAnimate) {
        [self animateInterstitialWebViewOut];
    } else {
        [self.interstitialWebView removeFromSuperview];
        [self notifyDelegateOfStatus:CLOSED];
    }
}
#pragma mark -

#pragma mark NSURLConnection delegate methods
/**
 * On interstitial request error, will hide the loading progress view, release the request
 * connection object, and notify the registered SPInterstitialViewControllerDelegate of an
 * ERROR_NETWORK condition.
 **/
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    [self animateLoadingViewOut];
    [self notifyDelegateOfStatus:ERROR_NETWORK];
    [initialRequestConnection release];
    initialRequestConnection = nil;
}

/**
 * Appends received interstitial request connection data to be loaded into the WebView when
 * the request finishes succesfully.
 **/
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    if (downloadedInterstitialData) {
        [downloadedInterstitialData appendData:data];
    } else {
        downloadedInterstitialData = [[NSMutableData dataWithData:data] retain];
    }
}

/**
 * Called on initial response to the interstitial request.
 */
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)theResponse {
    if ([theResponse isMemberOfClass:[NSHTTPURLResponse class]]) {
        urlResponse = (NSHTTPURLResponse *)[theResponse retain];
    } else
        NSLog(@"theResponse is NOT MemberOfClass NSHTTPURLResponse");
    
}

/**
 * Called when the interstitial load request finishes. If an interstitial is returned, it will load
 * it into the webview to show it to the user afterwards. Otherwise, it will hide the loading progress
 * view and notify the SPInterstitialViewControllerDelegate
 */
- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    int statusCode = [urlResponse statusCode];
    
    if ([SPInterstitialViewController isInterstitialAvailableAccordingToHttpStatusCode:statusCode]) {

        [self.interstitialWebView loadData:downloadedInterstitialData
                                  MIMEType:[urlResponse MIMEType]
                          textEncodingName:[urlResponse textEncodingName] 
                                   baseURL:[urlResponse URL]];
        offsetCounter ++;
        requestStatus = WAITING_FOR_WEBVIEW_TO_LOAD_INITIAL_CONTENTS;
    } else {
        [self animateLoadingViewOut];
        [self notifyDelegateOfStatus:NO_INTERSTITIAL_AVAILABLE];
        requestStatus = NOT_WAITING;
    }

    [downloadedInterstitialData release];
    downloadedInterstitialData = nil;

    [urlResponse release];
    urlResponse = nil;
    
    [initialRequestConnection release];
    initialRequestConnection = nil;
}

- (NSURLRequest *)connection:(NSURLConnection *)connection
             willSendRequest:(NSURLRequest *)request
            redirectResponse:(NSURLResponse *)redirectResponse {
    return request;
}
#pragma mark -

#pragma mark UIWebViewDelegate methods
/**
 * On WebView loading error, will hide the loading progress view (which is not hidden until the
 * WebView is shown, and the WebView is not shown until its loading is completed) and notify the
 * registered SPInterstitialViewControllerDelegate of an ERROR_NETWORK condition.
 **/
    - (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
    // Error -999 is triggered when the WebView starts a request before the previous one was completed.
    // We assume this kind of error can be safely ignored.
    if ([error code] != -999) {
        
        if (!isRedirecting) {
            NSLog(@"WebView did fail load with error: %@", error);
            
            [self closeInterstitialViewWithAnimation:YES];
            [self animateLoadingViewOut];
            
            [self notifyDelegateOfStatus:ERROR_NETWORK];
        }
    
    }
}


/**
 * Selector from the UIWebViewDelegate protocol. Captures the links on which the user
 * clicks and intercepts those which start with the defined SPONSORPAY_URL_SCHEME in order
 * to close the WebView and / or redirect the user outside the app (i.e. to the App Store)
 **/
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    
	NSURL *url = [request URL];

    NSLog(@"shouldStartLoadWithRequest called with URL: %@", url);
	
    BOOL continueLoading = YES;
	
	if ([[url scheme] isEqualToString:SPONSORPAY_URL_SCHEME]) {
		
		// The path must be preceeded by '//', '/' or ':' are unacceptable
		NSString *path = [url host];
		
		if ([path isEqualToString:SPONSORPAY_EXIT_PATH]) {
			continueLoading = NO;
            
			NSDictionary *queryDict = [url queryDictionary];
			NSString *destination = [[queryDict valueForKey:@"url"] stringWithPercentUnescape];
                    
            BOOL isDestinationMissing = (destination == nil) || [destination isEqualToString:@""];
            
            isRedirecting = !isDestinationMissing;
            
			BOOL shouldFinish = isDestinationMissing || self.shouldFinishOnRedirect;
			NSLog(@"shouldFinish = %d, isDestinationMissing = %d, shouldFinishOnRedirect = %d",
                  shouldFinish, isDestinationMissing, shouldFinishOnRedirect);
            if (shouldFinish) {
                [self closeInterstitialViewWithAnimation:!isRedirecting];
            }
            			
			if (isRedirecting)
                [[UIApplication sharedApplication] openURL: [NSURL URLWithString:destination]];
		}
	}
	
	return continueLoading;
}

/**
 * Called when the complete interstitial has been loaded into the WebView, including its dependencies
 * like images, javascript files, etc. Hides the loading progress view and shows
 * the interstitial webview. When the webview finishes loading its initial contents, it will notify
 * the registered SPInterstitialViewControllerDelegate.
 */
- (void)webViewDidFinishLoad:(UIWebView *)webView {
    if (requestStatus == WAITING_FOR_WEBVIEW_TO_LOAD_INITIAL_CONTENTS) {
        [self animateLoadingViewOut];
        [self animateInterstitialWebViewIn];
        [self notifyDelegateOfStatus:AD_SHOWN];
        requestStatus = NOT_WAITING;
    }
}
#pragma mark -

#pragma mark frame and center for interstitial
- (CGRect)frameForInterstitial {
//    return [[UIScreen mainScreen] applicationFrame];
    return self.view.frame;
}
- (CGPoint)centerForInterstitial {
//    CGPoint pointToReturn;
//    CGRect frame = [self frameForInterstitial];
//    pointToReturn.x = frame.origin.x + (frame.size.width / 2);
//    pointToReturn.y = frame.origin.y + (frame.size.height / 2);
    
    return self.view.center;
}
#pragma mark -

#pragma mark delegate notification
-(void)notifyDelegateOfStatus:(SPInterstitialViewControllerStatus)status {
    if (self.delegate && [self.delegate respondsToSelector:@selector(interstitialViewController:didChangeStatus:)]) {
        [delegate interstitialViewController:self didChangeStatus:status];
    }
}
#pragma mark -

#pragma mark static methods
+ (BOOL)isInterstitialAvailableAccordingToHttpStatusCode:(int)statusCode {
    // "OK" and "Redirect" codes mean we've got an interstitial
    return statusCode >= 200 && statusCode < 400;
}
#pragma mark -

#pragma mark UIViewController overriden methods
/**
 * Overriden from UIViewController.
 * Returns a Boolean value indicating whether the view controller supports the specified orientation.
 * As all orientations are supported, returns always YES.
 **/
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return YES;
}

/**
 * Overriden from UIViewController.
 * Creates the view that the controller manages.
 **/
- (void)loadView {
    // full screen view
    CGPoint origin = {0, 0};
    CGRect applicationFrame = [[UIScreen mainScreen] applicationFrame];
	
    CGSize sizeForView;
    UIInterfaceOrientation currentOrientation = [UIDevice currentDevice].orientation;

    if (currentOrientation == UIInterfaceOrientationLandscapeLeft
        || currentOrientation == UIInterfaceOrientationLandscapeRight) {
        sizeForView.width = applicationFrame.size.height;
        sizeForView.height = applicationFrame.size.width;
    } else {
        sizeForView = applicationFrame.size;
    }
    
    CGRect viewFrame = {origin, sizeForView};

    self.view = [[UIView alloc] initWithFrame:viewFrame];
    self.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
}
#pragma mark -

+ (void)overrideBaseUrlWithUrl:(NSString *)newUrl {
    [interstitialBaseUrl release];
    interstitialBaseUrl = [newUrl retain];
}

+ (void)restoreBaseUrlToDefault {
    [SPInterstitialViewController overrideBaseUrlWithUrl:INTERSTITIAL_BASE_URL];
}

#pragma mark memory management
- (void)dealloc {
    [NSObject cancelPreviousPerformRequestsWithTarget: self];
    self.appId = nil;
    self.userId = nil;
    if (loadingProgressView) {
        [loadingProgressView release];
    }
    if (interstitialWebView) {
        [interstitialWebView release];
    }
    [customParameters release];
    self.skin = nil;
    self.backgroundImageUrl = nil;
    self.delegate = nil;
    if (initialRequestConnection) {
        [initialRequestConnection release];
    }
    if (downloadedInterstitialData) {
        [downloadedInterstitialData release];
    }
    if (urlResponse) {
        [urlResponse release];
    }
    
    [super dealloc];
}
#pragma mark -
@end
