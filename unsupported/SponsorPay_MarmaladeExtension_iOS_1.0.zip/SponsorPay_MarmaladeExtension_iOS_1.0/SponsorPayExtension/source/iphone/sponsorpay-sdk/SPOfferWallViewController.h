//
//  SPOfferWallViewController.h
//  SponsorPay iOS SDK
//
//  Copyright 2011 SponsorPay. All rights reserved.
//


#import <UIKit/UIKit.h>
#import "SPLoadingProgressViewController.h"

/** value to return when there is a network error */
#define SPONSORPAY_ERR_NETWORK  -1

/**
 * This is a UIViewController that will handle communicating with the SponsorPay
 * server and display an offer wall to the user.
 *
 * Delegates of this controller receive a callback either when the user exits the
 * offer wall or when the user selects an offer and is sent to the App Store.
 */
@interface SPOfferWallViewController : UIViewController <UIWebViewDelegate> {

	UIWebView *webView;
	NSString *appId;
	NSString *userId;
//	NSError *lastNetworkError;
    
	BOOL isRedirecting;
	id delegate;
	
	BOOL shouldFinishOnRedirect;
    
    SPLoadingProgressViewController *loadingProgressView;
    
    NSDictionary *customParameters;
}

/** The application ID to send to SponsorPay */
@property (nonatomic, retain) NSString *appId;

/** The userID to send to SponsorPay */
@property (nonatomic, retain) NSString *userId;

/** The delegate to make callbacks to. Must conform to SPOfferWallViewControllerDelegate protocol */
@property (nonatomic, assign) id delegate;

/** Whether the offerwall should close after the user is redirected outside the app **/
@property (readwrite) BOOL shouldFinishOnRedirect;

@property (nonatomic, retain) NSDictionary *customParameters;

-(id) initWithUserId:(NSString *) _userId
               appId:(NSString *)_appId
    customParameters:(NSDictionary *)_customParameters;
    
/** Initialize the view controller with the userId and appId */
-(id) initWithUserId:(NSString *)userId appId:(NSString *)appId;

+ (void)overrideBaseUrlWithUrl:(NSString *)newUrl;
+ (void)restoreBaseUrlToDefault;

@end

/**
 * Protocol for the delegate of the publisher SDK to receive callbacks.
 */
@protocol SPOfferWallViewControllerDelegate
@optional
/**
 * Delegates will receive this callback when the view controller is finished.  Status will be a
 * value of SPONSORPAY_ERR_NETWORK if there was a network error.
 */
- (void)offerWallViewController:(SPOfferWallViewController *)offerwallVC isFinishedWithStatus:(int) status;

@end
