//  SP_SDK_versions.h
//  SponsorPay iOS SDK
//
//  Copyright 2011 SponsorPay. All rights reserved.
//


// SponsorPay iOS SDK v. 2.0.3
#define SP_SDK_MAJOR_RELEASE_VERSION_NUMBER 2
#define SP_SDK_MINOR_RELEASE_VERSION_NUMBER 0
#define SP_SDK_FIX_RELEASE_VERSION_NUMBER 3
