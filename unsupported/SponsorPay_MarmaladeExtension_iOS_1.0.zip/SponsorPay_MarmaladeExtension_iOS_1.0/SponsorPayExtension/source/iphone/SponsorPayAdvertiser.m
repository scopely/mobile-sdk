//
//  SponsorPayAdvertiser.m
//  SponsorPaySDKNativeiOS
//
//  Created by David on 8/1/12.
//  Copyright 2012 SponsorPay GmbH. All rights reserved.
//

#import "SponsorPayAdvertiser.h"
#import "SPAdvertiserManager.h"

@implementation SponsorPayAdvertiser


- (void) sendAdvertiserCallback:(NSString *)appId
{
	[[SPAdvertiserManager sharedManager] reportOfferCompleted:appId];
}



@end
