/*
Generic implementation of the SponsorPayExtension extension.
This file should perform any platform-indepedentent functionality
(e.g. error checking) before calling platform-dependent implementations.
*/

/*
 * NOTE: This file was originally written by the extension builder, but will not
 * be overwritten (unless --force is specified) and is intended to be modified.
 */


#include "SponsorPayExtension_internal.h"
s3eResult SponsorPayExtensionInit()
{
    //Add any generic initialisation code here
    return SponsorPayExtensionInit_platform();
}

void SponsorPayExtensionTerminate()
{
    //Add any generic termination code here
    SponsorPayExtensionTerminate_platform();
}

s3eResult SP_SendAdvertiserCallbackNow(const char* appId)
{
	return SP_SendAdvertiserCallbackNow_platform(appId);
}

s3eResult SP_LaunchOfferWall(const char* appId, const char* userId)
{
	return SP_LaunchOfferWall_platform(appId, userId);
}

s3eResult SP_LaunchInterstitial(const char* appId, const char* userId)
{
	return SP_LaunchInterstitial_platform(appId, userId);
}

s3eResult SP_RequestNewCoins(const char* appId, const char* userId, const char* securityToken)
{
	return SP_RequestNewCoins_platform(appId, userId, securityToken);
}
