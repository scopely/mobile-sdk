#include <cstdlib>
#include <sstream>

#include "s3e.h"
#include "IwUI.h"
#include "SponsorPayExtension.h"

// Attempt to lock to 25 frames per second.
#define MS_PER_FRAME (1000 / 25)

CIwUITextField* s_AppIDTextField = NULL;
CIwUITextField* s_DelayTextField = NULL;
CIwUITextField* s_UserIDTextField = NULL;
CIwUITextField* s_SecurityTokenTextField = NULL;
CIwUITextField* s_CustomCurrencyNameTextField = NULL;
CIwUITextField* s_ItemIDTextField = NULL;
CIwUITextField* s_ItemNameTextField = NULL;

CIwUILabel* s_ResponseContentsLabel = NULL;
//CIwUILabel* s_TestResultsLabel = NULL;

int32 onSponsorPayExtensionCallbackReceived (void* systemData, void* userData);
const char* getEnteredAppID();
const int32 getEnteredDelay();
const char* getEnteredUserID();
const char* getEnteredSecurityToken();
const char* getEnteredCustomCurrencyName();
const char* getEnteredItemID();
const char* getEnteredItemName();

int32 onSPDeltaOfCoinsSuccessfulResponse (void* systemData, void* userData);
int32 onSPDeltaOfCoinsRequestError (void* systemData, void* userData);
int32 onSPUnlockStatusRequestSuccess (void* systemData, void* userData);
int32 onSPUnlockStatusRequestError (void* systemData, void* userData);

//-----------------------------------------------------------------------------
class SendAdvertiserCallbackButtonEventHandler : public CIwUIElementEventHandler
{
public:
    virtual bool HandleEvent(CIwEvent* pEvent)
    {
        if (pEvent->GetID() == IWUI_EVENT_BUTTON)
        {
            SP_SendAdvertiserCallbackNow(getEnteredAppID());
            return true;
        }

        return false;
    }
};

class SendAdvertiserCallbackWithDelayButtonEventHandler : public CIwUIElementEventHandler
{
public:
    virtual bool HandleEvent(CIwEvent* pEvent)
    {
        if (pEvent->GetID() == IWUI_EVENT_BUTTON)
        {
            SP_SendAdvertiserCallbackWithDelay(getEnteredAppID(), getEnteredDelay());
            return true;
        }

        return false;
    }
};

class LaunchOfferWallButtonEventHandler : public CIwUIElementEventHandler
{
public:
    virtual bool HandleEvent(CIwEvent* pEvent)
    {
        if (pEvent->GetID() == IWUI_EVENT_BUTTON)
        {
            SP_LaunchOfferWall(getEnteredAppID(), getEnteredUserID());
            return true;
        }

        return false;
    }
};
class LaunchInterstitialButtonEventHandler : public CIwUIElementEventHandler
{
public:
    virtual bool HandleEvent(CIwEvent* pEvent)
    {
        if (pEvent->GetID() == IWUI_EVENT_BUTTON)
        {
            SP_LaunchInterstitial(getEnteredAppID(), getEnteredUserID());
            return true;
        }

        return false;
    }
};
class GetDeltaOfCoinsButtonEventHandler : public CIwUIElementEventHandler
{
public:
    virtual bool HandleEvent(CIwEvent* pEvent)
    {
        if (pEvent->GetID() == IWUI_EVENT_BUTTON)
        {
            SP_RequestNewCoins(getEnteredAppID(), getEnteredUserID(), getEnteredSecurityToken());
            return true;
        }

        return false;
    }
};
class RequestShowOfferBannerButtonEventHandler : public CIwUIElementEventHandler
{
public:
    virtual bool HandleEvent(CIwEvent* pEvent)
    {
        if (pEvent->GetID() == IWUI_EVENT_BUTTON)
        {
            SP_RequestOfferBanner(getEnteredAppID(), getEnteredUserID(), getEnteredCustomCurrencyName());
            return true;
        }

        return false;
    }
};
class LaunchUnlockOfferWallButtonEventHandler : public CIwUIElementEventHandler
{
public:
    virtual bool HandleEvent(CIwEvent* pEvent)
    {
        if (pEvent->GetID() == IWUI_EVENT_BUTTON)
        {
            SP_LaunchUnlockOfferWall(getEnteredAppID(), getEnteredUserID(),
                                     getEnteredItemID(), getEnteredItemName());
            return true;
        }

        return false;
    }
};
class RequestUnlockStatusButtonEventHandler : public CIwUIElementEventHandler
{
public:
    virtual bool HandleEvent(CIwEvent* pEvent)
    {
        if (pEvent->GetID() == IWUI_EVENT_BUTTON)
        {
            SP_RequestUnlockItemsStatus(getEnteredAppID(), getEnteredUserID(), getEnteredSecurityToken());
            return true;
        }

        return false;
    }
};


void ExampleInit()
{
    //Initialise the IwUI module
    IwUIInit();

    //Instantiate the view and controller singletons.
    //IwUI will not instantiate these itself, since they can be subclassed to add functionality.
    new CIwUIController;
    new CIwUIView;

    IwGetResManager()->LoadGroup("SPPluginSample.group");

    //Create text input singleton
    new CIwUITextInput;

    //Create softkeyboard
    IwGetUITextInput()->CreateSoftKeyboard();

    //Choose type of soft keyboard
    IwGetUITextInput()->SetEditorMode(CIwUITextInput::eInlineKeyboard); 

    //Add ui structure to UIView singleton
    CIwUIElement* pMain = CIwUIElement::CreateFromResource("Main");
    IwGetUIView()->AddElementToLayout(pMain);

    pMain->LookupChildNamed(s_AppIDTextField, "AppIDTextField");
    pMain->LookupChildNamed(s_DelayTextField, "AdvertiserCallbackDelayTextField");
    pMain->LookupChildNamed(s_UserIDTextField, "UserIDTextField");
    pMain->LookupChildNamed(s_SecurityTokenTextField, "SecurityTokenTextField");
    pMain->LookupChildNamed(s_CustomCurrencyNameTextField, "CustomCurrencyNameTextField");
    pMain->LookupChildNamed(s_ItemIDTextField, "ItemIDTextField");
    pMain->LookupChildNamed(s_ItemNameTextField, "ItemNameTextField");

    pMain->LookupChildNamed(s_ResponseContentsLabel, "ResponseContentsLabel");

	if (SponsorPayExtensionAvailable()) {
      s_ResponseContentsLabel->SetCaption("SponsorPay Extension available");
    } else {
      s_ResponseContentsLabel->SetCaption("SponsorPay Extension not available!");
    }


    CIwUIButton* sendAdvertiserCallbackButton;
    pMain->LookupChildNamed(sendAdvertiserCallbackButton, "SendAdvertiserCallbackButton");
    sendAdvertiserCallbackButton->AddEventHandler(new SendAdvertiserCallbackButtonEventHandler);

    CIwUIButton* sendDelayedAdvertiserCallbackButton;
    pMain->LookupChildNamed(sendDelayedAdvertiserCallbackButton, "SendDelayedAdvertiserCallbackButton");
    sendDelayedAdvertiserCallbackButton->AddEventHandler(new SendAdvertiserCallbackWithDelayButtonEventHandler);

    CIwUIButton* launchOfferWallButton;
    pMain->LookupChildNamed(launchOfferWallButton, "LaunchOfferWallButton");
    launchOfferWallButton->AddEventHandler(new LaunchOfferWallButtonEventHandler);

    CIwUIButton* launchInterstitialButton;
    pMain->LookupChildNamed(launchInterstitialButton, "LaunchInterstitialButton");
    launchInterstitialButton->AddEventHandler(new LaunchInterstitialButtonEventHandler);

    CIwUIButton* getDeltaOfCoinsButton;
    pMain->LookupChildNamed(getDeltaOfCoinsButton, "GetDeltaOfCoinsButton");
    getDeltaOfCoinsButton->AddEventHandler(new GetDeltaOfCoinsButtonEventHandler);

    CIwUIButton* requestShowOfferBannerButton;
    pMain->LookupChildNamed(requestShowOfferBannerButton, "RequestShowOfferBannerButton");
    requestShowOfferBannerButton->AddEventHandler(new RequestShowOfferBannerButtonEventHandler);

    CIwUIButton* launchUnlockOfferWallButton;
    pMain->LookupChildNamed(launchUnlockOfferWallButton, "LaunchUnlockOfferWallButton");
    launchUnlockOfferWallButton->AddEventHandler(new LaunchUnlockOfferWallButtonEventHandler);

    CIwUIButton* requestUnlockStatusButton;
    pMain->LookupChildNamed(requestUnlockStatusButton, "RequestUnlockStatusButton");
    requestUnlockStatusButton->AddEventHandler(new RequestUnlockStatusButtonEventHandler);
}

//-----------------------------------------------------------------------------
void ExampleShutDown()
{
    delete IwGetUITextInput();
    delete IwGetUIController();
    delete IwGetUIView();

    //Terminate the IwUI module
    IwUITerminate();
}
//-----------------------------------------------------------------------------
bool ExampleUpdate()
{
    //Update the controller (this will generate control events etc.)
    IwGetUIController()->Update();

    //Update the view (this will do animations etc.) The example framework has
    //a fixed framerate of 20fps, so we pass that duration to the update function.
    IwGetUIView()->Update(1000/20);

    return true;
}
//-----------------------------------------------------------------------------
void ExampleRender()
{
    //Render the UI
    IwGetUIView()->Render();

    //Flush IwGx
    IwGxFlush();

    //Display the rendered frame
    IwGxSwapBuffers();
}

//-----------------------------------------------------------------------------
// Main global function
//-----------------------------------------------------------------------------
int main()
{
    //IwGx can be initialised in a number of different configurations to help the linker eliminate unused code.
    //Normally, using IwGxInit() is sufficient.
    //To only include some configurations, see the documentation for IwGxInit_Base(), IwGxInit_GLRender() etc.
    IwGxInit();

    // Example main loop
    ExampleInit();

    // Set screen clear colour
    IwGxSetColClear(0xff, 0xff, 0xff, 0xff);
    IwGxPrintSetColour(128, 128, 128);

    // Register for callbacks from the SponsorPay Extension
    s3eResult registrationResult = SponsorPayExtensionRegister(SPONSORPAYEXTENSION_CALLBACK_CURRENCY_REQUEST_SUCCESS,
                                                              onSPDeltaOfCoinsSuccessfulResponse,
                                                              NULL);
	registrationResult = SponsorPayExtensionRegister(SPONSORPAYEXTENSION_CALLBACK_CURRENCY_REQUEST_ERROR,
                                                     onSPDeltaOfCoinsRequestError,
                                                     NULL);
    
	registrationResult = SponsorPayExtensionRegister(SPONSORPAYEXTENSION_CALLBACK_UNLOCK_ITEMS_REQUEST_SUCCESS,
                                                     onSPUnlockStatusRequestSuccess,
                                                     NULL);

    registrationResult = SponsorPayExtensionRegister(SPONSORPAYEXTENSION_CALLBACK_UNLOCK_ITEMS_REQUEST_ERROR,
                                                     onSPUnlockStatusRequestError,
                                                     NULL);
    while (1)
    {
        s3eDeviceYield(0);
        s3eKeyboardUpdate();
        s3ePointerUpdate();

        int64 start = s3eTimerGetMs();

        bool result = ExampleUpdate();
        if  (
            (result == false) ||
            (s3eKeyboardGetState(s3eKeyEsc) & S3E_KEY_STATE_DOWN) ||
            (s3eKeyboardGetState(s3eKeyAbsBSK) & S3E_KEY_STATE_DOWN) ||
            (s3eDeviceCheckQuitRequest())
            )
            break;

        // Clear the screen
        IwGxClear(IW_GX_COLOUR_BUFFER_F | IW_GX_DEPTH_BUFFER_F);
        ExampleRender();

        // Attempt frame rate
        while ((s3eTimerGetMs() - start) < MS_PER_FRAME)
        {
            int32 yield = (int32) (MS_PER_FRAME - (s3eTimerGetMs() - start));
            if (yield<0)
                break;
            s3eDeviceYield(yield);
        }
    }
    ExampleShutDown();
    IwGxTerminate();
    return 0;
}

int32 onSPDeltaOfCoinsSuccessfulResponse(void* systemData, void* userData) {
    SP_DeltaOfCoinsResponse *deltaOfCoinsResponse = (SP_DeltaOfCoinsResponse *)systemData;

    std::ostringstream results;
    results << "Delta of coins: " << deltaOfCoinsResponse->deltaOfCoins
		<< "\nLatest transaction ID: " << std::string(deltaOfCoinsResponse->latestTransactionId);

    s_ResponseContentsLabel->SetCaption(results.str().c_str());
    return 0;
}

int32 onSPDeltaOfCoinsRequestError (void* systemData, void* userData) {
	SP_ErrorResponse *errorResponse = (SP_ErrorResponse *)systemData;

	std::ostringstream results;
	results << "Error in delta of coins request:\nErrorType: " << errorResponse->errorType <<
		"\nErrorCode: " << std::string(errorResponse->errorCode) <<
		"\nErrorMessage: " << std::string(errorResponse->errorMessage);

	s_ResponseContentsLabel->SetCaption(results.str().c_str());
	return 0;
}

int32 onSPUnlockStatusRequestError (void* systemData, void* userData) {
	SP_ErrorResponse *errorResponse = (SP_ErrorResponse *)systemData;

	std::ostringstream results;
	results << "Error in unlock status request:\nErrorType: " << errorResponse->errorType <<
		"\nErrorCode: " << std::string(errorResponse->errorCode) <<
		"\nErrorMessage: " << std::string(errorResponse->errorMessage);

	s_ResponseContentsLabel->SetCaption(results.str().c_str());
	return 0;
}

int32 onSPUnlockStatusRequestSuccess (void* systemData, void* userData) {
    SP_UnlockItemsStatusResponse *unlockStatusResponse = (SP_UnlockItemsStatusResponse *)systemData;

    int numberOfItems = unlockStatusResponse->numberOfReturnedItems;

    std::ostringstream results;
    results << "Unlock status response:\nNumber of items: " << numberOfItems
        << "\n-----------------------\n\n";

    for (int i = 0; i < numberOfItems; i ++) {
        SP_UnlockItem unlockItem = (*(unlockStatusResponse->returnedItems))[i];
        results << "ID: " << std::string(unlockItem.id) << "\n";
    }

    s_ResponseContentsLabel->SetCaption(results.str().c_str());
    // s_ResponseContentsLabel->SetCaption("unlock status received");
    return 0;
}

const char* getEnteredAppID() {
    return IwSafeCast<CIwUITextField*>(s_AppIDTextField)->GetCaption();
}
const int32 getEnteredDelay() {
    return atoi(IwSafeCast<CIwUITextField*>(s_DelayTextField)->GetCaption());
}
const char* getEnteredUserID() {
    return IwSafeCast<CIwUITextField*>(s_UserIDTextField)->GetCaption();
}
const char* getEnteredSecurityToken() {
    return IwSafeCast<CIwUITextField*>(s_SecurityTokenTextField)->GetCaption();
}
const char* getEnteredCustomCurrencyName() {
    return IwSafeCast<CIwUITextField*>(s_CustomCurrencyNameTextField)->GetCaption();
}
const char* getEnteredItemID() {
    return IwSafeCast<CIwUITextField*>(s_ItemIDTextField)->GetCaption();
}
const char* getEnteredItemName() {
    return IwSafeCast<CIwUITextField*>(s_ItemNameTextField)->GetCaption();
}

