/*
 * android-specific implementation of the SponsorPayExtension extension.
 * Add any platform-specific functionality here.
 */
/*
 * NOTE: This file was originally written by the extension builder, but will not
 * be overwritten (unless --force is specified) and is intended to be modified.
 */
#include "SponsorPayExtension_internal.h"

#include "s3eEdk.h"
#include "s3eEdk_android.h"
#include <jni.h>
#include "IwDebug.h"

static jobject g_Obj;
static jmethodID g_SP_SendAdvertiserCallbackNow;
static jmethodID g_SP_SendAdvertiserCallbackWithDelay;
static jmethodID g_SP_LaunchOfferWall;
static jmethodID g_SP_LaunchInterstitial;
static jmethodID g_SP_RequestNewCoins;
static jmethodID g_SP_RequestOfferBanner;
static jmethodID g_SP_ShowLastReceivedOfferBanner;
static jmethodID g_SP_RemoveOfferBanner;
static jmethodID g_SP_RequestUnlockItemsStatus;
static jmethodID g_SP_LaunchUnlockOfferWall;

void JNICALL SpExtension_onDeltaOfCoinsResponseReceived(JNIEnv* env,jobject obj,
                                                        double deltaOfCoins,
                                                        jstring latestTransactionId);
void JNICALL SpExtension_onDeltaOfCoinsRequestError(JNIEnv* env,jobject obj,
                                                    int errorType,
                                                    jstring errorCode,
                                                    jstring errorMessage);
void JNICALL SpExtension_onUnlockStatusRequestError(JNIEnv* env,jobject obj,
                                                    int errorType,
                                                    jstring errorCode,
                                                    jstring errorMessage);
void JNICALL SpExtension_onUnlockStatusResponseReceived(JNIEnv* env,jobject obj,
                                                        jobjectArray itemIds,
                                                        jobjectArray items);

s3eResult SponsorPayExtensionInit_platform()
{
    // Get the environment from the pointer
    JNIEnv* env = s3eEdkJNIGetEnv();
    jobject obj = NULL;
    jmethodID cons = NULL;

    // Get the extension class
    jclass cls = s3eEdkAndroidFindClass("com/sponsorpay/sdk/marmalade/SponsorPayExtension");
    if (!cls)
        goto fail;

    // Get its constructor
    cons = env->GetMethodID(cls, "<init>", "()V");
    if (!cons)
        goto fail;

    // Construct the java class
    obj = env->NewObject(cls, cons);
    if (!obj)
        goto fail;

    // Get all the extension methods
    g_SP_SendAdvertiserCallbackNow = env->GetMethodID(cls, "SP_SendAdvertiserCallbackNow", "(Ljava/lang/String;)I");
    if (!g_SP_SendAdvertiserCallbackNow)
        goto fail;

    g_SP_SendAdvertiserCallbackWithDelay = env->GetMethodID(cls, "SP_SendAdvertiserCallbackWithDelay", "(Ljava/lang/String;I)I");
    if (!g_SP_SendAdvertiserCallbackWithDelay)
        goto fail;

    g_SP_LaunchOfferWall = env->GetMethodID(cls, "SP_LaunchOfferWall", "(Ljava/lang/String;Ljava/lang/String;)I");
    if (!g_SP_LaunchOfferWall)
        goto fail;

    g_SP_LaunchInterstitial = env->GetMethodID(cls, "SP_LaunchInterstitial", "(Ljava/lang/String;Ljava/lang/String;)I");
    if (!g_SP_LaunchInterstitial)
        goto fail;

    g_SP_RequestNewCoins = env->GetMethodID(cls, "SP_RequestNewCoins", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I");
    if (!g_SP_RequestNewCoins)
        goto fail;

    g_SP_RequestOfferBanner = env->GetMethodID(cls, "SP_RequestOfferBanner", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I");
    if (!g_SP_RequestOfferBanner)
        goto fail;

    g_SP_ShowLastReceivedOfferBanner = env->GetMethodID(cls, "SP_ShowLastReceivedOfferBanner", "()I");
    if (!g_SP_ShowLastReceivedOfferBanner)
        goto fail;

    g_SP_RemoveOfferBanner = env->GetMethodID(cls, "SP_RemoveOfferBanner", "()I");
    if (!g_SP_RemoveOfferBanner)
        goto fail;

    g_SP_RequestUnlockItemsStatus = env->GetMethodID(cls, "SP_RequestUnlockItemsStatus", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I");
    if (!g_SP_RequestUnlockItemsStatus)
        goto fail;

    g_SP_LaunchUnlockOfferWall = env->GetMethodID(cls, "SP_LaunchUnlockOfferWall", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I");
    if (!g_SP_LaunchUnlockOfferWall)
        goto fail;

    {
        static const JNINativeMethod methods[]=
        {
            {"native_onDeltaOfCoinsResponseReceived","(DLjava/lang/String;)V",(void*)&SpExtension_onDeltaOfCoinsResponseReceived},
            {"native_onDeltaOfCoinsRequestError","(ILjava/lang/String;Ljava/lang/String;)V",(void*)&SpExtension_onDeltaOfCoinsRequestError},
            {"native_onUnlockStatusResponseReceived","([Ljava/lang/String;[Lcom/sponsorpay/sdk/android/publisher/unlock/UnlockedItemsResponse$Item;)V",(void*)&SpExtension_onUnlockStatusResponseReceived},
            {"native_onUnlockStatusRequestError","(ILjava/lang/String;Ljava/lang/String;)V",(void*)&SpExtension_onUnlockStatusRequestError}
        };
        // Register the native hooks
        if(env->RegisterNatives(cls,methods,sizeof(methods)/sizeof(methods[0])))
            goto fail;
    }


    IwTrace(SPONSORPAYEXTENSION, ("SPONSORPAYEXTENSION init success"));
    g_Obj = env->NewGlobalRef(obj);
    env->DeleteLocalRef(obj);
    env->DeleteGlobalRef(cls);

    // Add any platform-specific initialisation code here
    return S3E_RESULT_SUCCESS;

fail:
    jthrowable exc = env->ExceptionOccurred();
    if (exc)
    {
        env->ExceptionDescribe();
        env->ExceptionClear();
        IwTrace(SponsorPayExtension, ("One or more java methods could not be found"));
    }
    return S3E_RESULT_ERROR;

}

void SponsorPayExtensionTerminate_platform()
{
    // Add any platform-specific termination code here
}

s3eResult SP_SendAdvertiserCallbackNow_platform(const char* appId)
{
    JNIEnv* env = s3eEdkJNIGetEnv();
    jstring appId_jstr = env->NewStringUTF(appId);
    return (s3eResult)env->CallIntMethod(g_Obj, g_SP_SendAdvertiserCallbackNow, appId_jstr);
}

s3eResult SP_SendAdvertiserCallbackWithDelay_platform(const char* appId, int delayMin)
{
    JNIEnv* env = s3eEdkJNIGetEnv();
    jstring appId_jstr = env->NewStringUTF(appId);
    return (s3eResult)env->CallIntMethod(g_Obj, g_SP_SendAdvertiserCallbackWithDelay, appId_jstr, delayMin);
}

s3eResult SP_LaunchOfferWall_platform(const char* appId, const char* userId)
{
    JNIEnv* env = s3eEdkJNIGetEnv();
    jstring appId_jstr = env->NewStringUTF(appId);
    jstring userId_jstr = env->NewStringUTF(userId);
    return (s3eResult)env->CallIntMethod(g_Obj, g_SP_LaunchOfferWall, appId_jstr, userId_jstr);
}

s3eResult SP_LaunchInterstitial_platform(const char* appId, const char* userId)
{
    JNIEnv* env = s3eEdkJNIGetEnv();
    jstring appId_jstr = env->NewStringUTF(appId);
    jstring userId_jstr = env->NewStringUTF(userId);
    return (s3eResult)env->CallIntMethod(g_Obj, g_SP_LaunchInterstitial, appId_jstr, userId_jstr);
}

s3eResult SP_RequestNewCoins_platform(const char* appId, const char* userId, const char* securityToken)
{
    JNIEnv* env = s3eEdkJNIGetEnv();
    jstring appId_jstr = env->NewStringUTF(appId);
    jstring userId_jstr = env->NewStringUTF(userId);
    jstring securityToken_jstr = env->NewStringUTF(securityToken);
    return (s3eResult)env->CallIntMethod(g_Obj, g_SP_RequestNewCoins, appId_jstr, userId_jstr, securityToken_jstr);
}

s3eResult SP_RequestOfferBanner_platform(const char* appId, const char* userId, const char* currencyName)
{
    JNIEnv* env = s3eEdkJNIGetEnv();
    jstring appId_jstr = env->NewStringUTF(appId);
    jstring userId_jstr = env->NewStringUTF(userId);
    jstring currencyName_jstr = env->NewStringUTF(currencyName);
    return (s3eResult)env->CallIntMethod(g_Obj, g_SP_RequestOfferBanner, appId_jstr, userId_jstr, currencyName_jstr);
}

s3eResult SP_ShowLastReceivedOfferBanner_platform(SP_BannerPosition position)
{
    JNIEnv* env = s3eEdkJNIGetEnv();
    return (s3eResult)env->CallIntMethod(g_Obj, g_SP_ShowLastReceivedOfferBanner);
}

s3eResult SP_RemoveOfferBanner_platform()
{
    JNIEnv* env = s3eEdkJNIGetEnv();
    return (s3eResult)env->CallIntMethod(g_Obj, g_SP_RemoveOfferBanner);
}

s3eResult SP_RequestUnlockItemsStatus_platform(const char* appId, const char* userId, const char* securityToken)
{
    JNIEnv* env = s3eEdkJNIGetEnv();
    jstring appId_jstr = env->NewStringUTF(appId);
    jstring userId_jstr = env->NewStringUTF(userId);
    jstring securityToken_jstr = env->NewStringUTF(securityToken);
    return (s3eResult)env->CallIntMethod(g_Obj, g_SP_RequestUnlockItemsStatus, appId_jstr, userId_jstr, securityToken_jstr);
}

s3eResult SP_LaunchUnlockOfferWall_platform(const char* appId, const char* userId, const char* itemId, const char* itemName)
{
    JNIEnv* env = s3eEdkJNIGetEnv();
    jstring appId_jstr = env->NewStringUTF(appId);
    jstring userId_jstr = env->NewStringUTF(userId);
    jstring itemId_jstr = env->NewStringUTF(itemId);
    jstring itemName_jstr = env->NewStringUTF(itemName);
    return (s3eResult)env->CallIntMethod(g_Obj, g_SP_LaunchUnlockOfferWall, appId_jstr, userId_jstr, itemId_jstr, itemName_jstr);
}

//doesn't own returned char*!
static char* CStringFromJavaString(JNIEnv* env, jstring javaString)
{
    const char* cString = env->GetStringUTFChars(javaString,NULL);
    jsize javaStringLen = env->GetStringLength(javaString);
    char * cStringToReturn = new char[javaStringLen+1];
    memcpy(cStringToReturn, cString, javaStringLen + 1);
    env->ReleaseStringUTFChars(javaString, cString);

    return cStringToReturn;
}

static void CleanCString(uint32, int32, void*, void*, int32, void* completeData)
{
    delete[] (char*)completeData;
}

static void CleanErrorResponse(uint32, int32, void*, void*, int32, void* completeData)
{
    SP_ErrorResponse *errorResponseToClean = (SP_ErrorResponse *)completeData;

    delete[] (char*)(errorResponseToClean->errorCode);
    delete[] (char*)(errorResponseToClean->errorMessage);

    free(errorResponseToClean);
}

static void CleanUnlockStatusResponse(uint32, int32, void*, void*, int32, void* completeData) {
    SP_UnlockItemsStatusResponse *response = (SP_UnlockItemsStatusResponse *)completeData;

    int numberOfItems = response->numberOfReturnedItems;

    for (int i = 0; i < numberOfItems; i ++) {
        SP_UnlockItem item = (*(response->returnedItems))[i];
        delete[] (char *)(item.id);
        delete[] (char *)(item.name);
    }

    free(response->returnedItems);
    free(response);
}

static void EnqueueErrorCallback(JNIEnv* env, int errorType, jstring errorCode, jstring errorMessage,
                                 SponsorPayExtensionCallback callbackType) {

    SP_ErrorResponse *errorResponse = (SP_ErrorResponse *)malloc(sizeof(SP_ErrorResponse));
    errorResponse->errorType = (RequestErrorType)errorType;

    errorResponse->errorCode = CStringFromJavaString(env, errorCode);
    errorResponse->errorMessage = CStringFromJavaString(env, errorMessage);

    s3eEdkCallbacksEnqueue(S3E_EXT_SPONSORPAYEXTENSION_HASH,
                           callbackType,
                           errorResponse, 0,
                           NULL, false,
                           &CleanErrorResponse, errorResponse);
}

void JNICALL SpExtension_onDeltaOfCoinsResponseReceived(JNIEnv* env,jobject obj,
                                                        double deltaOfCoins,
                                                        jstring latestTransactionId) {
    SP_DeltaOfCoinsResponse deltaOfCoinsResponse;
    deltaOfCoinsResponse.deltaOfCoins = deltaOfCoins;

    const char* utf = env->GetStringUTFChars(latestTransactionId,NULL);
    jsize len = env->GetStringLength(latestTransactionId);
    deltaOfCoinsResponse.latestTransactionId = new char[len+1];
    memcpy(deltaOfCoinsResponse.latestTransactionId, utf, len+1);
    env->ReleaseStringUTFChars(latestTransactionId,utf);

    s3eEdkCallbacksEnqueue(S3E_EXT_SPONSORPAYEXTENSION_HASH,
                           SPONSORPAYEXTENSION_CALLBACK_CURRENCY_REQUEST_SUCCESS,
                           &deltaOfCoinsResponse, sizeof(SP_DeltaOfCoinsResponse),
                           NULL, false,
                           &CleanCString, deltaOfCoinsResponse.latestTransactionId);
}

void JNICALL SpExtension_onDeltaOfCoinsRequestError(JNIEnv* env,jobject obj,
                                                    int errorType, jstring errorCode, jstring errorMessage) {
    
    EnqueueErrorCallback(env, errorType, errorCode, errorMessage, SPONSORPAYEXTENSION_CALLBACK_CURRENCY_REQUEST_ERROR);
}

void JNICALL SpExtension_onUnlockStatusResponseReceived(JNIEnv* env,jobject obj,
                                                        jobjectArray itemIds,
                                                        jobjectArray items) {
    int numberOfItems = env->GetArrayLength(items);

    SP_UnlockItemsStatusResponse *response = (SP_UnlockItemsStatusResponse *)malloc(sizeof(SP_UnlockItemsStatusResponse));
    response->numberOfReturnedItems = numberOfItems;
    // This is a pointer to an array of unlock items
    response->returnedItems = (SP_UnlockItem (*)[]) malloc(sizeof(SP_UnlockItem) * numberOfItems);

    jclass javaUnlockItemClass = s3eEdkAndroidFindClass("com/sponsorpay/sdk/android/publisher/unlock/UnlockedItemsResponse$Item");
    jmethodID getItemIdMethod = env->GetMethodID(javaUnlockItemClass, "getId", "()Ljava/lang/String;");
    jmethodID getItemNameMethod = env->GetMethodID(javaUnlockItemClass, "getName", "()Ljava/lang/String;");
    jmethodID getItemTimestampMethod = env->GetMethodID(javaUnlockItemClass, "getTimestamp", "()J");
    jmethodID isItemUnlockedMethod = env->GetMethodID(javaUnlockItemClass, "isUnlocked", "()Z");

    for (int i = 0; i < numberOfItems; i ++) {
        jobject javaUnlockItem = env->GetObjectArrayElement(items, i);

        jstring itemId = (jstring)env->CallObjectMethod(javaUnlockItem, getItemIdMethod);
        jstring itemName = (jstring)env->CallObjectMethod(javaUnlockItem, getItemNameMethod);
        jlong unlockTimestamp = env->CallLongMethod(javaUnlockItem, getItemTimestampMethod);
        jboolean isUnlocked = env->CallBooleanMethod(javaUnlockItem, isItemUnlockedMethod);

        SP_UnlockItem unlockItem;
        unlockItem.id = CStringFromJavaString(env, itemId);
        unlockItem.name = CStringFromJavaString(env, itemName);
        unlockItem.timestamp = unlockTimestamp;
        unlockItem.unlocked = isUnlocked;

        (*(response->returnedItems))[i] = unlockItem;
    }

    s3eEdkCallbacksEnqueue(S3E_EXT_SPONSORPAYEXTENSION_HASH,
                           SPONSORPAYEXTENSION_CALLBACK_UNLOCK_ITEMS_REQUEST_SUCCESS,
                           response, 0,
                           NULL, false,
                           &CleanUnlockStatusResponse, response);
}

void JNICALL SpExtension_onUnlockStatusRequestError(JNIEnv* env,jobject obj,
                                                    int errorType, jstring errorCode, jstring errorMessage) {

    EnqueueErrorCallback(env, errorType, errorCode, errorMessage, SPONSORPAYEXTENSION_CALLBACK_UNLOCK_ITEMS_REQUEST_ERROR);
}