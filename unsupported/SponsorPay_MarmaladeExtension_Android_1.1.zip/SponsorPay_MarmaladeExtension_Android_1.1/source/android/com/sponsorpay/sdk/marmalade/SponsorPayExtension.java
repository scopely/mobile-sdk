/*
java implementation of the SponsorPayExtension extension.

Add android-specific functionality here.

These functions are called via JNI from native code.
*/
/*
 * NOTE: This file was originally written by the extension builder, but will not
 * be overwritten (unless --force is specified) and is intended to be modified.
 */
package com.sponsorpay.sdk.marmalade;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import android.content.Context;
import android.content.Intent;
import android.app.Activity;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.LinearLayout;

import com.ideaworks3d.marmalade.*;

import com.sponsorpay.sdk.android.advertiser.SponsorPayAdvertiser;
import com.sponsorpay.sdk.android.publisher.SponsorPayPublisher;
import com.sponsorpay.sdk.android.publisher.currency.*;
import com.sponsorpay.sdk.android.publisher.OfferBanner;
import com.sponsorpay.sdk.android.publisher.OfferBannerRequest;
import com.sponsorpay.sdk.android.publisher.SPOfferBannerListener;
import com.sponsorpay.sdk.android.publisher.AbstractResponse;
import com.sponsorpay.sdk.android.publisher.unlock.SPUnlockResponseListener;
import com.sponsorpay.sdk.android.publisher.unlock.UnlockedItemsResponse;


class SponsorPayExtension
{
	private static final String FRAMEWORK_VERSION = "1.1";
	
    private static native void native_onDeltaOfCoinsResponseReceived(double deltaOfCoins,
                                                                     String latestTransactionId);
    private static native void native_onDeltaOfCoinsRequestError(int errorType,
                                                                 String errorCode,
                                                                 String errorMessage);

    private static native void native_onUnlockStatusResponseReceived(String[] itemIds,
                                                                     UnlockedItemsResponse.Item[] items);

    private static native void native_onUnlockStatusRequestError(int errorType,
                                                                 String errorCode,
                                                                 String errorMessage);

    private LinearLayout mBannerContainer;
    private OfferBanner mLastReceivedOfferBanner;
    
    private HashMap<String, String> parameters;
    
    public int SP_SendAdvertiserCallbackNow(String appId)
    {
        SponsorPayAdvertiser.register(getApplicationContext(), appId, getAdditionalParameters());
        return 0;
    }
    public int SP_SendAdvertiserCallbackWithDelay(String appId, int delayMin)
    {
        SponsorPayAdvertiser.registerWithDelay(getApplicationContext(),
                                               delayMin,
                                               appId,
                                               getAdditionalParameters());
        

        return 0;
    }
    public int SP_LaunchOfferWall(String appId, String userId)
    {
        final boolean shouldStayOpen = true;

        Intent offerWallIntent = 
        SponsorPayPublisher.getIntentForOfferWallActivity(getApplicationContext(),
                                                          userId,
                                                          shouldStayOpen,
                                                          appId,
                                                          getAdditionalParameters());

        getActivity().startActivityForResult(offerWallIntent,
                                             SponsorPayPublisher.DEFAULT_OFFERWALL_REQUEST_CODE);
        return 0;
    }
    public int SP_LaunchInterstitial(String appId, String userId)
    {
        final boolean shouldStayOpen = false;

        SponsorPayPublisher.loadShowInterstitial(getActivity(), userId, null, shouldStayOpen,
                                                 null, null, 0, appId, getAdditionalParameters());
        return 0;
    }
    public int SP_RequestNewCoins(String appId, String userId, String securityToken)
    {
        SPCurrencyServerListener deltaOfCoinsListener =
        new SPCurrencyServerListener() {
            public void onSPCurrencyServerError(CurrencyServerAbstractResponse response) {
                native_onDeltaOfCoinsRequestError(response.getErrorType().ordinal(),
                                                  response.getErrorCode(),
                                                  response.getErrorMessage());
            }

            public void onSPCurrencyDeltaReceived(CurrencyServerDeltaOfCoinsResponse response) {
                native_onDeltaOfCoinsResponseReceived(response.getDeltaOfCoins(),
                                                      response.getLatestTransactionId());
            }
        };

        SponsorPayPublisher.requestNewCoins(getApplicationContext(), userId, deltaOfCoinsListener,
                    null, securityToken, appId, getAdditionalParameters());

        return 0;
    }
    public int SP_RequestOfferBanner(String appId, String userId, String currencyName)
    {
        SPOfferBannerListener offerBannerListener = new SPOfferBannerListener() {
            public void onSPOfferBannerAvailable(OfferBanner banner) {
                mLastReceivedOfferBanner = banner;
                SP_ShowLastReceivedOfferBanner();
            }

            public void onSPOfferBannerNotAvailable(OfferBannerRequest bannerRequest) {
               SP_RemoveOfferBanner();
            }

            public void onSPOfferBannerRequestError(OfferBannerRequest request) {

            }
        };

        SponsorPayPublisher.requestOfferBanner(getApplicationContext(), userId, offerBannerListener, null,
                    currencyName, appId, getAdditionalParameters());
        return 0;
    }
    public int SP_ShowLastReceivedOfferBanner()
    {
        if (null == mBannerContainer) {
            mBannerContainer = new LinearLayout(getApplicationContext());
            mBannerContainer.setOrientation(LinearLayout.VERTICAL);
            
            getActivity().getWindow().addContentView(mBannerContainer,
                new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT,
                                           ViewGroup.LayoutParams.FILL_PARENT));
        } else {
            SP_RemoveOfferBanner();
        }

        int horizontalGravity = Gravity.CENTER_HORIZONTAL;
        mBannerContainer.setGravity(horizontalGravity | Gravity.BOTTOM);

        View bannerView = mLastReceivedOfferBanner.getBannerView(getActivity());
        if (null == bannerView) {
            return -1;
        }
        mBannerContainer.addView(bannerView,
            new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                                       ViewGroup.LayoutParams.WRAP_CONTENT));

        return 0;
    }
    public int SP_RemoveOfferBanner()
    {
        if (null == mBannerContainer) {
            return -1;
        }

        // Typically, the banner container will have either 0 or 1 child --but to make sure we won't assume it 
        int bannerContainerChildCount = mBannerContainer.getChildCount();

        for (int i = 0; i < bannerContainerChildCount; i++) {
            View bannerView = mBannerContainer.getChildAt(i);

            if (WebView.class.isAssignableFrom(bannerView.getClass())) {
                // If the banner view is of type WebView, call its destroy() method to free resources
                ((WebView)bannerView).destroy();
            }
        }

        if (bannerContainerChildCount > 0) {
            mBannerContainer.removeAllViews();  
        }
        return 0;
    }
    public int SP_RequestUnlockItemsStatus(String appId, String userId, String securityToken)
    {
        final SPUnlockResponseListener listener = new SPUnlockResponseListener() {
            @Override
            public void onSPUnlockRequestError(AbstractResponse response) {
                native_onUnlockStatusRequestError(response.getErrorType().ordinal(),
                                                  response.getErrorCode(),
                                                  response.getErrorMessage());
            }

            @Override
            public void onSPUnlockItemsStatusResponseReceived(UnlockedItemsResponse response) {
                
                Map<String, UnlockedItemsResponse.Item> itemsMap = response.getItems();
                Set<String> setOfIds = itemsMap.keySet();
                int numberOfMappings = setOfIds.size();

                String[] itemIds = new String[numberOfMappings];
                itemIds = setOfIds.toArray(itemIds);
                
                UnlockedItemsResponse.Item[] items = new UnlockedItemsResponse.Item[numberOfMappings];
                for (int i = 0; i < numberOfMappings; i ++) {
                    items[i] = itemsMap.get(itemIds[i]);
                }

                native_onUnlockStatusResponseReceived(itemIds, items);
            }
        };

        SponsorPayPublisher.requestUnlockItemsStatus(getApplicationContext(),
                    userId, listener, securityToken, appId, getAdditionalParameters());
        return 0;
    }
    public int SP_LaunchUnlockOfferWall(String appId, String userId, String itemId, String itemName)
    {
        Intent unlockOfferWallIntent = 
        SponsorPayPublisher.getIntentForUnlockOfferWallActivity(getApplicationContext(),
                                            userId,
                                            itemId,
                                            itemName, 
                                            appId,
                                            getAdditionalParameters());
        getActivity().startActivityForResult(unlockOfferWallIntent,
                                             SponsorPayPublisher.DEFAULT_UNLOCK_OFFERWALL_REQUEST_CODE);
        return 0;
    }

    private Context getApplicationContext() {
        return LoaderActivity.m_Activity.getApplicationContext();
    }

    private Activity getActivity() {
        return LoaderActivity.m_Activity;
    }

	
	private HashMap<String, String> getAdditionalParameters() {
		if (parameters == null) {
			parameters = new HashMap<String, String>();
			parameters.put("framework", "marmalade");
			parameters.put("plugin_version", FRAMEWORK_VERSION);
		}
		return parameters;
	}
	
}
