//
//  SPLogViewController.h
//  SponsorPaySample
//
//  Created by David Davila on 1/14/13.
//  Copyright (c) 2013 SponsorPay. All rights reserved.
//

#import "SPTestAppBaseViewController.h"

@interface SPLogViewController : SPTestAppBaseViewController

@property (retain, nonatomic) IBOutlet UITextView *logMessagesTextView;

@end
