# SponsorPay's Unity Plugin #

The SponsorPay Unity plugin lets you access features provided by the native SponsorPay SDK from your Unity application.

The following features are available for both platforms, iOS and Android:

* Sending the Advertiser Callback 
* Launching the OfferWall
* Communicating with the VCS to get the Delta of Coins

On Android, the following features are also available:

* Sending Advertiser Callback with a customized delay
* Launching the Interstitial
* Requesting and showing an Offer Banner
* Launching the Unlock OfferWall
* Obtaining the status of your Unlock Items

## PLUGIN SETUP ##

Follow these steps to integrate SponsorPay into your Unity project:

1. Import the provided `SponsorPayUnityPlugin.unitypackage` assets package into your project by clicking on `Assets` > `Import Package` > `Custom Package…` from the Unity Editor.
	* If you don't want one of the platforms, just uncheck the corresponding files from the `Plugins/Android` or `Plugins/IOS` folder.
2. The assets package also provides a test scene and a test script to demonstrate how to use the plugin (more information [here](#usingThePlugin)). If you're not interested in it, uncheck the following files from the import dialog:
	* `SponsorPaySDKDemo.cs` 
	* `TestScene.unity`
3. If you're considering deploying for Android and you have your own Android Manifest, read the following [section](#ownAndroidManifest) before continuing. 
4. Attach the `SponsorPayPluginMonoBehaviour.cs` to one of your `Game Objects`. This will be the object used to receive callbacks from the asynchronous SDK methods.
	* This will enable you to get register custom handlers that will be called from the `Game Object`, like this (snippet from the test script provided in the `unitypackage`):

			// get a hold of the SponsorPay plugin instance (SponsorPayPluginMonoBehaviour must be attached to a scene object)
			sponsorPayPlugin = SponsorPayPluginMonoBehaviour.PluginInstance;
	
			// Register delegates to be notified of the result of the "get new coins" request
			sponsorPayPlugin.OnDeltaOfCoinsReceived +=
				new	SponsorPay.DeltaOfCoinsResponseReceivedHandler(OnSPDeltaOfCoinsReceived);
			sponsorPayPlugin.OnDeltaOfCoinsRequestFailed +=
				new SponsorPay.ErrorHandler(OnSPDeltaOfCoinsRequestFailed);
			
			// Register delegates to be notified of the result of the "get unlock status" request
			sponsorPayPlugin.OnUnlockItemsStatusReceived +=
				new SponsorPay.UnlockItemsStatusResponseReceivedHandler(OnSPUnlockItemsStatusResponseReceived);
			sponsorPayPlugin.OnUnlockItemsStatusRequestFailed +=
				new SponsorPay.ErrorHandler(OnSPUnlockItemsRequestError);
			
			// Register delegates to be notified of the result of the "get offerbanner" request
			sponsorPayPlugin.OnOfferBannerResponseReceived +=
				new SponsorPay.OfferBannerResponseReceivedHandler(OnSPOfferBannerResponseReceived);
			sponsorPayPlugin.OnOfferBannerRequestFailed +=
				new SponsorPay.ErrorHandler(OnSPOfferBannerRequestError);

### Build your application ###

1. Build your Unity project for the desired platform.
    * For Android, that's it. Unity will generate your application's APK
	* For iOS, follow [these extra steps](#buildIOS)

<a id="buildIOS"> </a>
### Build your application - iOS ###
1. Unity will generate an XCode project, but first it will prompt you for the desired name for this project. Enter the name and click on "Save". Once the project is generated, open it with XCode.
2. Go to the Build Settings of your project and set "Enable Objective-C Exceptions" to "Yes".
3. Add the following frameworks:
    * AdSupport (optional) - support to the new [Apple's Identifier for Advertisers](http://developer.apple.com/library/ios/#documentation/AdSupport/Reference/ASIdentifierManager_Ref/ASIdentifierManager.html "ASIdentifierManager Class Reference"), available since iOS6
	* CoreTelephony (required)
4. Build the XCode project. If you followed this process with the provided demo Unity project, you can go ahead and run it on the device.


<a id="ownAndroidManifest"> </a>
### If you have your own Android Manifest ###

1. Uncheck the `Assets/Plugins/Android/AndroidManifest.xml` file before hitting the "Import" button.
2. If you want to use the OfferWall or the Interstitial features add the corresponding activities to your manifest (inside the `application` element):

        <!-- SponsorPay OfferWall Activity -->
        <activity android:name="com.sponsorpay.sdk.android.publisher.OfferWallActivity"
                  android:configChanges="fontScale|keyboard|keyboardHidden|locale|mnc|mcc|navigation|orientation|screenLayout|screenSize|smallestScreenSize|uiMode|touchscreen"
                  android:screenOrientation="sensor" />
        <!-- SponsorPay Interstitial Activity -->
        <activity android:name="com.sponsorpay.sdk.android.publisher.InterstitialActivity"
                  android:configChanges="fontScale|keyboard|keyboardHidden|locale|mnc|mcc|navigation|orientation|screenLayout|screenSize|smallestScreenSize|uiMode|touchscreen"
                  android:screenOrientation="sensor"
                  android:theme="@android:style/Theme.Dialog" />                

3. Make sure your manifest contains the following permissions

		<uses-permission android:name="android.permission.INTERNET" />
		<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
		<uses-permission android:name="android.permission.READ_PHONE_STATE" />
		<uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />



<a id="usingThePlugin"> </a>
## USING THE PLUGIN ##

An example script which uses each of the SDK features is provided in the sample project as `Assets/SponsorPaySDKDemo.cs`  script and `Assets/TestScene.unity` scene.

It demonstrates how to send the advertiser callback, launch the SponsorPay OfferWall and the Interstitial, request and show an Offer Banner and request the delta of coins as well as the status of the Unlock Items, and how to get responses back from the SDK.

It also includes code to draw a test UI which triggers calls to the SDK and displays its responses.
