//
//  SPLogViewController.m
//  SponsorPay Sample App
//
//  Created by David Davila on 1/14/13.
// Copyright 2011-2013 SponsorPay. All rights reserved.
//

#import "SPLogViewController.h"
#import "SPBufferedLogger.h"

@interface SPLogViewController ()

@end


@implementation SPLogViewController
{
    @private
    BOOL shouldScrollLogViewToEnd;
}


#pragma mark - Life Cycle

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];

    if (self) {

    }

    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];

    self.logMessagesTextView.delegate = self;
    self.logMessagesTextView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"lined_paper.png"]];

    self->shouldScrollLogViewToEnd = YES;

    [self updateLogView];

    [[SPBufferedLogger logger] addObserver:self
                                forKeyPath:SPLoggerBufferedMessagesStringPropertyName
                                   options:NSKeyValueObservingOptionOld
                                   context:nil];

    UIButton* clearButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [clearButton setImage:[UIImage imageNamed:@"clear.png"] forState:UIControlStateNormal];
    clearButton.frame = CGRectMake(292,2,16,16);
    [clearButton addTarget:self action:@selector(clearMessages) forControlEvents:UIControlEventTouchUpInside];

    [self.view addSubview:clearButton];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}


- (void)viewDidUnload
{
    [[SPBufferedLogger logger] removeObserver:self forKeyPath:SPLoggerBufferedMessagesStringPropertyName];
    [self setLogMessagesTextView:nil];
    [super viewDidUnload];
}


#pragma mark - KVO

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    if (object == [SPBufferedLogger logger] && [keyPath isEqualToString:SPLoggerBufferedMessagesStringPropertyName]) {
        [self performSelectorOnMainThread:@selector(updateLogView) withObject:nil waitUntilDone:NO];
    }
}


#pragma mark - Private

- (void)updateLogView
{
    BOOL const shouldScroll = self->shouldScrollLogViewToEnd;

    self.logMessagesTextView.text = [[SPBufferedLogger logger] bufferedMessagesString];

    if (shouldScroll) {
        [self scrollLogViewToEnd];
    }
}


- (void)clearMessages
{
    [[SPBufferedLogger logger] clearBuffer];
}


#pragma mark - UITextViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGPoint const textViewContentOffset = self.logMessagesTextView.contentOffset;
    CGSize const textViewContentSize = self.logMessagesTextView.contentSize;
    CGRect const textViewBounds = self.logMessagesTextView.bounds;
    
    CGRect const visibleRect = CGRectMake(
    	textViewContentOffset.x,
        textViewContentOffset.y,
        textViewBounds.size.width,
        textViewBounds.size.height);
    
    CGFloat const deltaOfMaximumYs = CGRectGetMaxY(visibleRect) - textViewContentSize.height;

    self->shouldScrollLogViewToEnd = (1.0 > fabs(deltaOfMaximumYs)) ? YES : NO;
}


- (void)scrollLogViewToEnd
{
    NSUInteger currentLogLength = [[[SPBufferedLogger logger] bufferedMessagesString] length];

    if (currentLogLength) {
        NSRange newMessageRange = NSMakeRange(currentLogLength - 1, 1);
        [self.logMessagesTextView scrollRangeToVisible:newMessageRange];
    }

    self->shouldScrollLogViewToEnd = YES;
}

@end
