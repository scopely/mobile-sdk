//
//  SPDictionaryBasedSettings.m
//  SponsorPayTestApp
//
//  Created by Pierre Bongen on 26.05.14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import "SPDictionaryBasedSettings.h"

// SponsorPay SDK.
#import "SPStrings.h"


#pragma mark  

@interface SPDictionaryBasedSettings ()

#pragma mark  
#pragma mark Public Properties Declaration Overrides -

#pragma mark  
#pragma mark Target

@property ( nonatomic, strong, readwrite ) id target;

#pragma mark  
#pragma mark Settings

@property ( nonatomic, copy, readwrite ) NSDictionary *values;

@end



#pragma mark  
#pragma mark  
#pragma mark  

@implementation SPDictionaryBasedSettings
{
@private

    //
    // Target
    //
    
    id target;
    
    //
    // Settings
    //
    
    NSString *localizedDescription;
    NSString *localizedName;
    NSDictionary *values;

}

#pragma mark  
#pragma mark Public Properties -

#pragma mark  
#pragma mark Target

@synthesize target = target;

#pragma mark  
#pragma mark Settings

@synthesize values = values;

#pragma mark  

- (void)setValues:(NSDictionary *)newValues
{
    NSAssert(
        [newValues isKindOfClass:[NSDictionary class]]
            && [newValues count],
        @"Expecting newSettings parameter to be a non-empty dictionary." );
    
    self->values = [[NSDictionary alloc]
        initWithDictionary:newValues
        copyItems:YES];
}

#pragma mark  
#pragma mark State

- (SPSettingsState)state
{
    //
    // Check state.
    //
    
    if ( !self.target ) {
    
        return SPSettingsStateUnknown;
    
    }
    
    //
    // Compare values.
    //
    //      The setting is regarded active if all of the setting's values are
    //      found in the adapter for the corresponding key paths.
    //
    
    id const targetOfSelf = self.target;
    NSDictionary * const valuesOfSelf = self.values;
    NSArray * const keyPaths = [valuesOfSelf allKeys];
    
    for ( NSString *keyPath in keyPaths ) {
    
        id const settingsValue = valuesOfSelf[ keyPath ];
        id const currentValue = [targetOfSelf valueForKeyPath:keyPath];
        
        if ( !currentValue && [settingsValue isKindOfClass:[NSNull class]] ) {
        
            // The current value is nil and the counterpart value of the 
            // setting is NSNull which is regarded equal. Continue!
            continue;
        
        }
        
        if ( ![settingsValue isEqual:currentValue] ) {
        
            // If the values are different the setting is not active in the
            // adapter.
            return SPSettingsStateInactive;
        
        }
        
    }
    
    return SPSettingsStateActive;
}

- (BOOL)isAvailable
{
    return self.target ? YES : NO;
}

#pragma mark  
#pragma mark  
#pragma mark Public Methods -

#pragma mark  
#pragma mark Initialisation

- (instancetype)initWithName:(NSString *)aLocalizedName
    description:(NSString *)aLocalizedDescription
    values:(NSDictionary *)someValues
    forTarget:(id)aTarget
{
    self = [super 
    	initWithName:aLocalizedName 
        description:aLocalizedDescription];
    
    if ( self ) {
    
        self.values = someValues;
        self.target = aTarget;
    
    }
    
    return self;
}

+ (instancetype)settingsWithName:(NSString *)aName
    description:(NSString *)aDescription
    values:(NSDictionary *)someValues
    forTarget:(id)aTarget
{
    return [[self alloc] 
    	initWithName:aName
        description:aDescription
        values:someValues
        forTarget:aTarget];
}

#pragma mark  
#pragma mark Applying Settings

- (void)apply
{
    //
    // Check state.
    //
    
    if ( !self.available ) {
    
        // Cannot apply settings since settings are not available ( e.g. no
        // target, ... )
        return;
    
    }
    else if ( self.active ) {
    
        // Settings are active, nothing to do.
        return;
    
    }
    
    //
    // Apply settings.
    //
        
    NSLog( 
    	@"Applying setting '%@' to target %@.",
    	self.localizedName,
        self.target );

    SPSettingsState const oldState = self.state;
    NSDictionary * const valuesOfSelf = self.values;
    NSArray * const keyPaths = [valuesOfSelf allKeys];
    id const targetOfSelf = self.target;
    
    for ( NSString *keyPath in keyPaths ) {
    
        id const value = valuesOfSelf[ keyPath ];
        
        [targetOfSelf setValue:value forKeyPath:keyPath];
        
    }
    
    //
    // Trigger KVO for "state" property.
    //
    
    if ( oldState != self.state ) {
    
        [self notifyDidChangeState];
    
    }
}

#pragma mark  
#pragma mark  
#pragma mark Protocol Methods -

#pragma mark  
#pragma mark NSKeyValueObserving: Observing Customization

+ (BOOL)automaticallyNotifiesObserversForKey:(NSString *)key
{
    static NSSet *keysWithManualNotifications = nil;
    static dispatch_once_t onceToken;

	dispatch_once(&onceToken, ^( void ) {
    
    	keysWithManualNotifications = [NSSet setWithObjects:
        	SP_KEY_FOR_PROPERTY( (SPDictionaryBasedSettings *)0, state ),
            nil];
	
    });

    if ( [keysWithManualNotifications containsObject:key] ) {
    
        return NO;
    
    }
    
    return [super automaticallyNotifiesObserversForKey:key];
}

@end

#pragma mark  
