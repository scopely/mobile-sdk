//
//  SPSettingsTableViewCell.m
//  SponsorPayTestApp
//
//  Created by Pierre Bongen on 27.05.14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import "SPSettingsTableViewCell.h"

// SponsorPay Test App.
#import "SPTestAppSettings.h"
#import "SPStrings.h"



#pragma mark  

@interface SPSettingsTableViewCell ()

@end



#pragma mark  
#pragma mark  
#pragma mark  

@implementation SPSettingsTableViewCell
{
@private

    SPTestAppSettings *settings;

    struct {
    
        BOOL isObservingSettings:1;
        
    } flags;
    
}

#pragma mark  
#pragma mark Public Properties -

#pragma mark  
#pragma mark Cell Data

@synthesize settings = settings;

- (void)setSettings:(SPTestAppSettings *)newSettings
{
    //
    // Check parameter.
    //
    
    //
    // Check state.
    //
    //      NOTE: We currently have no dedicated implementation for isEqual: for
    //            the settings class.
    //
    
    if ( newSettings == self->settings ) {

        return;
    }
    
    //
    // Set new settings.
    //
    
    if ( self->settings ) {
 
        [self stopObservingSettings];
        
    }
    
    self->settings = newSettings;
    
    if ( self->settings ) {
    
        [self startObservingSettings];
    
    }
    
    //
    // Update the cell.
    //
    
    [self updateCell];
}

#pragma mark  
#pragma mark Public Methods -

#pragma mark  
#pragma mark Initialisation

- (instancetype)init
{
    return ( self = [self initWithReuseIdentifier:nil] );
}

- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super 
    	initWithStyle:UITableViewCellStyleSubtitle 
        reuseIdentifier:reuseIdentifier];
    
    if ( self ) {
    }
    
    return self;
}

#pragma mark  
#pragma mark Realising Cell State and Data

- (void)realizeStateAndData
{
    [self realizeSettingsDescription];
    [self realizeSettingsName];
    [self realizeSettingsActiveState];
}

#pragma mark  
#pragma mark Private Methods -

#pragma mark  
#pragma mark Realizing Cell State and Data

- (void)realizeSettingsActiveState
{
    if ( 
    	( UITableViewCellAccessoryNone == self.accessoryType 
            && self.settings.active )
        || ( UITableViewCellAccessoryCheckmark == self.accessoryType
            && !self.settings.active )
    ){	
    	[self updateSettingsActiveState];
    }
}

- (void)realizeSettingsAvailableState
{
    if ( 
    	( UITableViewCellSelectionStyleNone == self.selectionStyle 
            && self.settings.available )
        || ( UITableViewCellSelectionStyleDefault == self.selectionStyle
            && !self.settings.available )
    ){	
    	[self updateSettingsAvailableState];
    }
}

- (void)realizeSettingsDescription
{
    if ( 
    	![self.detailTextLabel.text isEqualToString:
    		self.settings.localizedDescription]
    ){
        [self updateSettingsDescription];
    }
}

- (void)realizeSettingsName
{
    if (
        ![self.textLabel.text isEqualToString:
            self.settings.localizedName]
    ){
        [self updateSettingsName];
    }
}


#pragma mark  
#pragma mark Updating the Cell

- (void)updateCell
{
    [self updateSettingsDescription];
    [self updateSettingsName];
    [self updateSettingsActiveState];
    [self updateSettingsAvailableState];
}

- (void)updateSettingsDescription
{
    self.detailTextLabel.text = self.settings.localizedDescription;
}

- (void)updateSettingsName
{
    self.textLabel.text = self.settings.localizedName;
}

- (void)updateSettingsActiveState
{
    self.accessoryType = self.settings.active 
    	? UITableViewCellAccessoryCheckmark
        : UITableViewCellAccessoryNone;
}

- (void)updateSettingsAvailableState
{
    BOOL const available = self.settings.available;
    
    if ( available )
    {
    	self.selectionStyle = UITableViewCellSelectionStyleDefault;
    }
    else
    {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.selected = NO;
    }

    self.textLabel.enabled = available;
    self.detailTextLabel.enabled = available;
}

#pragma mark  
#pragma mark Observing the Settings

- (void)startObservingSettings
{
    //
    // Check state.
    //
    
    if ( self->flags.isObservingSettings ) {
        
        return;

    }
    
    //
    // Start observing the settings.
    //
    
    NSAssert( self.settings, @"Expecting settings to be set." );
    
    [self.settings 
    	addObserver:self
        forKeyPath:SP_KEY_FOR_PROPERTY( self.settings, active )
        options:0
        context:(__bridge void *)[SPSettingsTableViewCell class]];
    
    self->flags.isObservingSettings = YES;
}

- (void)stopObservingSettings
{
    //
    // Check state.
    //
    
    if ( !self->flags.isObservingSettings ) {
        
        return;

    }
    
    //
    // Start observing the settings.
    //
    
    NSAssert( self.settings, @"Expecting settings to be set." );
    
    [self.settings 
    	removeObserver:self
        forKeyPath:SP_KEY_FOR_PROPERTY( self.settings, active )
        context:(__bridge void *)[SPSettingsTableViewCell class]];
    
    self->flags.isObservingSettings = NO;
}

#pragma mark  
#pragma mark Method Overrides -

#pragma mark  
#pragma mark NSObject: Creating, Copying, and Deallocating

- (void)dealloc
{
    [self stopObservingSettings];
}

#pragma mark  
#pragma mark Protocol Methods -

#pragma mark  
#pragma mark NSKeyValueObserving: Change Notification

- (void)observeValueForKeyPath:(NSString *)keyPath 
	ofObject:(id)object 
	change:(NSDictionary *)change 
    context:(void *)context
{
    BOOL didHandleChange = NO;
    
    if ( context == (__bridge void *)[SPSettingsTableViewCell class] ) {
    
        if ( object == self.settings ) {
        
            if ( 
            	[keyPath isEqualToString:SP_KEY_FOR_PROPERTY(
                	self.settings, active )]
            ){
                [self realizeSettingsActiveState];
                didHandleChange = YES;
            }

        }

    }
    
    if ( !didHandleChange ) {
    
        [super 
        	observeValueForKeyPath:keyPath 
            ofObject:object 
            change:change 
            context:context];
    
    }
}

@end

#pragma mark  
