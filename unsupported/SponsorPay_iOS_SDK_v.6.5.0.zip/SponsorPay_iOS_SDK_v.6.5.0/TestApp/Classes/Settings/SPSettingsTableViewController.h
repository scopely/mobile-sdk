//
//  SPSettingsTableViewController.h
//  SponsorPayTestApp
//
//  Created by Pierre Bongen on 26.05.14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import <UIKit/UIKit.h>

// SponsorPay Test App.
#import "SPTestAppSettings.h"



#pragma mark  

/*!
    \brief View controller displaying and applying settings.
    
    The groups are sorted alphabetically. The settings themselves are displayed
    in the order in which they have been added.
*/
@interface SPSettingsTableViewController : UITableViewController

#pragma mark  
#pragma mark Initialisation

- (instancetype)init;

#pragma mark  
#pragma mark Managing Settings

/*!
    \name Managing Settings
    \note Currently, adding of settings only.
    
    @{
*/

- (void)addSettings:(SPTestAppSettings *)settings 
	toGroupWithName:(NSString *)aGroupName;
- (SPTestAppSettings *)settingsAtIndexPath:(NSIndexPath *)indexPath;
- (NSArray *)settingsInGroupWithName:(NSString *)aGroupName;


//!@}

#pragma mark  
#pragma mark Managing Settings Groups

- (NSString *)footerTitleForSettingsGroupWithName:(NSString *)aGroupName;
- (void)setFooterTitle:(NSString *)newLocalizedTitle
	forSettingsGroupWithName:(NSString *)aGroupName;

@end

#pragma mark  