//
//  SPConfigurationRequestManagerSpec.m
//  SponsorPayTestApp
//
//  Created by Piotr on 6/23/14.
//  Copyright 2014 SponsorPay. All rights reserved.
//

#import <Specta/Specta.h>
#define EXP_SHORTHAND
#import <Expecta/Expecta.h>
#import <OHHTTPStubs/OHHTTPStubs.h>
#import <OHHTTPStubs/OHHTTPStubsResponse+JSON.h>

#import "SPConfigurationRequestManager.h"
#import "SPKeychainItemWrapper.h"
#import "SPCredentials.h"
#import "SPURLGenerator.h"
#import "SPSignature.h"
#import "SPGlobalUtilities.h"
#import "NSDictionary+SPSerialization.h"
#import "SPConfigurationRequestManager+Debug.h"

@interface SPConfigurationRequestManager(Extra)

+ (void)allNestedKeys:(id)dict log:(NSMutableSet *)log;

@end

@implementation SPConfigurationRequestManager(Extra)
/**
 Requests the lowest level representation of key
 
 @param container Object that can be NSArray, NSDictionry, NSSet type
 @param log Mutable set object that stores the lowest level key found in the container
 
 @code
 
 NSArray *numbers = @[
    @{ @"ein" : @"one",
        @"hundert" : @{
            @"hundert ein" : @"hundred two",
            @"hundert zwei" : @"hundred one",
            @"hundert drei" : @{
                @"tausend ein" : @"thousand one",
                @"tausend zwei" : @"thousand two"
            }
        },
        @"zwei" : @"two",
    },
    @{
        @"minus ein" : @"-one",
        @"minus zwei" : @"-two",
    }
 ];
 
 NSMutableSet *logSet = [NSMutableSet set];
 [[self class] numbers log:logSet];
 @endcode
 
 @note Mutable set collects following keys:@"minus ein", @"ein", @"hundert zwei", @"tausend ein", @"minus zwei", @"hundert ein", @"zwei", @"tausend zwei". The keys @"hundert" and @"hundert drei" are not included as they are not lowest level object keys and are keys for another containers
 
 */
+ (void)allNestedKeys:(id)container log:(NSMutableSet *)log{
    if ([container isKindOfClass:[NSArray class]]) {
        int i = 0;
        while (i < [container count] && container[i]) {
            [self allNestedKeys:container[i] log:log];
            i++;
        }
    } else {
        for (id key in container) {
            if ([container[key] isKindOfClass:[NSDictionary class]]) {
                [self allNestedKeys:container[key] log:log];
            } else {
                NSArray *k = [[container allKeysForObject:container[key]] lastObject];
                [log addObject:k];
            }
        }
    }
    return;
}

@end

SpecBegin(ConfigurationResponse)

// Test for checking the request and response of configuration data
// The following test are performed:
// 1. Check the network configuration is passed by completion block
// 2. Verify the network configuration is NSArray type
// 3. Verify all the keys are NSString class
// 4. Verify the passwords are trimmed
// 5. Verify adapters credentials found in both json and plist, including also overriding check
// 6. Verify adapters credentials found only in plist - only when overriding takes place


describe(@"SPConfigurationRequestManager - Verifying response", ^{
    __block NSArray *result;
    __block SPConfigurationRequestManager *configManager;
    __block SPCredentials *credentials;
    
    void (^configurationCompletionBlock)(NSArray *networks) = ^(NSArray *networks) {
        result = networks;
    };

    beforeAll(^{
        credentials = [[SPCredentials alloc] init];
        credentials.appId = @"8061";
        credentials.securityToken = @"63adc1aea63b7a8d9666335bc63459ba";
    });
    
    it(@"Checking json response", ^AsyncBlock{
        configManager = [[SPConfigurationRequestManager alloc] initWithCredentials:credentials completionBlock:configurationCompletionBlock];
        [configManager requestConfiguration];
        done();
    });
    
    it(@"Check content of result", ^{
        // Check data is not empty
        expect(result).notTo.beNil();
        
        // Check data type is correct
        expect(result).to.beKindOf([NSArray class]);
        
        // Loop through networks and check all striped off passwords
        NSMutableSet *keys = [[NSMutableSet alloc] init];
        [SPConfigurationRequestManager allNestedKeys:result log:keys];
        
        for(id key in keys){
            expect(key).to.beKindOf([NSString class]);
            expect([(NSString *)key hasPrefix:@"__"]).notTo.beTruthy;
        }
    });
    
    afterAll(^{
        credentials = nil;
    });
    
    describe(@"SPConfigurationRequestManager - Verify adapters credentials found in both json and plist", ^{
        __block NSString *expectedSecret1;
        __block NSString *expectedSecret2;
        __block NSString *adapterName;
        __block NSString *key;
        
        beforeAll(^{
            // Expected secrets
            expectedSecret1 = @"7TGX5C5S3XK633XSVMBB"; // JSON
            expectedSecret2 = @"7TGX5C5S3XK633XSVMBB"; // plist
            adapterName     = @"Flurry for Advertisers";
            key             = @"SPFlurryApiKey";
        });
        
        it(@"Checking secret is matching", ^{
            SPKeychainItemWrapper *keychain = [[SPKeychainItemWrapper alloc] initWithAdapter:adapterName key:key accessGroup:nil];
            NSString *secretValue = [keychain objectForKey:(__bridge id)kSecValueData];
            
#ifndef IGNORE_LOCAL_ADAPTERS_SETTINGS
            expect(secretValue).to.equal(expectedSecret2);
#else
            expect(secretValue).to.equal(expectedSecret1);
#endif
        });
        
        afterAll(^{
            expectedSecret1 = nil;
            expectedSecret2 = nil;
        });
    });

#ifndef IGNORE_LOCAL_ADAPTERS_SETTINGS
    describe(@"SPConfigurationRequestManager - Verify adapters credentials found only in plist", ^{
        __block NSString *expectedSecret;
        __block NSString *adapterName;
        __block NSString *key;
        
        beforeAll(^{
            // Expected secrets
            expectedSecret  = @"9e09f722cfd04cc09e38366c8fa3a4a0";
            adapterName     = @"InMobi";
            key             = @"SPInMobiAppId";
        });
        
        it(@"Checking secret is matching", ^{
            SPKeychainItemWrapper *keychain = [[SPKeychainItemWrapper alloc] initWithAdapter:adapterName key:key accessGroup:nil];
            NSString *secretValue = [keychain objectForKey:(__bridge id)kSecValueData];

            expect(secretValue).to.equal(expectedSecret);
        });
        
        afterAll(^{
            expectedSecret = nil;
        });
    });
#endif
    
});

SpecEnd

SpecBegin(ConfigurationFile)

// Test for checking the file has been stored in cache folder
// The following test are performed:
// 1. Check the file exists
// 2. Test the file is not empty
// 3. Verify parsing file works as expected - (it is not corrupt)
// 4. Verify all the keys are NSString class
// 5. Verify the passwords are trimmed

describe(@"SPConfigurationRequestManager - Verifying the file stored in cache folder", ^{
    __block NSData *fileData;
    
    it(@"Check local file", ^{
        // Checked saved file exists
        NSString *networksCachePath = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject];
        networksCachePath = [networksCachePath stringByAppendingPathComponent:@"SPNetworksCache"];
        NSString *filePath = [networksCachePath stringByAppendingPathComponent:@"adapters.json"];
        BOOL fileValid = [[NSFileManager defaultManager] fileExistsAtPath:filePath];
        expect(fileValid).notTo.beNull;
        
        // Check saved file is not empty
        fileData = [[NSFileManager defaultManager] contentsAtPath:filePath];
        fileValid &= fileData != nil;
        expect(fileValid).notTo.beNull;
    });
    
    __block id jsonObj;
    // Verify the file is not corrupt and works as expected
    it(@"Build dictionary from json file", ^AsyncBlock {
        NSError *error = nil;
        jsonObj = [[NSJSONSerialization JSONObjectWithData:fileData
                                                   options:NSJSONReadingMutableContainers
                                                     error:&error] copy];
        expect(error).to.beNil;
        done();
    });
    
    // Loop through all the keys
    // Verify they are NSString type and password key-value pair is absent
    it(@"Verify there no passwords", ^{
        NSMutableSet *keys = [[NSMutableSet alloc] init];
        [SPConfigurationRequestManager allNestedKeys:jsonObj log:keys];
        
        for(id key in keys){
            expect(key).to.beKindOf([NSString class]);
            expect([(NSString *)key hasPrefix:@"__"]).notTo.beTruthy;
        }
    });
});

SpecEnd

SpecBegin(ConfigurationSecrets)

// Test for checking handling sensitive data
// The following test are performed:
// 1. Check all sensitive data has been saved in keychain
// 2. Check the replacement has occured and verify
// 3. Access secured information and verify

describe(@"SPConfigurationRequestManager - Check sensitive data", ^{
    __block NSArray *result;
    __block SPConfigurationRequestManager *configManager;
    __block SPCredentials *credentials;
    
    // In order to avoid signature validation failure and posses full controll over what is requested and what is responded
    // each network request is stubbed.
    
    // This test case uses dummyData (Configure as you want).
    NSString *(^dummyJson)() = ^NSString *() {
        return @"{\"adapters\":[{\"name\":\"Millennial\",\"settings\":{\"__SPMillennialApid\":152144}},{\"name\":\"Flurry for Advertisers\",\"settings\":{\"__SPFlurryApiKey\":\"7TGX5C5S3XK633XSVMBB\",\"__SPFlurryAdSpaceVideo\":\"INTERSTITIAL_MAIN_VC\"}}]}";
    };
    
    NSString *(^dummySignature)() = ^NSString *() {
        NSString *json = dummyJson();
        return [SPSignature signatureForString:json secretToken:credentials.securityToken];
    };
    
    void (^httpStubs)() = ^{
        [OHHTTPStubs stubRequestsPassingTest:^BOOL(NSURLRequest *request) {
            return YES;
        } withStubResponse:^OHHTTPStubsResponse*(NSURLRequest *request) {
            NSString *dummySign = dummySignature();
            NSData *adaptersData = [dummyJson() dataUsingEncoding:NSUTF8StringEncoding];
            return [OHHTTPStubsResponse responseWithData:adaptersData statusCode:200 headers:@{@"Content-Type":@"text/json",
                                                                                               @"X-Sponsorpay-Response-Signature": dummySign}];
        }];
    };
    
    void (^configurationCompletionBlock)(NSArray *networks) = ^(NSArray *networks) {
        result = networks;
    };
    
    beforeAll(^{
        credentials = [[SPCredentials alloc] init];
        credentials.appId = @"8061";
        credentials.securityToken = @"63adc1aea63b7a8d9666335bc63459ba";
        
        // Stub the network
        httpStubs();
    });
    
    it(@"Checking json response", ^AsyncBlock{
        configManager = [[SPConfigurationRequestManager alloc] initWithCredentials:credentials completionBlock:configurationCompletionBlock];
        [configManager requestConfiguration];
        done();
    });
    
    it(@"Verify that sensitive data is stored in keychain for each adapter", ^{
        
        NSData *dummyData               = [dummyJson() dataUsingEncoding:NSUTF8StringEncoding];
        NSDictionary *dummyDictionary   = [NSJSONSerialization JSONObjectWithData:dummyData options:0 error:nil];
        NSArray *dummyAdapters          = dummyDictionary[@"adapters"];
        
        // Because the keys and values for sensitive data are stripped off from `result`, the only way to access
        // is to reuse dummy array of adapters containing these keys and values.
        [dummyAdapters enumerateObjectsUsingBlock:^(NSDictionary *adapter, NSUInteger idx, BOOL *stop) {
            __block BOOL isSavedInKeychain = NO;
            [(NSDictionary *)adapter.adapterSettings enumerateKeysAndObjectsUsingBlock:^(NSString *key, id obj, BOOL *stop) {
                
                if ([key hasPrefix:@"__"]) {
                    key = [key substringFromIndex:2];
                }
                
                SPKeychainItemWrapper *keychainWrapper = [[SPKeychainItemWrapper alloc] initWithAdapter:adapter.adapterName
                                                                                                    key:key
                                                                                            accessGroup:nil]; // We don't need access group as it is
                NSString *value = [keychainWrapper objectForKey:(__bridge id)kSecValueData];
                if(value) {
                    // It should contain string
                    expect(value.length).to.beGreaterThan(0);
                    
                    // It should be NSString type
                    expect(value).to.beKindOf([NSString class]);
                    
                    isSavedInKeychain = YES;
                }
            }];
        }];
    });
});

SpecEnd

SpecBegin(ConfigurationFallbackJson)
// Test for checking fallback operation. Network is not available and fetching json file
// Usually happens if there is no network connection.
// The following test are performed:
// 1. Check the network is offline
// 2. Check json file is available
// 3. Call SPConfigurationRequestManager and expect return configuration from json

describe(@"SPConfigurationRequestManager - Check json fallback", ^{
    __block NSArray *result;
    __block SPConfigurationRequestManager *configManager;
    __block NSError *networkError;
    
    void (^httpStubs)() = ^{
        [OHHTTPStubs stubRequestsPassingTest:^BOOL(NSURLRequest *request) {
            return YES;
        } withStubResponse:^OHHTTPStubsResponse*(NSURLRequest *request) {
            return [OHHTTPStubsResponse responseWithError:[NSError errorWithDomain:NSURLErrorDomain code:kCFURLErrorNotConnectedToInternet userInfo:nil]];
        }];
    };
    
    void (^configurationCompletionBlock)(NSArray *networks) = ^(NSArray *networks) {
        result = networks;
    };
    
    void (^configurationFailedBlock)(NSError *error) = ^(NSError *error) {
        networkError = error;
    };
    
    beforeAll(^{
        // Stub the network
        httpStubs();
    });
    
    it(@"Check the json file exists in cache directory", ^{
        NSString *networksCachePath = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject];
        networksCachePath = [networksCachePath stringByAppendingPathComponent:@"SPNetworksCache"];
        NSString *filePath = [networksCachePath stringByAppendingPathComponent:@"adapters.json"];
        BOOL fileValid = [[NSFileManager defaultManager] fileExistsAtPath:filePath];
        expect(fileValid).notTo.beNull;
        
        // Check saved file is not empty
        NSData *fileData = [[NSFileManager defaultManager] contentsAtPath:filePath];
        fileValid &= fileData != nil;
        expect(fileValid).notTo.beNull;
    });
    
    it(@"Checking json response", ^AsyncBlock{
        configManager = [[SPConfigurationRequestManager alloc] initWithCredentials:nil completionBlock:configurationCompletionBlock];
        configManager.configurationFailedBlock = configurationFailedBlock;
        [configManager requestConfiguration];
        done();
    });
    
    it(@"Verify that the network failed", ^{
        // Ok, the operation failed
        // Error returned
        expect(networkError).notTo.beNil;
        
        // Verify there was no internet connection
        expect(networkError.code).to.equal(kCFURLErrorNotConnectedToInternet);
        
        // Now expecting a fallback call to parse json from cache folder
        // configurationCompletionBlock should be called as data was finally provided
    });
    
    it(@"Verify that the data was returned", ^{
        // Data provided!
        expect(result).notTo.beNil;
    });
    
    afterAll(^{
        // Clean up
        result = nil;
        configManager = nil;
        networkError = nil;
    });
});

SpecEnd

SpecBegin(ConfigurationFallbackPlist)
// Test for checking fallback operation. Network is not available and also json is absent and fetching data from plist
// It usually happens in DEBUG mode when there is no network connection and IGNORE_LOCAL_ADAPTERS_SETTINGS is undefined
// The following test are performed:
// 1. Check the network is off
// 2. Check json file is unavailable
// 3. Call SPConfigurationRequestManager and expect return configuration from plist

describe(@"SPConfigurationRequestManager - Check ...-Info.plist fallback", ^{
    __block NSArray *result;
    __block SPConfigurationRequestManager *configManager;
    __block NSError *networkError = nil;
    
    void (^httpStubs)() = ^{
        [OHHTTPStubs stubRequestsPassingTest:^BOOL(NSURLRequest *request) {
            return YES;
        } withStubResponse:^OHHTTPStubsResponse*(NSURLRequest *request) {
            return [OHHTTPStubsResponse responseWithError:[NSError errorWithDomain:NSURLErrorDomain code:kCFURLErrorNotConnectedToInternet userInfo:nil]];
        }];
    };
    
    void (^configurationCompletionBlock)(NSArray *networks) = ^(NSArray *networks) {
        result = networks;
    };
    
    void (^configurationFailedBlock)(NSError *error) = ^(NSError *error) {
        networkError = error;
    };
    
    beforeAll(^{
        // Stub the network
        httpStubs();
    });
    
    it(@"Ensure json file has not been saved yet", ^{
        NSString *networksCachePath = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject];
        networksCachePath = [networksCachePath stringByAppendingPathComponent:@"SPNetworksCache"];
        NSString *filePath = [networksCachePath stringByAppendingPathComponent:@"adapters.json"];
        BOOL fileExists = [[NSFileManager defaultManager] fileExistsAtPath:filePath];
        expect(fileExists).to.beTruthy;
    });
    
    it(@"Checking json response", ^AsyncBlock{
        configManager = [[SPConfigurationRequestManager alloc] initWithCredentials:nil completionBlock:configurationCompletionBlock];
        configManager.configurationFailedBlock = configurationFailedBlock;
        [configManager requestConfiguration];
        done();
    });
    
    it(@"Verify that the network failed", ^{
        // Ok, the operation failed
        // Error returned
        expect(networkError).notTo.beNil;
        
        // Verify there was no internet connection
        expect(networkError.code).to.beGreaterThanOrEqualTo(kCFURLErrorNotConnectedToInternet);
        
        // Now expecting a fallback call to parse json from cache folder
        // configurationCompletionBlock should be called as data was finally provided
    });
    
    it(@"Verify that the data was returned", ^{
        // Data provided!
        expect(result).notTo.beNil;
    });
    
    afterAll(^{
        // Clean up
        result = nil;
        configManager = nil;
        networkError = nil;
    });
});

SpecEnd