//
//  SPActionIdValidatorTest.h
//  SponsorPaySample
//
//  Created by David Davila on 12/6/12.
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface SPActionIdValidatorTest : SenTestCase

@end
