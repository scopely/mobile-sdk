Then /^(?:T|t)he banner shows "([^\"]*)"$/ do |text|
  pause_video unless video_playing?
  screenshot_and_raise "The banner is not showing: #{text}" unless get_banner_message == text
end

Given /^I am a valid user with offers$/ do
  macro %Q|I am able to launch the application|
  # puts App.current_tag
  use_staging_urls false
  macro %Q|I am user "#{mbe_offer[:uid]}"|
  macro %Q|My Application is "#{mbe_offer[:appid]}"|
  macro %Q|My security token is "#{mbe_offer[:token]}"|
  macro %Q|I start the SDK|
  macro %Q|I request MBE offers|
  raise "No offers available" unless mbe_offers_available?
  sleep(STEP_PAUSE)
end

Given /^I request MBE offers$/ do
  switch_to_tab "MBE"
  request_mbe_offers
end

Given /^I am a valid user with an autoplay offer$/ do
  macro %Q|I am able to launch the application|
  use_staging_urls false
  macro %Q|I am user "#{mbe_autoplay_offer[:uid]}"|
  macro %Q|My Application is "#{mbe_autoplay_offer[:appid]}"|
  macro %Q|My security token is "#{mbe_autoplay_offer[:token]}"|
  macro %Q|I start the SDK|
  macro %Q|I request MBE offers|
  raise "No offers available" unless mbe_offers_available?
  sleep(STEP_PAUSE)
end

And /^(?:T|t)he video is on screen and not playing$/ do
  macro %Q|I start the engagement|
  raise "Video is playing" if video_playing?
end

And /^I am viewing the video$/ do
  macro %Q|I start the engagement|
  play_video
end

And /^I start the engagement$/ do
  start_mbe_engagement
  sleep 3
  raise "Not on engagement view" unless video_on_screen?
end

Then /^(?:T|t)he video is not playing$/ do
  raise "Video is playing" if video_playing?  
end

Then /^(?:T|t)he video is (?:still |)playing$/ do
  raise "Video is not playing" unless video_playing?  
end

And /^(?:T|t)he close button is visible$/ do
  raise "X close button is not visible" unless x_close_button_visible?
end

And /^(?:T|t)he close button is not visible$/ do
  raise "X close button is visible" if x_close_button_visible?
end

Given /^I press (?:next track|fast forward) button$/ do
  video_next_track
end

Given /^I install the offer$/ do
  install_offer
end

When /^I scrub the video to the end$/ do
  scrub_to_end_of_movie
end
