Given /^I play the video$/ do
	play_video
	sleep(STEP_PAUSE)
end

Then /^I play the video from pause$/ do
	play_video
	sleep(STEP_PAUSE)
end

Then /^I pause the video$/ do
	pause_video
	sleep(STEP_PAUSE)
end

Given /^I close the (?:offer|video|player) view$/ do
  #playback ("close_offer_view")
  unless x_close_button_visible?
    video_click_on_done if video_on_screen?
  end
  cpi_page = cpi_page?
  #click on the X close button
  click_on_x_close_button
  sleep(2)
  # click OK on the dialog
  unless cpi_page
    #playback ("click_alert_view_ok")
    # needed because of the weird stuff with adapters
    click_dialog_button "OK" if alert_dialog?
  end
  sleep(2)
end

Given /^I press the Done button on the video$/ do
  video_click_on_done
end

Then /^I wait until the video stops playing$/ do
  wait_for_video_to_end
end

Then /^I click on the youtube watermark$/ do
	playback("click_youtube_watermark")
	sleep(STEP_PAUSE)
end

Given /^I click on the X button$/ do
  click_on_x_close_button
end