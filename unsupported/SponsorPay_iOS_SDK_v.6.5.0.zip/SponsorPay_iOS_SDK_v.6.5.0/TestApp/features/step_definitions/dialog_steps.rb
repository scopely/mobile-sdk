Then /^I get an error for missing credentials$/ do
  screenshot_and_raise "Error was not displayed" unless error_no_credentials?
end

Then /^I see an error dialog$/ do
  screenshot_and_raise "No error dialog visible" unless alert_dialog?
end

Given /^I click on the "([^\"]*)" alert button$/ do |button|
  click_dialog_button "#{button}"
end