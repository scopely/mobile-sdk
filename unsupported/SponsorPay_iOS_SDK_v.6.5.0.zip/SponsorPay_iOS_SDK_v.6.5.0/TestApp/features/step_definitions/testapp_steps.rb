Given /^I am able to launch the application$/ do
  element_exists("view")
  sleep(STEP_PAUSE)
end

Given /^(?:T|t)he test app is running$/ do
  macro %Q|I am able to launch the application|
end

When /^I go to the "([^\"]*)" tab$/ do |tab_title|
  switch_to_tab tab_title unless current_tab == tab_title
  sleep(STEP_PAUSE)
end

Then /^(?:T|t)he log shows the following:$/ do |table|
  current_tab = opened_tab
  wait_for_elements_exist(["tabBarButton"], :timeout => 5)
  switch_to_tab "Log"
  sleep (1.5)
  table.raw.each do |text|
    # require 'pry'
    # binding.pry
  	text = text.first.gsub("'", %q(\\\'))
  	res = query("view {accessibilityLabel == 'Log_TextView' and text CONTAINS '#{text}'}").empty?
    screenshot_and_raise "No text found containing: #{text}" if res
  end
  switch_to_tab current_tab
end

Given /^I am using staging URLs$/ do
  use_staging_urls true
end

Given /^I close the dialog$/ do
	click_dialog_button "OK"
	sleep(2)
end

Then /^I am back to the application$/ do
	screenshot_and_raise "Not on the testapp" unless query("tabBar").size > 0
end
