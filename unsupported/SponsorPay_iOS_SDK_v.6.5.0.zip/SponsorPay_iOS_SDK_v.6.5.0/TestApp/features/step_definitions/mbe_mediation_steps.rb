 
Given /^I configure mock network as "([^\"]*)" in "([^\"]*)"$/ do |mock_option, section|
  touch "view accessibilityLabel:'ConfigureMock_Button'"
  sleep(STEP_PAUSE)
  require 'pry'
  # binding.pry
  sec = get_section section
  index_path = get_index_path(sec, mock_option)
  touch("tableViewCell indexPath:#{index_path[0]},#{index_path[1]}")
  sleep(1)
end


And /^I wait to get back to the application$/ do
  wait_for_elements_exist(["tabBarButton"], :timeout => 10)
end

And /^I start the mock engagement$/ do
  start_mbe_engagement
  sleep 2
end

Given /^I am a valid user for mediated mocked offers$/ do
  macro %Q|I am able to launch the application|
  # puts App.current_tag
  use_staging_urls false
  macro %Q|I am user "#{mbe_mock[:uid]}"|
  macro %Q|My Application is "#{mbe_mock[:appid]}"|
  macro %Q|My security token is "#{mbe_mock[:token]}"|
  macro %Q|I start the SDK|
  switch_to_tab "MBE"
  sleep(STEP_PAUSE)
end