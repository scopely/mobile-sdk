def mbe_offer 
  case ENV['DATA']
  when '@groupm'
    { uid: 'groupm', appid: '11008' , token: '52b9261869400174d9afd429780b00e6'}
  else
    { uid: 'testingisfun', appid: '10879' , token: 'f6925dc82e753e7557f44ba5b3aa9cfb'}
  end
end

def users
  ['tester_is_da_best', 'iLOVEtesting','testing_is_FUN','having_SOMUCH_fun','calabashing_is_cool','testsRdaBEST']
end

def random_user
  users.sample
end

def mbe_mock
  { uid: "#{random_user}", appid: '14639' , token: 'd25e5009f3cc014284efcd3a00b4fbfa'}
end

def mbe_autoplay_offer 
  { uid: 'testinglover', appid: '10939' , token: '433603494c1f6181d2a54d43b4189a56'}
end

def ofw 
  { uid: 'Ilovetesting', appid: '10879' , token: 'token'}
end