def response_ltid_value
  query("view accessibilityLabel:'responseLTIDField'", :text).first
end