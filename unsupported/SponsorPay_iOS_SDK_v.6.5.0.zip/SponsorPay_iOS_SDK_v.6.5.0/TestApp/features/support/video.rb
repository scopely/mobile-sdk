def video_playing?
  check_video_on_screen
  query("view:'MPVideoView'", :playbackState).first == 1
end

def video_paused?
  check_video_on_screen
  movie_view = query("view:'MPVideoView'", :playbackState)
  movie_view.empty? || movie_view.first == 2
end

def video_on_screen?
  query("view:'MPVideoView'").size > 0 || query("view:'SPBrandEngageWebView'").size > 0
end

def video_controls_on_screen?
  check_video_on_screen
  query("view:'MPTransportButton'").size > 0
end

def play_video
  unless video_playing?
    if query("view:'MPVideoView'").size > 0 
      if query("view:'MPVideoView'", :playbackState).first == 0 ||
        banner_visible?
        # needed because of the weird stuff with adapters
        touch("view:'FigPluginView'")
        sleep 3
      end
      # try 5 times
      try = 1
      until video_playing? || try > 5
        show_video_controls
        touch("view:'MPTransportButton' accessibilityLabel:'play'")
        try+=1
        sleep 0.5
      end
    else
      touch 'view'
      sleep 2
    end
    sleep 5
  end
end

def pause_video
  unless video_paused?
    show_video_controls
    touch("view:'MPTransportButton' accessibilityLabel:'pause'")
    sleep 1
  end
end

def video_next_track
  show_video_controls
  touch("view:'MPTransportButton' accessibilityLabel:'nexttrack'")
  sleep 1
end

def show_video_controls
  check_video_on_screen
  unless video_controls_on_screen?
    #simply touch any view
    touch 'view'
    sleep 1
  end
end

def wait_for_video_to_end
  screenshot_and_raise 'Video is not playing' unless video_playing?
  iOS5_family =  Calabash::Cucumber::SimulatorHelper.get_version['iOS_version'].to_f < 6
  wait_for(300) { 
    #result = 
    if iOS5_family
      query("webView css:'.action-button'").size > 0 ||
      (query("navigationButton accessibilityLabel:'Done'").size > 0 && video_paused?)
    else
      query("webView css:'div.topbar.translucent'").size > 0 || 
      (query("navigationButton accessibilityLabel:'Done'").size > 0 && video_paused?)
      # needed because of the weird stuff with adapters
    end
    #result.first["textContent"] == "Thanks for watching!" unless result.empty?
  }
  sleep 4
end

def video_click_on_done
  check_video_on_screen
  #bring the controls and pause
  pause_video
  #touch on done
  touch("navigationButton accessibilityLabel:'Done'")
  sleep 3
end

def check_video_on_screen
  raise "Video is not on screen" unless video_on_screen?
end

def scrub_to_end_of_movie
  show_video_controls
  query "view:'MPDetailSlider'", [{setValue:get_movie_duration},{animated:1}]
end

def get_movie_duration
  show_video_controls
  query("view:'MPDetailSlider'", :duration).first
end

