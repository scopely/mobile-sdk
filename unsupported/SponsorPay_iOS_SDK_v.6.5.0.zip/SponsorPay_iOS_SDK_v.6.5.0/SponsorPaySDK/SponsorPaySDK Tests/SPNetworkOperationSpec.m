//
//  SPNetworkOperationSpec.m
//  SponsorPayTestApp
//
//  Created by Piotr  on 26/06/14.
//  Copyright 2014 SponsorPay. All rights reserved.
//

#import <Specta/Specta.h>
#define EXP_SHORTHAND
#import <Expecta/Expecta.h>

#import "SPNetworkOperation.h"
#import "SPURLGenerator.h"
#import "SPSignature.h"
#import "SPCredentials.h"

SpecBegin(SPNetworkOperation)

// Test for checking the network operation and response of data
// The following test are performed:
// 1. Check the network opertion calls its blocks
// 2. Check response code equals to 200
// 3. Check headers are available
// 4. Check response data is not empty
// 5. Find signuture in header
// 6. Verify signature with response data

describe(@"SPNetworkOperation - checks network operation", ^{
    __block SPNetworkOperation *operation;
    __block SPCredentials *credentials;
    __block NSURL *url;

    beforeAll(^{
        credentials = [[SPCredentials alloc] init];
        credentials.appId = @"8061";
        credentials.securityToken = @"63adc1aea63b7a8d9666335bc63459ba";

        SPURLGenerator *urlGenerator = [[SPURLGenerator alloc] initWithEndpoint:SPURLEndpointAdaptersConfig];
        urlGenerator.credentials = credentials;
        url = [urlGenerator signedURLWithSecretToken:credentials.securityToken];

        operation = [[SPNetworkOperation alloc] initWithUrl:url];
    });

    it(@"SPNetworkOperation operation call test", ^AsyncBlock{
        operation.networkOperationSuccessBlock = ^{
            expect(nil);
        };

        operation.networkOperationFailedBlock = ^(NSError *error){
            expect(error).to.beTruthy;
        };

        [operation start];
        done();
    });

    describe(@"SPNetworkOperation operation response test", ^{
        it(@"Opertion header", ^{
            // Vrified status code is 200
            expect(operation.response.statusCode).to.equal(200);

            // Headers available
            expect([operation.response allHeaderFields]).notTo.beNil;
        });

        it(@"Operation response content", ^{
            // Checked if the response data is not empty
            NSString *responseString = [[NSString alloc] initWithData:operation.responseData encoding:NSUTF8StringEncoding];
            expect([responseString length]).to.beGreaterThan(0);
        });

        it(@"Opertion repsonse signature", ^{
            // Checked if the signature contains string
            NSString *responseSignature = [operation.response allHeaderFields][@"X-Sponsorpay-Response-Signature"];
            expect([responseSignature length]).to.beGreaterThan(0);

            // Checked if the signature is valid
            NSString *responseString = [[NSString alloc] initWithData:operation.responseData encoding:NSUTF8StringEncoding];
            BOOL isValid = [SPSignature isSignatureValid:responseSignature forText:responseString secretToken:credentials.securityToken];
            expect(isValid).to.beTruthy;
        });
    });

    afterAll(^{
        credentials = nil;
        operation = nil;
        url = nil;
    });
});

SpecEnd
