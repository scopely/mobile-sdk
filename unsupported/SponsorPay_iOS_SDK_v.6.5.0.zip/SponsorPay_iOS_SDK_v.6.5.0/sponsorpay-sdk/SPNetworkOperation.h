//
//  SPNetworkOperation.h
//  SponsorPayTestApp
//
//  Created by Daniel Barden on 11/11/13.
//  Copyright (c) 2013 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^SPNetworkOperationFailedBlock)(NSError *error);
typedef void (^SPNetworkOperationSuccessBlock)();

@interface SPNetworkOperation : NSOperation {
	BOOL _isFinished;
    BOOL _isExecuting;
}

@property (strong, nonatomic, readonly) NSHTTPURLResponse *response;
@property (strong, nonatomic, readonly) NSMutableData *responseData;
@property (strong, nonatomic, readonly) NSURL *url;

/**
 Collection of header parameters
 */
@property (nonatomic, strong) NSDictionary *headerParameters;

/**
 Block for handling failed request. This block property is called when remote network operation fails.
 This block takes one argument `error`.
 */
@property (copy) SPNetworkOperationFailedBlock  networkOperationFailedBlock;

/**
 Block for handling success request. This block property is called when remote network operation succeeded.
 */
@property (copy) SPNetworkOperationSuccessBlock  networkOperationSuccessBlock;

/**
 Initializes an `SPNetworkOperation` object with the specified URL.

 @param url The URL for the HTTP call.
 */
- (id) initWithUrl:(NSURL *)url;

@end
