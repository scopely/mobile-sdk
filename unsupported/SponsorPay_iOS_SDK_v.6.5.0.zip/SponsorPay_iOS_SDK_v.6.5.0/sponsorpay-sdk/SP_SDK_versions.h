//  SP_SDK_versions.h
//  SponsorPay iOS SDK
//
//  Copyright 2011-2013 SponsorPay. All rights reserved.
//

// SponsorPay iOS SDK v. 6.1.0
#define SP_SDK_MAJOR_RELEASE_VERSION_NUMBER 6
#define SP_SDK_MINOR_RELEASE_VERSION_NUMBER 5
#define SP_SDK_FIX_RELEASE_VERSION_NUMBER 0
