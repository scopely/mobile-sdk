//
//  SPSystemLogger.h
//  SponsorPayTestApp
//
//  Created by Daniel Barden on 07/02/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import "SPLogAppender.h"

@interface SPSystemLogger : NSObject<SPLogAppender>

@end
