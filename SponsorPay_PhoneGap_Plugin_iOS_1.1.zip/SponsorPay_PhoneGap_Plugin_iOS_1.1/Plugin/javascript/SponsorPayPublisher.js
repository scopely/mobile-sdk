var SponsorPayPublisher = function(){
    
}

SponsorPayPublisher.prototype.requestNewCoins = function(userId, appId, securityToken, lastTransactionId,
                                                         successCallback, failureCallback) {
    
    Cordova.exec(successCallback, failureCallback, "SponsorPayPlugin", "requestNewCoins",
                 [ userId, appId, securityToken, lastTransactionId ]);
}

SponsorPayPublisher.prototype.showOfferWall = function(userId, shouldStayOpen, appId, customParams) {
    Cordova.exec(null, null, "SponsorPayPlugin", "showOfferWall",
                 [ userId, appId, shouldStayOpen, customParams ]);
}

SponsorPayPublisher.prototype.showVersion = function(callback) {
    Cordova.exec(callback, null, "SponsorPayPlugin", "fetchSDKVersion", [ ]);

}
