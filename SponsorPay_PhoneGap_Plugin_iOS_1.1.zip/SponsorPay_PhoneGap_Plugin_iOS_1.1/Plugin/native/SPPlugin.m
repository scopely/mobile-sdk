//
//  SPPlugin.m
//  PhoneGap iOS SDK
//
//  Created by David Davila on 7/2/12.
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import "SPPlugin.h"
#import "SPAdvertiserManager.h"
#import "SPOfferWallViewController.h"
#import "SPVirtualCurrencyServerConnector.h"
#import "SP_SDK_versions.h"



@interface SPPlugin()

@property (readonly) NSDictionary *pluginParameters;

@property (retain) SPOfferWallViewController *offerWallViewController;
@property (nonatomic, retain) NSMutableSet *pendingVCSConnections;
@property (nonatomic, retain) NSMutableDictionary *pendingVCSCallbackIds;

@end

@implementation SPPlugin

#define PLUGIN_VERSION @"1.1"



#pragma mark - Init

-(CDVPlugin*)initWithWebView:(UIWebView*)theWebView
{
    self = [super initWithWebView:theWebView];
    if(self)
    {
        [SPUrlFactory customParametersProvider:self];
    }
    return self;
}


#pragma mark - SPUrlParametersProvider

@synthesize pluginParameters;

-(NSDictionary *)pluginParameters
{
    if (!pluginParameters)
    {
        pluginParameters = [[NSDictionary alloc]initWithObjectsAndKeys:
                            @"phonegap", @"framework",
                            PLUGIN_VERSION, @"plugin_version",
                            nil];

    }
    return pluginParameters;
}

- (NSDictionary *)dictionaryWithKeyValueParameters
{
    return [NSDictionary dictionaryWithDictionary:self.pluginParameters];
}

#pragma mark - Advertiser callback

- (void)sendAdvertiserCallback:(CDVInvokedUrlCommand*)command
{
    NSLog(@"sendAdvertiserCallback invoked");
    NSString *appId = [command.arguments objectAtIndex:0];
    [[SPAdvertiserManager sharedManager] reportOfferCompleted:appId];
}

#pragma mark - OfferWall
@synthesize offerWallViewController;

- (void)showOfferWall:(CDVInvokedUrlCommand*)command
{
    NSArray *arguments = command.arguments;
    NSString *userId = [arguments objectAtIndex:0];
    NSString *appId = [arguments objectAtIndex:1];
    BOOL shouldStayOpen = [[arguments objectAtIndex:2] boolValue];
    
    if (self.offerWallViewController) {
        [self.offerWallViewController.view removeFromSuperview];
        self.offerWallViewController = nil;
    }
    
    self.offerWallViewController = [[SPOfferWallViewController alloc] initWithUserId:userId
                                                                          appId:appId];
    self.offerWallViewController.shouldFinishOnRedirect = !shouldStayOpen;
    self.offerWallViewController.delegate = self;
    
    [self.viewController.view addSubview:self.offerWallViewController.view];
}

- (void)offerWallViewController:(SPOfferWallViewController *)offerwallVC
           isFinishedWithStatus:(int)status {
	[self.offerWallViewController.view removeFromSuperview];
    self.offerWallViewController = nil;
}

#pragma mark - VCS
@synthesize pendingVCSConnections = _pendingVCSConnections, pendingVCSCallbackIds = _pendingVCSCallbackIds;

#define kSPInitialCapacityForMultipleVCSConnections 2
- (NSMutableSet *)pendingVCSConnections {
    if (!_pendingVCSConnections) {
        _pendingVCSConnections = [[NSMutableSet alloc] initWithCapacity:kSPInitialCapacityForMultipleVCSConnections];
    }
    return _pendingVCSConnections;
}

- (NSMutableDictionary *)pendingVCSCallbackIds {
    if (!_pendingVCSCallbackIds) {
        _pendingVCSCallbackIds = [[NSMutableDictionary alloc] initWithCapacity:kSPInitialCapacityForMultipleVCSConnections];
    }
    return _pendingVCSCallbackIds;
}


- (void)requestNewCoins:(CDVInvokedUrlCommand*)command
{
    NSArray *arguments = command.arguments;
    NSString *userId = [arguments objectAtIndex:0];
    NSString *appId = [arguments objectAtIndex:1];
    NSString *securityToken = [arguments objectAtIndex:2];
    NSString *callbackId = command.callbackId;
    
    SPVirtualCurrencyServerConnector *vcsConnection =
    [[SPVirtualCurrencyServerConnector alloc] initWithUserId:userId
                                                        appId:appId
                                                secretToken:securityToken];
    vcsConnection.delegate = self;

    [self.pendingVCSConnections addObject:vcsConnection];
    [self.pendingVCSCallbackIds setObject:callbackId forKey:[self keyForCallbackIdsDictionaryWithObject:vcsConnection]];
    
    [vcsConnection fetchDeltaOfCoins];
    [vcsConnection release];
}

- (void)virtualCurrencyConnector:(SPVirtualCurrencyServerConnector *)vcConnector
  didReceiveDeltaOfCoinsResponse:(double)deltaOfCoins
             latestTransactionId:(NSString *)transactionId
{
    NSDictionary * resultsDictionary = [NSDictionary dictionaryWithObjectsAndKeys:
                                        [NSNumber numberWithDouble:deltaOfCoins], @"DeltaOfCoins",
                                        transactionId, @"LastTransactionId",
                                        vcConnector.latestTransactionId, @"LastSentTransactionId",
                                        nil];
    CDVPluginResult *result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsDictionary:resultsDictionary];
    
    [self writeJavascript:[result toSuccessCallbackString:[self callbackIDForVCSConnection:vcConnector]]];
    
    [self.pendingVCSConnections removeObject:vcConnector];
}

- (void)virtualCurrencyConnector:(SPVirtualCurrencyServerConnector *)vcConnector
                 failedWithError:(SPVirtualCurrencyRequestErrorType)error
                       errorCode:(NSString *)errorCode
                    errorMessage:(NSString *)errorMessage
{
    NSDictionary * resultsDictionary = [NSDictionary dictionaryWithObjectsAndKeys:
                                        [NSNumber numberWithInt:error], @"ErrorType",
                                        errorCode, @"ErrorCode",
                                        errorMessage, @"ErrorMessage",
                                        nil];
    CDVPluginResult *result = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsDictionary:resultsDictionary];
    [self writeJavascript:[result toErrorCallbackString:[self callbackIDForVCSConnection:vcConnector]]];
    
    [self.pendingVCSConnections removeObject:vcConnector];
}

- (NSString *)callbackIDForVCSConnection:(SPVirtualCurrencyServerConnector *)connection
{
    id callbackKey = [self keyForCallbackIdsDictionaryWithObject:connection];
    NSString *callbackId = [[self.pendingVCSCallbackIds objectForKey:callbackKey] retain];
    [self.pendingVCSCallbackIds removeObjectForKey:callbackKey];
    return [callbackId autorelease];
}

- (id)keyForCallbackIdsDictionaryWithObject:(id)object {
    return [NSNumber numberWithUnsignedInt:[object hash]];
}

#pragma mark - SDK version

- (void)fetchSDKVersion:(CDVInvokedUrlCommand*)command
{
    CDVPluginResult *result;
    NSString *resultString = [NSString stringWithFormat:@"%d.%d.%d", SP_SDK_MAJOR_RELEASE_VERSION_NUMBER,
                              SP_SDK_MINOR_RELEASE_VERSION_NUMBER, SP_SDK_FIX_RELEASE_VERSION_NUMBER];
    result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:resultString];
    [self writeJavascript:[result toSuccessCallbackString:command.callbackId]];
}


#pragma mark - Memory management
- (void) dealloc
{
    [pluginParameters release];
    self.pendingVCSCallbackIds = nil;
    self.pendingVCSConnections = nil;
    [super dealloc];
}

@end
