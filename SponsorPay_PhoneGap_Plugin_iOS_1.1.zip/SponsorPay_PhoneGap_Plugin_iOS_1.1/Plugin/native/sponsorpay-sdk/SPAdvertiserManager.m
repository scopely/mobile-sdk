//
//  SPAdvertiserManager.m
//  SponsorPay iOS SDK
//
//  Copyright 2011 SponsorPay. All rights reserved.
//


#import <UIKit/UIDevice.h>
#import "SPAdvertiserManager.h"
#import "SPUrlFactory.h"
#import "SPAppIdValidator.h"
#import "SP_SDK_versions.h"


#define ADVERTISER_BASE_URL                         @"https://service.sponsorpay.com/installs"
#define URL_PARAM_SUCCESSFUL_ANSWER_RECEIVED_KEY    @"answer_received"


// Max number of times to retry
#define MAX_RETRIES_PER_SESSION	5

// Initial delay for retries.  Subsequent delays are multiples of this.
#define INITIAL_RETRY_DELAY		5.0

static SPAdvertiserManager *sharedAdManager = nil;
static NSString *advertiserBaseUrl = ADVERTISER_BASE_URL;

// Private methods
@interface SPAdvertiserManager()
- (void)reportOfferCompletedToServer;
- (void)retry;
@end

// The implementation of SPAdManager
@implementation SPAdvertiserManager

// Factory Method
+ (SPAdvertiserManager*)sharedManager {
    if (!sharedAdManager) {
        sharedAdManager = [[super allocWithZone:NULL] init];
    }
    return sharedAdManager;
}

- (id)init {
	if (self = [super init]) {
        ;
    }
	return self;
}

// Public method to report the offer to the server
- (void)reportOfferCompleted: (NSString *)_appId {
    [SPAppIdValidator validateOrThrow:_appId];
    appId = [_appId retain];
	[self reportOfferCompletedToServer];
}

// Initiates the actual network call to the server
- (void) reportOfferCompletedToServer {
	SPUrlFactory *urlFactory = [SPUrlFactory urlFactoryWithDefaultParametersProvidersWithBaseUrl:advertiserBaseUrl
                                                                 shouldUseSystemDeviceIdentifier:NO];
    
    [urlFactory addKey:URL_PARAM_APP_ID withValue:appId];
    [urlFactory addKey:URL_PARAM_SUCCESSFUL_ANSWER_RECEIVED_KEY
             withValue:[SPPersistence didAdvertiserCallbackSucceed] ? @"1" : @"0"];
    
    [urlFactory addDeviceInfo];
    
    NSString *urlString = [urlFactory urlString];

	NSLog(@"SponsorPay Advertiser SDK will send callback using url: %@", urlString);

	NSURL *url = [NSURL URLWithString:urlString];
	
	if (url != nil) {
		NSURLRequest *theRequest=[NSURLRequest requestWithURL:url
												  cachePolicy:NSURLRequestUseProtocolCachePolicy
											  timeoutInterval:60.0];
		
		NSURLConnection *urlConnection=[[NSURLConnection alloc] initWithRequest:theRequest delegate:self];

		if (!urlConnection ) {
			[self retry];
		}
    }
}

// Retry the call to the server.  If it fails for MAX_RETRIES_PER_SESSION, it stops retrying
// for this run of the app.
//
// Each retry waits for INITIAL_RETRY_DELAY * the number of retries for this session.
//

- (void)retry {
	
	if (++retryCount < MAX_RETRIES_PER_SESSION) {
		
		NSTimeInterval retryDelay = INITIAL_RETRY_DELAY * retryCount;
//		NSLog(@"Waiting %f seconds and then retrying.", retryDelay);
		
		[self performSelector:@selector(reportOfferCompletedToServer) 
				   withObject:nil 
				   afterDelay:retryDelay];
	}
	else {
//		NSLog(@"Done retrying, failed for this session.");
	}
}
#pragma mark -

#pragma mark NSURLConnection delegate methods
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
	NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *) response;
	NSLog(@"Advertiser callback received response status code: %d", [httpResponse statusCode]);
	
	if ([httpResponse statusCode] != 200) {
//		NSLog(@"Request failed.");
		[self retry];
	} else {
        [SPPersistence setDidAdvertiserCallbackSucceed:YES];
    }

    [connection cancel];
    [connection release];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    // release the connection
    [connection release];
	
//    NSLog(@"Connection failed! Error - %@ %@",
//          [error localizedDescription],
//          [[error userInfo] objectForKey:NSURLErrorFailingURLStringErrorKey]);
	
	[self retry];
}

#pragma mark -

+ (void)overrideBaseUrlWithUrl:(NSString *)newUrl {
    [advertiserBaseUrl release];
    advertiserBaseUrl = [newUrl retain];
}

+ (void)restoreBaseUrlToDefault {
    [SPAdvertiserManager overrideBaseUrlWithUrl:ADVERTISER_BASE_URL];
}

// Implementations of base methods to ensure singleton behaviour

+ (id)allocWithZone:(NSZone *)zone {
    return [[self sharedManager] retain];
}

- (id)copyWithZone:(NSZone *)zone {
    return self;
}

- (id)retain {
    return self;
}

- (NSUInteger)retainCount {
    return NSUIntegerMax;  //denotes an object that cannot be released
}

- (oneway void)release {
    //do nothing
}

- (id)autorelease {
    return self;
}

@end
