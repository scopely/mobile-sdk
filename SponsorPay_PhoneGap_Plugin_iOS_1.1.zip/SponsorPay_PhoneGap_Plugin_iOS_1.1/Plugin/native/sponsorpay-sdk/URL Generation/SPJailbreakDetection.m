//
//  SPJailbreakDetection.m
//  SponsorPay iOS SDK
//
//  Copyright 2011 SponsorPay. All rights reserved.
//

#import "SPJailbreakDetection.h"

@implementation SPJailbreakDetection

static const char* jailbreakApps[] = {
	"/Applications/Cydia.app", 
	"/Applications/limera1n.app", 
	"/Applications/greenpois0n.app", 
	"/Applications/blackra1n.app",
	"/Applications/blacksn0w.app",
	"/Applications/redsn0w.app",
	NULL,
};

// Check for apps that are known to be installed when jailbreaking
+ (BOOL) isJailBroken {
	
	BOOL ret = NO;
	for (int i = 0; jailbreakApps[i] != NULL; ++i) {
		NSString *appPath = [NSString stringWithUTF8String:jailbreakApps[i]];
		if ([[NSFileManager defaultManager] fileExistsAtPath:appPath]) {
			ret = YES;
			break;
		}
	}
	
	return ret;
}

@end
