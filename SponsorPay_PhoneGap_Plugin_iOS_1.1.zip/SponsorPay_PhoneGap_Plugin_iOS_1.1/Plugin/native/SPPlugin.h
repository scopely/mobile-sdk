//
//  SPPlugin.h
//  PhoneGap iOS SDK
//
//  Created by David Davila on 7/2/12.
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import <Cordova/CDV.h>
#import "SPUrlFactory.h"


@interface SPPlugin : CDVPlugin <SPUrlParametersProvider> {
    @private
    NSDictionary *pluginParameters;
}

- (void)sendAdvertiserCallback:(CDVInvokedUrlCommand*)command;

- (void)showOfferWall:(CDVInvokedUrlCommand*)command;

- (void)requestNewCoins:(CDVInvokedUrlCommand*)command;

- (void)fetchSDKVersion:(CDVInvokedUrlCommand*)command;

- (NSDictionary *)dictionaryWithKeyValueParameters;

@end
