# SponsorPay SDK - PhoneGap (Apache Cordova) Plugin for iOS

## DESCRIPTION

This plugin provides a way of using the native SponsorPay iOS SDK from within a PhoneGap (Cordova) application.

## INSTALLING THE PLUGIN

1. Copy the files inside the provided "javascript" folder into the "www" folder in your own Cordova project folder. Add references to these files to your own html files from where you plan to use the plugin.
2. Drag the contents of the provided "native" folder into your Cordova project's "Plugins" folder in XCode.
	- When XCode prompts you, make sure "Copy items into destination group's folder (if needed)" and "Create groups for any added folders" are checked.
3. Add these two entries to your "Cordova.plist" file
	1. Inside the **Plugins** group add a new entry with key: `SponsorPayPlugin` and value: `SPPlugin`.
	2. Inside the **ExternalHosts** group add a new `String` with value `*`. This is required because the SponsorPay's Mobile OfferWall can access a number of hosts to load its offers and corresponding static resources.

## USING THE PLUGIN

We provide an ExampleApp consisting on a Cordova XCode project which integrates the SponsorPay plugin and demostrates how to use all of its features. You can take a look at its "main.js" file for examples on how to send the Advertiser Callback, show the OfferWall, and query the Virtual Currency Server for the amount of coins earned by the user.