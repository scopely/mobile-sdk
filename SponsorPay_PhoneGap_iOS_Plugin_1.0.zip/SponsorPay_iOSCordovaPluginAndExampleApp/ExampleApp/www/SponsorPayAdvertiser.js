var SponsorPayAdvertiser = function(){
    
}

SponsorPayAdvertiser.prototype.sendAdvertiserCallback = function(appId) {
    
    Cordova.exec(null, null, "SponsorPayPlugin", "sendAdvertiserCallback", [ appId ]);
}

