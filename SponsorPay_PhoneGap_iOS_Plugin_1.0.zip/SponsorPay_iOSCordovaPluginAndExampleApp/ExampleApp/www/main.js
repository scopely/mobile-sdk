// Cordova is loaded and it is now safe to make calls Cordova methods
//
function onDeviceReady() {
	document.addEventListener("pause", onPause, false);
	appId.value = window.localStorage.getItem("appId");
	userId.value = window.localStorage.getItem("userId");
	securityToken.value = window.localStorage.getItem("securityToken");
    deviceInfo();	
}

// Handle the pause event
//
function onPause() {
	window.localStorage.setItem("appId", appId.value);
	window.localStorage.setItem("userId", userId.value);
	window.localStorage.setItem("securityToken", securityToken.value);
}

var deviceInfo = function() {
	spp.showVersion(function(a) {
		document.getElementById("sdkVersion").innerHTML = a;
	})
	document.getElementById("platform").innerHTML = device.platform;
	document.getElementById("version").innerHTML = device.version;
	document.getElementById("uuid").innerHTML = device.uuid;
	document.getElementById("name").innerHTML = device.name;
	document.getElementById("width").innerHTML = screen.width;
	document.getElementById("height").innerHTML = screen.height;
	document.getElementById("colorDepth").innerHTML = screen.colorDepth;
};

var spp = new SponsorPayPublisher()

function showOfferWall() {
	spp.showOfferWall(userId.value, true, appId.value, null);
	return false;
}

function requestNewCoins() {
	spp.requestNewCoins(userId.value, appId.value, securityToken.value, null,
        function(a) {
            displayDeltaOfCoins(a)
        }, function(e) {
            displayRequestNewCoinsError(e)
        });


	return false;
}

function displayDeltaOfCoins(deltaOfCoinsResponse) {
	alert('Delta of coins: ' + deltaOfCoinsResponse.DeltaOfCoins
			+ '\nLast transaction id: '
			+ deltaOfCoinsResponse.LastTransactionId + '\nTransaction used: '
			+ deltaOfCoinsResponse.LastSentTransactionId)
}

function displayRequestNewCoinsError(errorResponse) {
	console.log(errorResponse);
	alert('Error code: ' + errorResponse.ErrorCode + '\nError message: '
			+ errorResponse.ErrorMessage + '\nError type: '
			+ errorResponse.ErrorType);
}

var spa = new SponsorPayAdvertiser();

function sendAdvertiserCallback() {
	spa.sendAdvertiserCallback(appId.value);
	return false;
}
