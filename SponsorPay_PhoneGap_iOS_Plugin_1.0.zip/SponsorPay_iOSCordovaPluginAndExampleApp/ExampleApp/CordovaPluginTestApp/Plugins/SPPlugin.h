//
//  SPPublisherPlugin.h
//  CordovaPluginTestApp
//
//  Created by David Davila on 7/2/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Cordova/CDV.h>

@interface SPPlugin : CDVPlugin

- (void)sendAdvertiserCallback:(NSMutableArray *)arguments withDict:(NSMutableDictionary *)options;

- (void)showOfferWall:(NSMutableArray *)arguments withDict:(NSMutableDictionary *)options;

- (void)requestNewCoins:(NSMutableArray *)arguments withDict:(NSMutableDictionary *)options;

- (void)fetchSDKVersion:(NSMutableArray *)arguments withDict:(NSMutableDictionary *)options;

@end
