//
//  SPUrlFactory.h
//  SponsorPay iOS SDK
//
//  Copyright 2011 SponsorPay. All rights reserved.
//


#import <Foundation/Foundation.h>

//#define kSPShouldNotSendPlainMACAddress
//#define kSPShouldNotSendMD5MacAddress
//#define kSPShouldNotSendSHA1MacAddress
//#define kSPShouldNotSendSystemDeviceIdentifier
//#define kSPShouldNotSendOpenUDID
//#define kSPShouldNotSendSecureUDID

#define URL_PARAM_APP_ID                    @"appid"
#define URL_PARAM_USER_ID                   @"uid"
#define URL_PARAM_ALLOW_CAMPAIGN            @"allow_campaign"
#define URL_PARAM_ALLOW_CAMPAIGN_VALUE_ON   @"on"
#define URL_PARAM_SKIN                      @"skin"
#define URL_PARAM_OFFSET                    @"offset"
#define URL_PARAM_BACKGROUND                @"background"

#define URL_PARAM_DEVICE_ID             @"device_id"
#define URL_PARAM_MAC_ADDRESS           @"mac_address"
#define URL_PARAM_MAC_ADDRESS_SHA1      @"sha1_mac"
#define URL_PARAM_MAC_ADDRESS_MD5       @"md5_mac"
#define URL_PARAM_OPENUDID              @"openudid"
#define URL_PARAM_SECUREUDID            @"secureudid"

#define kSPErrorDomain @"SPErrorDomain"
#define kSPErrorLoggableDescription @"SPErrorLoggableDescription"

@protocol SPUrlParametersProvider
@required
- (NSDictionary *)dictionaryWithKeyValueParameters;
@end

/**
 * Provides a more convenient way of creating a URL string which can include key value parameters.
 * Can add host device information to the created URL string.
 **/
@interface SPUrlFactory : NSObject {
    NSString *_baseUrl;
    NSMutableDictionary *_urlParamsDictionary;
    NSMutableSet *_urlParamsProviders;
}

/**
 * Designated initializer. Will start building the URL string on top of the provided base URL.
 **/
- (id)initWithBaseUrl:(NSString *)theUrl sdkVersionValue:(int)versionValue;

/**
 * Adds a key-value parameter with the specified string key and the provided string value
 **/
- (void)addKey:(NSString *)key withValue:(NSString *)value;

/**
 * Adds a key-value parameter with the specified string key and the provided integer value
 **/
- (void)addKey:(NSString *)key withIntegerValue:(int)intValue;

- (void)addParametersProvider:(id<SPUrlParametersProvider>)paramsProvider;

/**
 * Adds the device information key-value parameters to the built string.
 **/
- (void)addDeviceInfo;

/**
 * Builds and returns the URL string.
 **/
- (NSString *)urlString;

/**
 * Builds and returns the URL string including a signature parameter.
 * Url parameters will be signed using the provided secretToken.
 **/
- (NSString *)urlStringWithSignatureForSecretKey:(NSString *)secretToken;

+ (SPUrlFactory *)urlFactoryWithDefaultParametersProvidersWithBaseUrl:(NSString *)baseUrl
                                                      sdkVersionValue:(int)versionValue
                                      shouldUseSystemDeviceIdentifier:(BOOL)useSystemDeviceIdentifier;
@end

@interface SPMacAddressProvider : NSObject <SPUrlParametersProvider> {
    NSString *_macAddressPlain;
}

@property (readonly) NSString *macAddressPlain;

- (NSString *)fetchPlainMacAddressOrFailWithError:(NSError **)error;

@end

@interface SPSHA1MacAddressProvider : SPMacAddressProvider {
    NSString *_macAddressSHA1;
}

@property (readonly) NSString *macAddressSHA1;

@end

@interface SPMD5MacAddressProvider : SPMacAddressProvider {
    NSString *_macAddressMD5;
}

@property (readonly) NSString *macAddressMD5;

@end

@interface SPOpenUDIDProvider : NSObject <SPUrlParametersProvider>
@end

@interface SPSecureUDIDProvider : NSObject <SPUrlParametersProvider>
@end

@interface SPSystemUDIDProvider : NSObject <SPUrlParametersProvider>
@end
