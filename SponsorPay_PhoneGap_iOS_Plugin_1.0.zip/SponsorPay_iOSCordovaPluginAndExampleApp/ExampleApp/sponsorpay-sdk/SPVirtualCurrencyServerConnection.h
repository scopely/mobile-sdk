//
//  SPVirtualCurrencyConnector.h
//  SponsorPaySample
//
//  Created by David Davila on 9/23/11.
//  Copyright (c) 2011 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SPVirtualCurrencyServerConnection : NSObject {
    NSString *appId;
	NSString *userId;
	NSString *secretToken;
    
    int responseStatusCode;
    NSMutableData *responseData;
    NSString *responseSignature;

    id delegate;
    BOOL shouldLogVerbosely;
    
    NSURLConnection *currentConnection;
}

@property (retain) NSString *appId;
@property (retain) NSString *userId;
@property (retain) NSString *secretToken;
@property (retain) NSString *responseSignature;
@property (retain) NSString *latestTransactionId;
@property (retain) id delegate;
@property BOOL shouldLogVerbosely;
@property (retain) NSString *lastSentTransactionId;

- (id)initWithUserId:(NSString *)theUserId
               appId: (NSString *)theAppId
         secretToken:(NSString *)theSecretToken;

- (void)fetchDeltaOfCoins;

@end

typedef enum {
    NO_ERROR,
    ERROR_NO_INTERNET_CONNECTION,
    ERROR_INVALID_RESPONSE,
    ERROR_INVALID_RESPONSE_SIGNATURE,
    SERVER_RETURNED_ERROR,
    ERROR_OTHER
} SPVirtualCurrencyRequestErrorType;

@protocol SPVirtualCurrencyConnectionDelegate
@optional
- (void)virtualCurrencyConnector:(SPVirtualCurrencyServerConnection *)vcConnector
  didReceiveDeltaOfCoinsResponse:(double)deltaOfCoins
             latestTransactionId:(NSString *)transactionId;

- (void)virtualCurrencyConnector:(SPVirtualCurrencyServerConnection *)vcConnector
                 failedWithError:(SPVirtualCurrencyRequestErrorType)error
                       errorCode:(NSString *)errorCode
                    errorMessage:(NSString *)errorMessage;
@end