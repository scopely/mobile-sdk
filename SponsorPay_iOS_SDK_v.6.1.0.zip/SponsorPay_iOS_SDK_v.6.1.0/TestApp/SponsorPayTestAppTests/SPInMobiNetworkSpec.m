//
//  SPInMobiNetworkSpec.m
//  SponsorPayTestApp
//
//  Created by Daniel Barden on 16/04/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import <Specta/Specta.h>
#define EXP_SHORTHAND
#import <Expecta/Expecta.h>

#import "SPInMobiNetwork.h"

SpecBegin(SPInMobiNetwork)

describe(@"SPInMobiNetwork", ^{
    __block SPInMobiNetwork *sut;
    beforeEach(^{
        sut = [[SPInMobiNetwork alloc] init];
    });

    it(@"should contain an interstitial adapter", ^{
        expect(sut.interstitialAdapter).toNot.beNil();
    });

    it(@"should not start the SDK when appId is invalid", ^{
        BOOL sdkStarted = [sut startSDK:nil];
        expect(sdkStarted).to.beFalsy();

        sdkStarted = [sut startSDK:@{@"SPInMobiAppId": @""}];
        expect(sdkStarted).to.beFalsy();
    });

    it(@"should start the SDK when appId is valid", ^{
        BOOL sdkStarted = [sut startSDK:@{@"SPInMobiAppId": @"434"}];
        expect(sdkStarted).to.beTruthy();
    });
});

SpecEnd
