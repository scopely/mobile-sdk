//
//  SponsorPayTestAppTests.m
//  SponsorPayTestAppTests
//
//  Created by Daniel Barden on 23/02/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#define EXP_SHORTHAND

#import <Specta/Specta.h>
#import <Expecta/Expecta.h>

SpecBegin(ClassToTest)

describe(@"Something", ^{
    it(@"should do something", ^{
        expect(@"ok").to.equal(@"ok");
    });
});

SpecEnd
