//
//  SPOfferWallLaunchViewController.h
//  SponsorPay Sample App
//
//  Created by David Davila on 1/14/13.
// Copyright 2011-2013 SponsorPay. All rights reserved.
//

#import "SPOfferWallLaunchViewController.h"
#import "SPSettingsViewController.h"

static NSString *const SPPersistedCloseOnFinishKey = @"SPPersistedCloseOnFinishKey";


@interface SPOfferWallLaunchViewController ()

@end

@implementation SPOfferWallLaunchViewController {
    CGRect _parametersGroupFrame;
    CGRect _launchOfferWallButtonFrame;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    _parametersGroupFrame = self.parametersGroup.frame;
    _launchOfferWallButtonFrame = self.launchOfferWallButton.frame;
    [self restorePersistedUserEnteredValues];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self adjustUIToInterfaceOrientation:[[UIApplication sharedApplication] statusBarOrientation]];
}

- (void)viewWillDisappear:(BOOL)animated // TODO: move up
{
    [self persistUserEnteredValues];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - OfferWall

- (IBAction)launchOfferWall
{
    @try {
        SPOfferWallViewController *offerWallVC =
        [SponsorPaySDK offerWallViewControllerForCredentials:self.lastCredentialsToken];
        offerWallVC.delegate = self;
        offerWallVC.shouldFinishOnRedirect = self.closeOnFinishSwitch.on;
        [offerWallVC showOfferWallWithParentViewController:self];
    } @catch (NSException *exception) {
        [self showSDKException:exception];
    }
}

- (void)offerWallViewController:(SPOfferWallViewController *)offerwallVC
           isFinishedWithStatus:(int)status {
	SPLogDebug(@"Did receive SPOfferWallViewController callback with status: %d", status);
}

#pragma mark -

- (IBAction)showCustomParamsController
{
    SPSettingsViewController *settingsViewController = [[SPSettingsViewController alloc] init];

    [self presentViewController:settingsViewController animated:YES completion:nil];
}

- (void)persistUserEnteredValues
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setBool:self.closeOnFinishSwitch.on forKey:SPPersistedCloseOnFinishKey];
    [defaults synchronize];
}

- (void)restorePersistedUserEnteredValues
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    self.closeOnFinishSwitch.on = [defaults boolForKey:SPPersistedCloseOnFinishKey];
}

- (void)adjustUIToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
{
    static const CGFloat halfMargin = 2;
    
    if (UIInterfaceOrientationIsLandscape(toInterfaceOrientation)) {
        CGRect leftBlock = self.parametersGroup.frame;
        leftBlock.origin.x = halfMargin * 2;
        leftBlock.size.width = (self.view.frame.size.width / 2) - (3 * halfMargin);
        self.parametersGroup.frame = leftBlock;
        
        CGRect launchOFWBlock = self.launchOfferWallButton.frame;
        launchOFWBlock.origin.x = leftBlock.origin.x;
        launchOFWBlock.origin.y = leftBlock.origin.y + leftBlock.size.height + 2 * halfMargin;
        launchOFWBlock.size.width = leftBlock.size.width;
        self.launchOfferWallButton.frame = launchOFWBlock;
    } else {
        self.parametersGroup.frame = _parametersGroupFrame;
        self.launchOfferWallButton.frame = _launchOfferWallButtonFrame;
    }
}

- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    [self adjustUIToInterfaceOrientation:toInterfaceOrientation];
}

- (void)viewDidUnload
{
    [self setCloseOnFinishSwitch:nil];
    [self setParametersGroup:nil];
    [self setLaunchOfferWallButton:nil];
    [super viewDidUnload];
}
@end
