//
//  SPCustomParamsUtil.h
//  SponsorPay Sample App
//
//  Created by David on 9/14/12.
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SPURLGenerator.h"


@protocol SPUrlOverriderDelegate <NSObject>

@required
- (void)overrideUrlWith:(NSString *)url;

@end

@interface SPUrlUtil : NSObject <SPURLParametersProvider>

+(SPUrlUtil *)defaultUrlUtil;

@property (nonatomic, strong) NSMutableArray *keysArray;
@property (nonatomic, strong) NSMutableDictionary *paramsDictionary;

@property (nonatomic, strong) NSString *urlOverride;
@property (nonatomic, assign) BOOL shouldOverride;

-(void)addValue:(NSString *)value forKey:(NSString *)key ;

-(void)removeObjectForKey:(NSString *)key ;

-(NSString *)objectAtIndex:(int)index ;

-(NSString *)keyAtIndex:(int)index ;

-(void)removeObjectForIndex:(NSUInteger)index;

-(NSString *)objectDescriptionForIndex:(int)index;

-(void)setDelegate:(id<SPUrlOverriderDelegate>)delegate;

@end


