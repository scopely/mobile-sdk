//
//  SPSettingsViewController.m
//  SponsorPay Sample App
//
//  Created by David on 9/14/12.
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import "SPSettingsViewController.h"

@interface SPSettingsViewController ()


@property (weak, nonatomic) SPUrlUtil *additionalParameters;

@end

@implementation SPSettingsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.additionalParameters = [SPUrlUtil defaultUrlUtil];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Do any additional setup after loading the view from its nib.
    self.overrideSwitch.on = self.additionalParameters.shouldOverride;
    self.urlOverriderTextField.text = self.additionalParameters.urlOverride;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}

#pragma mark - IBAction methods
- (IBAction)doneButtonTapped:(id)sender
{
    if ([self respondsToSelector:@selector(presentingViewController)]) {
        [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
    } else {
        [self.parentViewController dismissModalViewControllerAnimated:YES];
    }
}

-(IBAction)addButtonTapped:(id)sender
{
    if (self.keyTextField.text.length) {
        [self.additionalParameters addValue:self.valueTextField.text forKey:self.keyTextField.text];
        [self.paramsTableView reloadData];
        self.keyTextField.text = @"";
        self.valueTextField.text = @"";
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return NO;
}

- (IBAction)urlOverriderSwitchValueChanged:(UISwitch *)sender
{
    [self.additionalParameters setShouldOverride:sender.on];
}

#pragma mark - UITextFielDelegate methods

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if ([textField isEqual:self.urlOverriderTextField]) {
        [self.additionalParameters setUrlOverride:textField.text];
    }
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [self.additionalParameters.keysArray count];
}

#define CELL_IDENTIFIER @"CustomParamsCell"

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER];
    
    // Configure the cell...
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER];
    
    cell.textLabel.text = [self.additionalParameters objectDescriptionForIndex:indexPath.row];
    
    return cell;
}


- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [self.additionalParameters removeObjectForIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    self.keyTextField.text = [self.additionalParameters keyAtIndex:indexPath.row];
    self.valueTextField.text = [self.additionalParameters objectAtIndex:indexPath.row];
}

@end
