//
//  SPCustomParamsUtil.m
//  SponsorPay Sample App
//
//  Created by David on 9/14/12.
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import "SPUrlUtil.h"

static SPUrlUtil *__defaultUrlUtil;

@interface SPUrlUtil ()

@property (weak, nonatomic) id<SPUrlOverriderDelegate> delegate;

@end

@implementation SPUrlUtil

- (id)init
{
    self = [super init];
    if (self) {
        _keysArray = [[NSMutableArray alloc] init];
        _paramsDictionary = [[NSMutableDictionary alloc] init];
    }

    return self;
}

- (void)addValue:(NSString *)value forKey:(NSString *)key {
    if (![self.paramsDictionary valueForKey:key]) {
        [self.keysArray addObject:key];
    }
    [self.paramsDictionary setValue:value forKey:key];
}

- (void)removeObjectForKey:(NSString *)key {
    if ([self.paramsDictionary valueForKey:key]) {
        [self.keysArray removeObject:key];
        [self.paramsDictionary removeObjectForKey:key];
    }
}

- (void)removeObjectForIndex:(NSUInteger)index
{
    if ([self.keysArray count] >= index+1 ) {
        [self.paramsDictionary removeObjectForKey:[self.keysArray objectAtIndex:index]];
        [self.keysArray removeObjectAtIndex:index];
    }
}

- (NSString *)objectDescriptionForIndex:(int)index
{
    NSString *description = @"";
    if ([self.keysArray count] >= index + 1) {
        NSString *key = [self.keysArray objectAtIndex:index];
        NSString *value = [self.paramsDictionary objectForKey:key];
        description = [NSString stringWithFormat:@"%@ - %@", key, value];
    }
    return description;
}

- (NSString *)objectAtIndex:(int)index {
    return [self.paramsDictionary objectForKey:[self.keysArray objectAtIndex:index]];
}

- (NSString *)keyAtIndex:(int)index {
    return [self.keysArray objectAtIndex:index];
}

- (NSDictionary *)dictionaryWithKeyValueParameters
{
    return [NSDictionary dictionaryWithDictionary:self.paramsDictionary];
}

-(void)setDelegate:(id<SPUrlOverriderDelegate>)delegate
{
    _delegate = delegate;
   [self notifyDelegate];
}

-(void)setUrlOverride:(NSString *)urlOverride
{
    _urlOverride = urlOverride;
    if (self.shouldOverride) {
        [self notifyDelegate];
    }
    [self storeValues];
}

-(void)setShouldOverride:(BOOL)shouldOverride
{
    _shouldOverride = shouldOverride;
    [self notifyDelegate];
    [self storeValues];
}

-(void) notifyDelegate
{
    if (self.delegate)
    {
        [self.delegate overrideUrlWith:self.shouldOverride ? self.urlOverride : nil];
    }
}

static NSString *const SPPersistedUrlOverride = @"SPPersistedUrlOverride";
static NSString *const SPPersistedOverrideOn = @"SPPersistedOverrideOn";

- (void)storeValues
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setValue:self.urlOverride forKey:SPPersistedUrlOverride];
    [defaults setBool:self.shouldOverride forKey:SPPersistedOverrideOn];
    [defaults synchronize];
}

-(void)loadStoredValues
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    self.urlOverride = [defaults valueForKey:SPPersistedUrlOverride];
    [self setShouldOverride:[defaults boolForKey:SPPersistedOverrideOn]];
}

-(void) dealloc {
    self.urlOverride = nil;
}

#pragma mark Singleton implementation

+ (SPUrlUtil *)defaultUrlUtil
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        __defaultUrlUtil = [[SPUrlUtil alloc] init];
        [SPURLGenerator setGlobalCustomParametersProvider:__defaultUrlUtil];
        [__defaultUrlUtil loadStoredValues];
    });

    return __defaultUrlUtil;
}

@end
