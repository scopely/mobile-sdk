/**
 *  
 * @return Object literal singleton instance of SponsorPayPublisher
 */

var SponsorPayPublisher = function() {
};

/**
 * Get the SponsorPay SDK version.
 * @param callback
 *            The callback which will be called with the returning value
 */
SponsorPayPublisher.prototype.showVersion = function (callback) {
	return PhoneGap.exec(callback, 
			null,
			'SponsorPayPublisher', 
			'showVersion', 
			[]); 
}

/**
 * <p>
 * Launch the {@link OfferWallActivity}. Lets the caller specify the behavior
 * of the Offer Wall once the user gets redirected out of the application by
 * clicking on an offer.
 * </p>
 * 
 * <p>
 * Will use the provided publisher application id (if provided) instead of
 * trying to retrieve it from the application manifest.
 * </p>
 * 
 * @param userId
 *            The current user ID of the host application.
 * @param shouldStayOpen
 *            True if the Offer Wall should stay open after the user clicks on
 *            an offer and gets redirected out of the app. False to close the
 *            Offer Wall.
 * @param overridingAppId
 *            An app ID which will override the one included in the manifest.
 * @param customParams
 *            A map of extra key/value pairs to add to the request URL.
 */
SponsorPayPublisher.prototype.showOfferWall = function(userId, shouldStayOpen, 
		overridingAppId, customParams) {

	return PhoneGap.exec(null, 
			null, 
			'SponsorPayPublisher', 
			'showOfferWall', 
			[ userId, shouldStayOpen, overridingAppId, customParams ]); 
};

/**
 * Sends a request to the SponsorPay currency server to obtain the variation in amount of
 * virtual currency for a given user. Returns immediately, and the answer is delivered to one of
 * the provided listener's callback methods.
 * 
 * @param userId
 *            The ID of the user for which the delta of coins will be requested.
 * @param overridingAppId
 *            Application ID assigned by SponsorPay. Provide null to read the Application ID
 *            from the Application Manifest.
 * @param securityToken
 *            Security Token associated with the provided Application ID. It's used to sign the
 *            requests and verify the server responses.
 * @param lastTranscationID
 *            Optionally, provide the ID of the latest known transaction. The delta of coins
 *            will be calculated from this transaction (not included) up to the present. Leave
 *            it to null to let the SDK use the latest transaction ID it kept track of.
 * @param successCallback 
 * 			  The callback which will be called when the operation is successful.
 * 			  The return value is a JSONObject with the following attributes:
 * 					deltaOfCoins - the delta of coins provided by the server
 *					latestTransactionId - the latest transaction ID returned by the server
 *					usedTransaction - the transaction used to compute the coins earned
 * @param failureCallback 
 * 			  The callback which will be called when the operation generates an error.
 * 			  The return value is a JSONObject with the following attributes:
 * 					errorCode - the error code returned by the server. 
 * 					errorMessage - the error message returned by the server.
 * 					errorType - the error condition in which this request / response has resulted.
 */
SponsorPayPublisher.prototype.requestNewCoins = function(userId, overridingAppId, 
		securityToken, lastTranscationID, successCallback, failureCallback) {
	return PhoneGap.exec(successCallback, 
			failureCallback, 
			'SponsorPayPublisher', 
			'requestNewCoins', 
			[ userId, overridingAppId, securityToken, lastTranscationID ]); 
};

/**
 * <p>
 * Launch the {@link OfferWallActivity} for Unlock items. 
 * Uses the unlock item id and the unlock item name to customize and only provide offers related to
 * unlockable items.
 * </p>
 * <p>
 * Will use the provided publisher application id (if provided) instead of trying to retrieve it from the
 * application manifest.
 * </p>
 * 
 * @param userId
 *            The current user ID of the host application.
 * @param unlockItemId
 *            ID of the item for which the Unlock OfferWall will be shown, matching any 
 *            of the Item IDs you specified when setting up the items for your app.
 * @param unlockItemName
 *            Localized name of the item for which the Unlock OfferWall will be shown. 
 *            If provided, it will override the ItemName that is set on our server.
 * @param overridingAppId
 *            An app ID which will override the one included in the manifest.
 * @param customParams
 *            A map of extra key/value pairs to add to the request URL.
 */
SponsorPayPublisher.prototype.showUnlockOfferWall = function(userId, unlockItemId, 
		unlockItemName, overridingAppId, customParams, failureCallback) {
	
	return PhoneGap.exec(null, 
			failureCallback, 
			'SponsorPayPublisher', 
			'showUnlockOfferWall', 
			[ userId, unlockItemId, unlockItemName, overridingAppId, customParams ]); 
};

/**
 * Sends a request to the SponsorPay currency server to obtain the variation in
 * amount of virtual currency for a given user. Returns immediately, and the
 * answer is delivered to one of the provided listener's callback methods.
 * 
 * @param userId
 *            The ID of the user for which the delta of coins will be requested.
 * @param securityToken
 *            Security Token associated with the provided Application ID. It's used to sign the
 *            requests and verify the server responses.
 * @param overridingAppId
 *            Application ID assigned by SponsorPay. Provide null to read the Application ID
 *            from the Application Manifest.
 * @param customParams
 *            A map of extra key/value pairs to add to the request URL.
 * @param successCallback 
 * 			  The callback which will be called when the operation is successful.
 * 			  The return value is a JSONArray with the following JSONObject and attributes:
 * 					itemID - the Unlock Item ID
 * 					itemName - the Unlock Item name
 * 					unlocked - whether the item has been unlocked
 * 					timestamp - the timestamp of the unlock if the item has been unlocked
 * @param failureCallback 
 * 			  The callback which will be called when the operation generates an error.
 * 			  The return value is a JSONObject with the following attributes:
 * 					errorCode - the error code returned by the server. 
 * 					errorMessage - the error message returned by the server.
 * 					errorType - the error condition in which this request / response has resulted.
 */
SponsorPayPublisher.prototype.unlockItems = function(userId, securityToken, 
		overridingAppId, customParams, successCallback, failureCallback) {
	
	return PhoneGap.exec(successCallback,
			failureCallback,
			'SponsorPayPublisher', 
			'unlockItems', 
			[ userId, securityToken, overridingAppId, customParams ]); 
};

PhoneGap.addConstructor(function() {
	PhoneGap.addPlugin("SponsorPayPublisher", new SponsorPayPublisher());
});
