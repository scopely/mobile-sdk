package com.sponsorpay.sdk.android.phonegap.advertiser;

import org.apache.cordova.api.CordovaInterface;
import org.apache.cordova.api.PluginResult;
import org.apache.cordova.api.PluginResult.Status;
import org.json.JSONArray;
import org.json.JSONException;

import android.util.Log;

import com.sponsorpay.sdk.android.SponsorPay;
import com.sponsorpay.sdk.android.advertiser.SponsorPayAdvertiser;
import com.sponsorpay.sdk.android.phonegap.AbstractSPPlugin;

/**
 * The Class SponsorPayAdvertiserPlugin.
 * 
 * Features related to the advertiser side of the SponsorPay Mobile SDK.
 */
public class SponsorPayAdvertiserPlugin extends AbstractSPPlugin {
	
	/** The Constant SEND_ADVERTISER_CALLBACK_ACTION. */
	private static final String SEND_ADVERTISER_CALLBACK_ACTION = "sendAdvertiserCallback";
	
	/** The Constant SEND_ADVERTISER_CALLBACK_WITH_DELAY_ACTION. */
	private static final String SEND_ADVERTISER_CALLBACK_WITH_DELAY_ACTION = "sendAdvertiserCallbackWithDelay";
	
	/** The Constant VERSION_ACTION. */
	private static final String VERSION_ACTION = "showVersion";

	/* (non-Javadoc)
	 * @see org.apache.cordova.api.Plugin#setContext(org.apache.cordova.api.CordovaInterface)
	 */
	@Override
	public void setContext(CordovaInterface ctx) {
		super.setContext(ctx);
		try {
//			Workaround for the invalid handler exception on asynctask
//			http://code.google.com/p/android/issues/detail?id=20915
			Class.forName("android.os.AsyncTask");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	
	/* (non-Javadoc)
	 * @see org.apache.cordova.api.Plugin#execute(java.lang.String, org.json.JSONArray, java.lang.String)
	 */
	@Override
	public PluginResult execute(String action, JSONArray data, String callbackId) {
		Log.d("SponsorPayAdvertiserPlugin", "Plugin Called");

		PluginResult result = null;
		if (action != null && !action.trim().equals("")) {

			if (action.equals(SEND_ADVERTISER_CALLBACK_ACTION)) {
				result = sendAdvertiserCallback(data);
			} else if (action.equals(SEND_ADVERTISER_CALLBACK_WITH_DELAY_ACTION)) {
				result = sendAdvertiserCallbackWithDelay(data);
			} else if (action.equals(VERSION_ACTION)) {
				result = showVersion();
			}
		}
		
		if (result == null) {
			result = new PluginResult(Status.INVALID_ACTION);
			Log.d("SponsorPayAdvertiserPlugin", "Invalid action : " + action
					+ " passed");
		}

		return result;
	}

	/**
	 * Get the SponsorPay SDK version and returns it on the plugin result object.
	 *
	 * @return the SponsorPay SDK version
	 */
	private PluginResult showVersion() {
		return new PluginResult(Status.OK, SponsorPay.RELEASE_VERSION_STRING);
	}

	/**
	 * Send advertiser callback.
	 *
	 * @param data the JSONArray arguments passed to the method from the SDK
	 * 		 Index  0 - Overriding App ID - String
	 * 				1 - Additional custom parameters - Map<String, String>
	 * @return the result of the operation 
	 */
	private PluginResult sendAdvertiserCallback(JSONArray data) {
		PluginResult result = null;
		try {
			SponsorPayAdvertiser.register(ctx.getActivity()
					.getApplicationContext(), getNullFromJSONArray(data, 0),
					decodeJSONMap(data, 1));
			result = new PluginResult(Status.OK);
		} catch (JSONException jsonEx) {
			result = error(jsonEx);
		}
		return result;
	}

	/**
	 * Send advertiser callback with delay.
	 *
	 * @param data the JSONArray arguments passed to the method from the SDK
	 * 		 Index  0 - Overriding App ID - String
	 * 				1 - Delay to wait (in minutes) - Integer
	 * 				2 - Additional custom parameters - Map<String, String>
	 * @return the result of the operation 
	 */
	private PluginResult sendAdvertiserCallbackWithDelay(JSONArray data) {
		PluginResult result = null;
		try {
			SponsorPayAdvertiser.registerWithDelay(ctx.getActivity()
					.getApplicationContext(), data.getInt(0),
					getNullFromJSONArray(data, 1), decodeJSONMap(data, 2));
			result = new PluginResult(Status.OK);
		} catch (JSONException jsonEx) {
			result = error(jsonEx);
		}
		return result;
	}

}
