package com.sponsorpay.sdk.android.phonegap.publisher;

import org.apache.cordova.api.CordovaInterface;
import org.apache.cordova.api.PluginResult;
import org.apache.cordova.api.PluginResult.Status;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.sponsorpay.sdk.android.SponsorPay;
import com.sponsorpay.sdk.android.phonegap.AbstractSPPlugin;
import com.sponsorpay.sdk.android.publisher.AbstractResponse;
import com.sponsorpay.sdk.android.publisher.SponsorPayPublisher;
import com.sponsorpay.sdk.android.publisher.currency.CurrencyServerAbstractResponse;
import com.sponsorpay.sdk.android.publisher.currency.CurrencyServerDeltaOfCoinsResponse;
import com.sponsorpay.sdk.android.publisher.currency.SPCurrencyServerListener;
import com.sponsorpay.sdk.android.publisher.currency.VirtualCurrencyConnector;
import com.sponsorpay.sdk.android.publisher.unlock.SPUnlockResponseListener;
import com.sponsorpay.sdk.android.publisher.unlock.UnlockedItemsResponse;
import com.sponsorpay.sdk.android.publisher.unlock.UnlockedItemsResponse.Item;

/**
 * The Class SponsorPayPublisherPlugin.
 * 
 * Features related to the publisher side of the SponsorPay Mobile SDK.
 */
public class SponsorPayPublisherPlugin extends AbstractSPPlugin {
	
	/** The Constant SHOW_OFFERWALL_ACTION. */
	private static final String SHOW_OFFERWALL_ACTION = "showOfferWall";
	
	/** The Constant REQUEST_NEW_COINS_ACTION. */
	private static final String REQUEST_NEW_COINS_ACTION = "requestNewCoins";
	
	/** The Constant SHOW_UNLOCK_OFFERWALL_ACTION. */
	private static final String SHOW_UNLOCK_OFFERWALL_ACTION = "showUnlockOfferWall";
	
	/** The Constant UNLOCK_ITEMS_ACTION. */
	private static final String UNLOCK_ITEMS_ACTION = "unlockItems";
	
	/** The Constant VERSION_ACTION. */
	private static final String VERSION_ACTION = "showVersion";

	/* (non-Javadoc)
	 * @see org.apache.cordova.api.Plugin#setContext(org.apache.cordova.api.CordovaInterface)
	 */
	@Override
	public void setContext(CordovaInterface ctx) {
		super.setContext(ctx);
		try {
//			Workaround for the invalid handler exception on asynctask
//			http://code.google.com/p/android/issues/detail?id=20915
			Class.forName("android.os.AsyncTask");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	/* (non-Javadoc)
	 * @see org.apache.cordova.api.Plugin#execute(java.lang.String, org.json.JSONArray, java.lang.String)
	 */
	@Override
	public PluginResult execute(String action, JSONArray data, String callbackId) {
		Log.d("SponsorPayPublisherPlugin", "Plugin Called");

		PluginResult result = null;
		if (action != null && !action.trim().equals("")) {

			if (action.equals(SHOW_OFFERWALL_ACTION)) {
				result = showOfferWall(data);
			} else if (action.equals(REQUEST_NEW_COINS_ACTION)){
				result = requestNewCoins(data, callbackId);
			} else if (action.equals(SHOW_UNLOCK_OFFERWALL_ACTION)) {
				result = showUnlockOfferWall(data);
			} else if (action.equals(UNLOCK_ITEMS_ACTION)) {
				result = unlockItems(data, callbackId);
			} else if (action.equals(VERSION_ACTION)) {
				result = showVersion();
			}
		}
		
		if (result == null) {
			result = new PluginResult(Status.INVALID_ACTION);
			Log.d("SponsorPayPublisherPlugin", "Invalid action : " + action
					+ " passed");
		}

		return result;
	}

	/**
	 * Get the SponsorPay SDK version and returns it on the plugin result object.
	 *
	 * @return the SponsorPay SDK version
	 */
	private PluginResult showVersion() {
		return new PluginResult(Status.OK, SponsorPay.RELEASE_VERSION_STRING);
	}

	/**
	 * Launch the OfferWall activity.
	 *
	 * @param data the JSONArray arguments passed to the method from the SDK
	 * 		 Index  0 - User ID - String
	 * 				1 - Should stay open - boolean
	 * 				2 - Overriding App ID - String
	 * 				3 - Additional custom parameters - Map<String, String>
	 * @return the result of the operation 
	 */
	private PluginResult showOfferWall(JSONArray data) {
		try {
			Intent offerWallActivity = SponsorPayPublisher
					.getIntentForOfferWallActivity(ctx.getActivity().getApplicationContext(),
							getNullFromJSONArray(data, 0), data.getBoolean(1),
							getNullFromJSONArray(data, 2),
							decodeJSONMap(data, 3));
			ctx.getActivity().startActivity(offerWallActivity);
			return new PluginResult(Status.OK);
		} catch (JSONException jsonEx) {
			return error(jsonEx);
		}
	}
	
	/**
	 * Launch the Unlock Items OfferWall activity.
	 *
	 * @param data the JSONArray arguments passed to the method from the SDK
	 * 		 Index  0 - User ID - String
	 * 				1 - Unlock item ID - String
	 * 				2 - Unlock Item Name - String
	 * 				3 - Overriding App ID - String
	 * 				4 - Additional custom parameters - Map<String, String>
	 * @return the result of the operation 
	 */
	private PluginResult showUnlockOfferWall(JSONArray data) {
		try {
			Intent unlockOfferWallActivity = SponsorPayPublisher
					.getIntentForUnlockOfferWallActivity(
							ctx.getActivity().getApplicationContext(),
							getNullFromJSONArray(data, 0),
							getNullFromJSONArray(data, 1),
							getNullFromJSONArray(data, 2),
							getNullFromJSONArray(data, 3), 
							decodeJSONMap(data, 4));
			ctx.getActivity().startActivity(unlockOfferWallActivity);
			return new PluginResult(Status.OK);
		} catch (JSONException e) {
			return error(e);
		} catch (RuntimeException e) {
			return new PluginResult(Status.ERROR, e.getMessage());
		}
	}
	
	/**
	 * Request new coins.
	 *
	 * @param data the JSONArray arguments passed to the method from the SDK
	 * 		 Index  0 - User ID - String
	 * 				1 - Overriding App ID - String
	 * 				2 - Security token - String
	 * 				3 - Last transaction ID - String
	 * @param callbackId the callback id
	 * @return the result of the operation, either error message or coins earned 
	 */
	private PluginResult requestNewCoins(JSONArray data, final String callbackId) {
		PluginResult pluginResult = null;
		try {
			String userId = getNullFromJSONArray(data, 0);

			String overridingAppId = getNullFromJSONArray(data, 1);
			String securityToken = getNullFromJSONArray(data, 2);
			
			String lastTransactionID = getNullFromJSONArray(data, 3);

			Context appContext = ctx.getActivity().getApplicationContext();

			final String usedTransactionId = VirtualCurrencyConnector
					.fetchLatestTransactionId(appContext , overridingAppId,
							userId);
		    
			SPCurrencyServerListener requestListener = new SPCurrencyServerListener() {
				public void onSPCurrencyServerError(
						CurrencyServerAbstractResponse response) {
					try {
						JSONObject jsonResponse = new JSONObject();
						jsonResponse.put("errorCode", response.getErrorCode());
						jsonResponse.put("errorMessage", response.getErrorMessage());
						jsonResponse.put("errorType", response.getErrorType());
						PluginResult result = new PluginResult(Status.ERROR, jsonResponse); 
						result.setKeepCallback(false); 
						error(result, callbackId);
					} catch (JSONException e) {
						e.printStackTrace();
					}
				}

				public void onSPCurrencyDeltaReceived(
						CurrencyServerDeltaOfCoinsResponse response) {
					try {
						JSONObject jsonResponse = new JSONObject();
						jsonResponse.put("deltaOfCoins", response.getDeltaOfCoins());
						jsonResponse.put("latestTransactionId", response.getLatestTransactionId());
						jsonResponse.put("usedTransaction", usedTransactionId);
						PluginResult result = new PluginResult(Status.OK, jsonResponse); 
						result.setKeepCallback(false); 
						success(result, callbackId); 
					} catch (JSONException e) {
						e.printStackTrace();
					}
				}
			};

			
			try {
				SponsorPayPublisher.requestNewCoins(appContext, userId,
						requestListener, lastTransactionID, securityToken,
						overridingAppId);
				pluginResult = new PluginResult(Status.NO_RESULT);
				pluginResult.setKeepCallback(true);
			} catch (RuntimeException ex) {
				Log.e(this.getClass().toString(), "SponsorPay SDK Exception: ",
						ex);
				pluginResult = new PluginResult(Status.ERROR, ex.getMessage());
			}

		} catch (JSONException e) {
			pluginResult = error(e);
		}
		return pluginResult;
	}
	

	/**
	 * Unlock items.
	 *
	 * @param data the JSONArray arguments passed to the method from the SDK
	 * 		 Index  0 - User ID - String
	 * 				1 - Security token - String
	 * 				2 - Overriding App ID - String
	 * 				3 - Additional custom parameters - Map<String, String>
	 * @param callbackId the callback id
	 * @return the result of the operation, either error message or coins earned 
	 */
	private PluginResult unlockItems(JSONArray data, final String callbackId) {
		PluginResult pluginResult = null;
		try {
			SPUnlockResponseListener listener = new SPUnlockResponseListener() {

				public void onSPUnlockRequestError(AbstractResponse response) {
					try {
						JSONObject jsonResponse = new JSONObject();
						jsonResponse.put("errorCode", response.getErrorCode());
						jsonResponse.put("errorMessage", response.getErrorMessage());
						jsonResponse.put("errorType", response.getErrorType());
						PluginResult result = new PluginResult(Status.ERROR, jsonResponse); 
						result.setKeepCallback(false); 
						error(result, callbackId);
					} catch (JSONException e) {
						e.printStackTrace();
					}
				}

				public void onSPUnlockItemsStatusResponseReceived(
						UnlockedItemsResponse response) {
					JSONArray jsonResponse = new JSONArray();
					for (Item item : response.getItems().values()) {
						JSONObject jsonObject = new JSONObject();
						try {
							jsonObject.put("itemID", item.getId());
							jsonObject.put("itemName", item.getName());
							jsonObject.put("timestamp", item.getTimestamp());
							jsonObject.put("unlocked", item.isUnlocked());
							jsonResponse.put(jsonObject);
						} catch (JSONException e) {
							e.printStackTrace();
						}
					}
					PluginResult result = new PluginResult(Status.OK,
							jsonResponse);
					result.setKeepCallback(false);
					success(result, callbackId);
				}

			};
			SponsorPayPublisher.requestUnlockItemsStatus(ctx.getActivity().getApplicationContext(), 
					getNullFromJSONArray(data, 0),
					listener,
					getNullFromJSONArray(data, 1), 
					getNullFromJSONArray(data, 2), 
					decodeJSONMap(data, 3));
			pluginResult = new PluginResult(Status.NO_RESULT);
			pluginResult.setKeepCallback(true);
		} catch (JSONException jsonEx) {
			pluginResult = error(jsonEx);
		}
		return pluginResult;
	}
	
}
