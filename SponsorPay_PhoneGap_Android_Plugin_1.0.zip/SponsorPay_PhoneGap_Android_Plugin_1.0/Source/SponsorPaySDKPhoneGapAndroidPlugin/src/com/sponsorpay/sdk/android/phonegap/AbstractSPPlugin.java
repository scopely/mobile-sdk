package com.sponsorpay.sdk.android.phonegap;

import java.util.HashMap;
import java.util.Iterator;

import org.apache.cordova.api.Plugin;
import org.apache.cordova.api.PluginResult;
import org.apache.cordova.api.PluginResult.Status;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

public abstract class AbstractSPPlugin extends Plugin {

	protected String getNullFromJSONArray(JSONArray data, int index)
			throws JSONException {
		Object ret = data.get(index);
		return ret != JSONObject.NULL ? ret.toString() : null;
	}

	protected PluginResult error(JSONException jsonEx) {
		Log.d("SponsorPayPublisherPlugin",
				"Got JSON Exception " + jsonEx.getMessage());
		return new PluginResult(Status.JSON_EXCEPTION, jsonEx.getMessage());
	}
	
	protected HashMap<String, String> decodeJSONMap(JSONArray data, int index){
		try {
			JSONObject jsonObject = data.getJSONObject(index);
			if (jsonObject != JSONObject.NULL) {
				HashMap<String, String> map = new HashMap<String, String>();

				Iterator<?> keys = jsonObject.keys();
				while (keys.hasNext()) {
					String key = keys.next().toString();
					map.put(key, jsonObject.get(key).toString());
				}
				return map.isEmpty() ? null : map;
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return null;
	}
	
}
