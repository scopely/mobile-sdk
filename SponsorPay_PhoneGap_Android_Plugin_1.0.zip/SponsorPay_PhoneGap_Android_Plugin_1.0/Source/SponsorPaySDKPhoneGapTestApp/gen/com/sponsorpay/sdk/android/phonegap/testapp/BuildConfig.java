/** Automatically generated file. DO NOT MODIFY */
package com.sponsorpay.sdk.android.phonegap.testapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}