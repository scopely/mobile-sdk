package com.sponsorpay.sdk.android.phonegap.testapp;

import org.apache.cordova.DroidGap;

import android.os.Bundle;

public class SponsorPayPhoneGapTestApp extends DroidGap {

	@Override
	public void onCreate(Bundle savedInstance) {
		super.onCreate(savedInstance);
		super.loadUrl("file:///android_asset/www/index.html");
	}

}
