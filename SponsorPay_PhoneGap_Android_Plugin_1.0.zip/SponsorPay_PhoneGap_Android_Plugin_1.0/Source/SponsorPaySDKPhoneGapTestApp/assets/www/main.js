function init() {
	document.addEventListener("deviceready", deviceInfo, true);
	document.addEventListener("deviceready", onDeviceReady, false);
}

// Cordova is loaded and it is now safe to make calls Cordova methods
//
function onDeviceReady() {
	document.addEventListener("pause", onPause, false);
	appId.value = window.localStorage.getItem("appId");
	userId.value = window.localStorage.getItem("userId");
	securityToken.value = window.localStorage.getItem("securityToken");
	unlockItemID.value = window.localStorage.getItem("unlockItemId");
	unlockItemName.value = window.localStorage.getItem("unlockItemName");
	advertiserDelay.value = window.localStorage.getItem("advertiserDelay");
}

// Handle the pause event
//
function onPause() {
	window.localStorage.setItem("appId", appId.value);
	window.localStorage.setItem("userId", userId.value);
	window.localStorage.setItem("securityToken", securityToken.value);
	window.localStorage.setItem("unlockItemId", unlockItemId.value);
	window.localStorage.setItem("unlockItemName", unlockItemName.value);
	window.localStorage.setItem("advertiserDelay", advertiserDelay.value);
}

var deviceInfo = function() {

	spp.showVersion(function(a) {
		document.getElementById("sdkVersion").innerHTML = a;
	})
	document.getElementById("platform").innerHTML = device.platform;
	document.getElementById("version").innerHTML = device.version;
	document.getElementById("uuid").innerHTML = device.uuid;
	document.getElementById("name").innerHTML = device.name;
	document.getElementById("width").innerHTML = screen.width;
	document.getElementById("height").innerHTML = screen.height;
	document.getElementById("colorDepth").innerHTML = screen.colorDepth;
};

var spp = new SponsorPayPublisher()

function showOfferWall() {
	spp.showOfferWall(userId.value, true, appId.value, null);
	return false;
}

function requestNewCoins() {
	spp.requestNewCoins(userId.value, appId.value, securityToken.value, null,
			function(a) {
				displayDeltaOfCoins(a)
			}, function(e) {
				displayError(e)
			});
	return false;
}

function displayDeltaOfCoins(deltaOfCoinsResponse) {
	alert('Delta of coins: ' + deltaOfCoinsResponse.deltaOfCoins
			+ '\nLast transaction id: '
			+ deltaOfCoinsResponse.latestTransactionId + '\nTransaction used: '
			+ deltaOfCoinsResponse.usedTransaction)
}

function displayError(errorResponse) {
	console.log(errorResponse);
	alert('Error code: ' + errorResponse.errorCode + '\nError message: '
			+ errorResponse.errorMessage + '\nError type: '
			+ errorResponse.errorType);
}

function showUnlockOfferWall() {
	spp.showUnlockOfferWall(userId.value, unlockItemId.value,
			unlockItemName.value, appId.value, null, function(e) {
			alert(e);
			});
	return false;
}

function unlockItems() {
	spp.unlockItems(userId.value, securityToken.value, appId.value, null,
			function(a) { displayUnlockItemResponse(a)}, function(e) {
				displayError(e)
			});
	return false;
}

function displayUnlockItemResponse(items) {
	var msg = ""
	for ( var i = 0; i < items.length; i++) {
		var item = items[i];
		for ( var key in item) {
			var attrName = key;
			var attrValue = item[key];
			var bla = "\n" + attrName + " : " + attrValue;
			msg = msg.concat(bla);
		}
		msg = msg.concat("\n=================")
	}
	alert(msg);
}

var spa = new SponsorPayAdvertiser();

function sendAdvertiserCallback() {
	spa.sendAdvertiserCallback(appId.value);
	return false;
}

function sendAdvertiserCallbackWithDelay(){
	spa.sendAdvertiserCallbackWithDelay(advertiserDelay.value, appId.value);
	return false;
}

