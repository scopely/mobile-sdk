//
//  SPSampleViewController.h
//  SponsorPay iOS Test App
//
//  Copyright 2011 SponsorPay. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SponsorPaySDK.h"

#import "SPCustomParamsUtil.h"

#define DEFAULT_SECURITY_TOKEN  @"888"

#define ENTERED_APPID_KEY                           @"ENTERED_APPID_KEY"
#define ENTERED_USERID_KEY                          @"ENTERED_USERID_KEY"
#define ENTERED_BACKGROUND_URL_KEY                  @"ENTERED_BACKGROUND_URL_KEY"
#define ENTERED_SKIN_NAME_KEY                       @"ENTERED_SKIN_NAME_KEY"
#define ENTERED_CLOSE_AFTER_CLICKING_ON_OFFER_KEY   @"ENTERED_CLOSE_AFTER_CLICKING_ON_OFFER_KEY"
#define ENTERED_SECURITY_TOKEN_KEY                  @"ENTERED_SECURITY_TOKEN_KEY"
#define ENTERED_ACTION_ID                           @"ENTERED_ACTION_ID"


@interface SPSampleViewController : UIViewController <UITextFieldDelegate, SPOfferWallViewControllerDelegate, SPInterstitialViewControllerDelegate,SPVirtualCurrencyConnectionDelegate>


@property (retain) IBOutlet UIScrollView *scrollView;
@property (retain) IBOutlet UIView *contentView;
@property (retain) IBOutlet UITextField *appIdTextField;
@property (retain) IBOutlet UITextField *userIdTextField;
@property (retain) IBOutlet UITextField *backgroundUrlTextField;
@property (retain) IBOutlet UITextField *skinNameTextField;
@property (retain) IBOutlet UITextField *securityTokenTextField;
@property (retain) IBOutlet UISwitch *closeAfterClickingOffer;
@property (retain) IBOutlet UIButton *sendVCSDeltaRequestButton;
@property (retain) IBOutlet UIButton *settingsButton;
@property (retain, nonatomic) IBOutlet UIButton *startSDKButton;
@property (retain, nonatomic) IBOutlet UITextField *actionIdTextField;

- (IBAction)launchOfferWall:(id)sender;
- (IBAction)launchInterstitial:(id)sender;
- (IBAction)registerSDKCredentials:(id)sender;
- (IBAction)textFieldReturn:(id)sender;
- (IBAction)sendVCSDeltaRequest:(id)sender;
- (IBAction)goToSettings:(id)sender;
- (IBAction)reportActionCompleted:(id)sender;
- (IBAction)textFieldEditingDidBegin:(UITextField *)sender;

@end
