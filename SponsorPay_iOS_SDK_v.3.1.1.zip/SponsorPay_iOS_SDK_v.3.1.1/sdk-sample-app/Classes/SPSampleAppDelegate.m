//
//  SPPublishAppDelegate.m
//  SponsorPay iOS Test App
//
//  Copyright 2011 SponsorPay. All rights reserved.
//

#import "SPSampleAppDelegate.h"
#import "SPAdvertiserManager.h"
#import "SPLogger.h"

@implementation SPSampleAppDelegate

#pragma mark - Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window.rootViewController = self.viewController;
    [self.window makeKeyAndVisible];
    
    [SPLogger defaultLogger].shouldOutputToSystemLog = YES;

    return YES;
}

#pragma mark - Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application
{

}

- (void)dealloc
{
    self.viewController = nil;
    self.window = nil;
    [super dealloc];
}

@end
