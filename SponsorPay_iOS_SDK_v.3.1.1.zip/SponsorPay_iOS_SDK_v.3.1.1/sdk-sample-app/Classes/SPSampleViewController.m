//
//  SPSampleViewController.m
//  SponsorPay iOS Test App
//
//  Copyright 2011 SponsorPay. All rights reserved.
//

#import "SPSampleViewController.h"
#import "SPSettingsViewController.h"
#import "SPAdvertiserManager.h"
#import "SPLogger.h"

@interface SPSampleViewController()

@property (readonly, nonatomic) NSString *userEnteredAppId;
@property (readonly, nonatomic) NSString *userEnteredUserId;
@property (readonly, nonatomic) NSString *userEnteredSecurityToken;
@property (readonly, nonatomic) NSString *userEnteredActionId;
@property (readonly, nonatomic) SPCustomParamsUtil *additionalParameters;
@property (retain, nonatomic) NSString *lastCredentialsToken;

@property (retain) NSString *latestUsedVCSTransactionId;


@property (retain) SPOfferWallViewController *offerWallViewController;
@property (retain) SPInterstitialViewController *interstitialViewController;
@property (retain) SPVirtualCurrencyServerConnector *virtualCurrencyConnector;

@property (retain) UITextField *activeField;

@end

@implementation SPSampleViewController {
    SPCustomParamsUtil *_additionalParameters;
}

#pragma mark properties

- (NSString *)userEnteredAppId {
    return self.appIdTextField.text;
}

- (NSString *)userEnteredUserId {
    return self.userIdTextField.text;
}

- (NSString *)userEnteredSecurityToken {
    return self.securityTokenTextField.text;
}

- (NSString *)userEnteredActionId {
    return self.actionIdTextField.text;
}

- (SPCustomParamsUtil *)additionalParameters {
    if(!_additionalParameters) {
        _additionalParameters = [[SPCustomParamsUtil alloc] init];
        [SPURLGenerator setGlobalCustomParametersProvider:_additionalParameters];
    }
    return _additionalParameters;
}

#pragma mark - Start SDK

- (IBAction)registerSDKCredentials:(id)sender {
    @try {
        self.lastCredentialsToken = [SponsorPaySDK startForAppId:self.userEnteredAppId
                                                          userId:self.userEnteredUserId
                                                   securityToken:self.userEnteredSecurityToken];
    }
    @catch (NSException *exception) {
        [self showSDKException:exception];
    }
}

#pragma mark - OfferWall

- (IBAction)launchOfferWall:(id)sender {
    if (self.offerWallViewController) {
        [self.offerWallViewController dismissAnimated:NO];
        self.offerWallViewController = nil;
    }
    
    @try {
        self.offerWallViewController = [SponsorPaySDK offerWallViewControllerForCredentials:self.lastCredentialsToken];
    } @catch (NSException *exception) {
        [self showSDKException:exception];
    }
    
    self.offerWallViewController.delegate = self;
    self.offerWallViewController.shouldFinishOnRedirect = self.closeAfterClickingOffer.on;
    [self.offerWallViewController showOfferWallWithParentViewController:self];
}

- (void)offerWallViewController:(SPOfferWallViewController *)offerwallVC
           isFinishedWithStatus:(int)status {
	[SPLogger log:@"SPSampleViewController did receive SPOfferWallViewController callback with status: %@", status];
    
    // offerWallVC will remove itself from the parent VC
    
    self.offerWallViewController = nil;
}

#pragma mark - Interstitial

- (IBAction)launchInterstitial:(id)sender {
    if (nil != self.interstitialViewController) {
        [self.interstitialViewController cancelInterstitialRequest];
        [self.interstitialViewController dismissAnimated:NO];
        self.interstitialViewController = nil;
    }

    @try {
        self.interstitialViewController =
        [SponsorPaySDK interstitialViewControllerForCredentials:self.lastCredentialsToken];
    } @catch (NSException *exception) {
        [self showSDKException:exception];
    }
    
    self.interstitialViewController.backgroundImageUrl = self.backgroundUrlTextField.text;
    self.interstitialViewController.skin = self.skinNameTextField.text;
    self.interstitialViewController.delegate = self;
    self.interstitialViewController.shouldFinishOnRedirect = self.closeAfterClickingOffer.on;

    [self.interstitialViewController startLoadingWithParentViewController:self];
}

- (void)interstitialViewController:(SPInterstitialViewController *)theInterstitialViewController
                   didChangeStatus:(SPInterstitialViewControllerStatus)status {
    
    NSString *statusAsString;
    BOOL isInterstitialDone = NO;
    
    switch (status) {
        case AD_SHOWN:
            statusAsString = @"AD_SHOWN";
            break;
        case NO_INTERSTITIAL_AVAILABLE:
            statusAsString = @"NO_INTERSTITIAL_AVAILABLE";
            isInterstitialDone = YES;
            break;
        case ERROR_NETWORK:
            statusAsString = @"ERROR_NETWORK";
            isInterstitialDone = YES;
            break;
        case ERROR_TIMEOUT:
            statusAsString = @"ERROR_TIMEOUT";
            isInterstitialDone = YES;
            break;
        case CLOSED:
            statusAsString = @"CLOSED";
            isInterstitialDone = YES;
            break;
    }
    
    if (isInterstitialDone) {
        // just release interstitial, its VC has been removed if necessary from the parent VC
        self.interstitialViewController = nil;
    }
    
    [SPLogger log:@"SPSampleViewController did receive InterstitialViewController callback with status %@", statusAsString];
}

#pragma mark - Virtual Currency Server

- (IBAction)sendVCSDeltaRequest:(id)sender
{
    @try {
        self.virtualCurrencyConnector = [SponsorPaySDK VCSConnectorForCredentials:self.lastCredentialsToken];
    } @catch (NSException *exception) {
        [self showSDKException:exception];
    }
    
    self.virtualCurrencyConnector.secretToken = self.userEnteredSecurityToken;
    self.virtualCurrencyConnector.delegate = self;
    self.latestUsedVCSTransactionId = self.virtualCurrencyConnector.latestTransactionId;
    
    [self.virtualCurrencyConnector fetchDeltaOfCoins];
    
    [self showActivityIndication];
}

- (void)virtualCurrencyConnector:(SPVirtualCurrencyServerConnector *)vcConnector
  didReceiveDeltaOfCoinsResponse:(double)deltaOfCoins
             latestTransactionId:(NSString *)transactionId
{
    [self stopActivityIndication];
    
    NSString *formattedMessage = [NSString stringWithFormat:
                                  @"Sent Latest Transaction ID:%@ Delta of Coins:%f\nReturned Latest Transaction ID:%@",
                                  self.latestUsedVCSTransactionId, deltaOfCoins, transactionId];
    
    UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"VCS Response Received"
                                                     message:formattedMessage
                                                    delegate:self cancelButtonTitle:@"OK"
                                           otherButtonTitles:nil] autorelease];
    [alert show];
}

- (void)virtualCurrencyConnector:(SPVirtualCurrencyServerConnector *)vcConnector
                 failedWithError:(SPVirtualCurrencyRequestErrorType)error
                       errorCode:(NSString *)errorCode
                    errorMessage:(NSString *)errorMessage
{
    [self stopActivityIndication];
    
    NSString *errorType;
    
    switch (error) {
        case NO_ERROR:
            errorType = @"NO_ERROR";
            break;
        case ERROR_NO_INTERNET_CONNECTION:
            errorType = @"ERROR_NO_INTERNET_CONNECTION";
            break;
        case ERROR_INVALID_RESPONSE:
            errorType = @"ERROR_INVALID_RESPONSE";
            break;
        case ERROR_INVALID_RESPONSE_SIGNATURE:
            errorType = @"ERROR_INVALID_RESPONSE_SIGNATURE";
            break;
        case SERVER_RETURNED_ERROR:
            errorType = @"SERVER_RETURNED_ERROR";
            break;
        case ERROR_OTHER:
            errorType = @"ERROR_OTHER";
            break;
        default:
            errorType = [NSString stringWithFormat:@"%d", error];
            break;
    }
    
    NSString *formattedError = [NSString stringWithFormat:@"%@\n%@\n%@", errorType, errorCode, errorMessage];
    
    UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"Error in VCS Request / Response"
                                                     message:formattedError
                                                    delegate:self cancelButtonTitle:@"OK"
                                           otherButtonTitles:nil] autorelease];
    [alert show];
}

#pragma mark - CPE Actions

- (IBAction)reportActionCompleted:(id)sender {
    @try {
        [SponsorPaySDK reportActionCompleted:self.userEnteredActionId
                              forCredentials:self.lastCredentialsToken];
    } @catch (NSException *exception) {
        [self showSDKException:exception];
    }
}

#pragma mark - UIViewController lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.scrollView addSubview:self.contentView];
    self.scrollView.contentSize = self.contentView.bounds.size;
    
    [self.view addSubview:self.scrollView];
}

- (void)viewDidAppear:(BOOL)animated
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    self.appIdTextField.text = [defaults stringForKey:ENTERED_APPID_KEY];
    self.userIdTextField.text = [defaults stringForKey:ENTERED_USERID_KEY];
    self.backgroundUrlTextField.text = [defaults stringForKey:ENTERED_BACKGROUND_URL_KEY];
    self.skinNameTextField.text = [defaults stringForKey:ENTERED_SKIN_NAME_KEY];
    self.closeAfterClickingOffer.on = [defaults boolForKey:ENTERED_CLOSE_AFTER_CLICKING_ON_OFFER_KEY];
    
    NSString *retrievedSecurityToken = [defaults stringForKey:ENTERED_SECURITY_TOKEN_KEY];
    
    self.securityTokenTextField.text =
    retrievedSecurityToken ? retrievedSecurityToken : DEFAULT_SECURITY_TOKEN;
    
    NSString *retrievedActionId = [defaults stringForKey:ENTERED_ACTION_ID];
    self.actionIdTextField.text = retrievedActionId;
    
    [[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(appWillResignActiveNotification:)
												 name:UIApplicationWillResignActiveNotification
											   object:nil];
    
    
    [self subscribeToKeyboardNotifications];
    
    [super viewDidAppear:animated];
}

-(void)viewWillDisappear:(BOOL)animated
{
    [self persistUseEnteredValues];
    [self unsubscribeFromKeyboardNotifications];
    [super viewWillDisappear:animated];
}

#pragma mark - Rotation management

#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 60000

- (NSUInteger)supportedInterfaceOrientations
{
    //    return [self currentStatusBarOrientation];
    return UIInterfaceOrientationMaskAll;
}

- (BOOL)shouldAutorotate
{
    return YES;
}

#else

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}

#endif

#pragma mark - Settings

- (IBAction)goToSettings:(id)sender
{
    SPSettingsViewController *settingsViewController = [[SPSettingsViewController alloc] init];
    settingsViewController.additionalParameters = self.additionalParameters;
    
    if ([self respondsToSelector:@selector(presentViewController:animated:completion:)]) {
        [self presentViewController:settingsViewController animated:YES completion:nil];
    } else {
        [self presentModalViewController:settingsViewController animated:YES];
    }
    
    [settingsViewController release];
}

- (void)persistUseEnteredValues
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    [defaults setValue:self.appIdTextField.text forKey:ENTERED_APPID_KEY];
    [defaults setValue:self.userIdTextField.text forKey:ENTERED_USERID_KEY];
    [defaults setValue:self.backgroundUrlTextField.text forKey:ENTERED_BACKGROUND_URL_KEY];
    [defaults setValue:self.skinNameTextField.text forKey:ENTERED_SKIN_NAME_KEY];
    [defaults setValue:self.securityTokenTextField.text forKey:ENTERED_SECURITY_TOKEN_KEY];
    [defaults setValue:self.actionIdTextField.text forKey:ENTERED_ACTION_ID];
    [defaults setBool:self.closeAfterClickingOffer.on forKey:ENTERED_CLOSE_AFTER_CLICKING_ON_OFFER_KEY];
    
    [defaults synchronize];
    
}

-(void)appWillResignActiveNotification:(NSNotification *)notification
{
    [self persistUseEnteredValues];
}

#pragma mark - Keyboard management

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    
    return NO;
}

- (IBAction)textFieldReturn:(id)sender
{
    [sender resignFirstResponder];
}

- (IBAction)textFieldEditingDidBegin:(UITextField *)sender
{
    self.activeField = sender;
}

- (void) keyboardDidShow: (NSNotification *) notification
{
    // Retrieve the keyboard bounds via the userInfo dictionary
    CGRect kbounds;
    NSDictionary *userInfo = [notification userInfo];
    [(NSValue *)[userInfo objectForKey:
                 @"UIKeyboardBoundsUserInfoKey"] getValue:&kbounds];
    
    // Shrink the scrollview frame
    self.scrollView.frame = CGRectShrinkHeight(self.view.bounds, kbounds.size.height);
    
    // Scroll to active field
    if (self.activeField)
        [self.scrollView scrollRectToVisible:self.activeField.frame animated:YES];
}

- (void)keyboardWillHide:(NSNotification *)notification
{
    // Return to previous text view size
    self.scrollView.frame = self.view.bounds;
}

CGRect CGRectShrinkHeight(CGRect rect, CGFloat amount)
{
    return CGRectMake(rect.origin.x, rect.origin.y,
                      rect.size.width, rect.size.height - amount);
}

- (void)subscribeToKeyboardNotifications
{
    // Subscribe to the two critical notifications
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardDidShow:)
                                                 name:UIKeyboardDidShowNotification object:nil];
}

- (void)unsubscribeFromKeyboardNotifications
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidShowNotification object:nil];
}

#pragma mark -

- (void)showActivityIndication
{
    UIApplication* app = [UIApplication sharedApplication];
	app.networkActivityIndicatorVisible = YES;
}

- (void)stopActivityIndication
{
    UIApplication* app = [UIApplication sharedApplication];
	app.networkActivityIndicatorVisible = NO;
}

- (void)showSDKException:(NSException *)exception {
    UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"The SDK threw an exception"
                                                     message:exception.reason
                                                    delegate:self cancelButtonTitle:@"OK"
                                           otherButtonTitles:nil] autorelease];
    [alert show];
}


#pragma mark - Housekeeping

- (void)dealloc {
    self.offerWallViewController = nil;
    self.interstitialViewController = nil;
    self.activeField = nil;
    self.lastCredentialsToken = nil;
    
    [_actionIdTextField release];
    [super dealloc];
}

- (void)viewDidUnload {
    [self setActionIdTextField:nil];
    [super viewDidUnload];
}
@end
