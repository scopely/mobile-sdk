//
//  SPAdvertisementViewControllerSubclass.h
//  SponsorPaySample
//
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SPAdvertisementViewController.h"

@interface SPAdvertisementViewController (AppIdUserIdAccess)

@property (nonatomic, retain) NSString *appId;
@property (nonatomic, retain) NSString *userId;

- (id)initWithUserId:(NSString *)userId appId:(NSString *)appId;

@end