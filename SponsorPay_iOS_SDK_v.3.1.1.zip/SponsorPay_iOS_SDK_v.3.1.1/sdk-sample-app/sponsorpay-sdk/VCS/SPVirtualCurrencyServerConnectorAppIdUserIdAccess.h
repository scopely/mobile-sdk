//
//  SPVirtualCurrencyServerConnectorAppIdUserIdAccess.h
//  SponsorPaySample
//
//  Created by David Davila on 11/13/12.
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SPVirtualCurrencyServerConnector (AppIdUserIdAccess)

@property (retain) NSString *appId;
@property (retain) NSString *userId;

@end
