//
//  SPPersistence.h
//  SponsorPaySample
//
//  Created by David Davila on 9/28/11.
//  Copyright (c) 2011 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>

#define SP_VCS_LATEST_TRANSACTION_ID_VALUE_NO_TRANSACTION         @"NO_TRANSACTION"

@interface SPPersistence : NSObject

+ (BOOL)didAdvertiserCallbackSucceed;
+ (void)setDidAdvertiserCallbackSucceed:(BOOL)successValue;

+ (BOOL)didActionCallbackSucceedForActionId:(NSString *)actionId;

+ (void)setDidActionCallbackSucceed:(BOOL)successValue
                        forActionId:(NSString *)actionId;

+ (BOOL)userDidAnswerAboutPermissionForSystemDeviceIdentifier;
+ (BOOL)mayAccessSystemDeviceIdentifier;
+ (void)setMayAccessSystemDeviceIdentifier:(BOOL)permissionValue;

+ (NSString *)latestVCSTransactionIdForAppId:(NSString *)appId
                                      userId:(NSString *)userId;

+ (void)setLatestVCSTransactionId:(NSString *)transactionId
                         forAppId:(NSString *)appId
                           userId:(NSString *)userId;

+ (id)nestedValueWithPersistenceKey:(NSString *)persistenceKey
                         nestedKeys:(NSArray *)nestedKeys
                  defaultingToValue:(id)defaultValue;

+ (void)setNestedValue:(id)value
     forPersistenceKey:(NSString *)persistenceKey
            nestedKeys:(NSArray *)nestedKeys;

+ (void)resetAllSDKValues;

@end
