//
//  SponsorPaySDK.m
//  SponsorPaySample
//
//  Created by David Davila on 11/13/12.
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import "SponsorPaySDK.h"
#import "SPAdvertiserManager.h"
#import "SPAdvertisementViewControllerAppIdUserIdAccess.h"
#import "SPVirtualCurrencyServerConnectorAppIdUserIdAccess.h"
#import "SPCredentials.h"
#import "SPActionIdValidator.h"

static const NSUInteger kSPExpectedNumberOfDifferentCredentials = 1;
static NSString *const kSPPersistedUserIdKey = @"SponsorPayUserId";

@implementation SponsorPaySDK

#pragma mark - Credentials and callback management

+ (NSString *)startForAppId:(NSString *)appId
                     userId:(NSString *)userId
              securityToken:(NSString *)securityToken
{
    if (!userId || [userId isEqualToString:@""]) {
        userId = [self anonymousUserId];
    }
    
    NSString *credentialsToken = [SPCredentials credentialsTokenForAppId:appId
                                                                  userId:userId];
    SPCredentials *credentials;
    
    @try {
        credentials = [self credentialsForToken:credentialsToken];
        credentials.securityToken = securityToken;
    }
    
    @catch (NSException *noSuchCredentialsException) {
        credentials = [SPCredentials credentialsWithAppId:appId
                                                   userId:userId
                                            securityToken:securityToken];
        
        [[self activeCredentialsItems] setObject:credentials forKey:credentialsToken];
        [self sendAdvertiserCallbackForCredentials:credentials];
    }
    
    return credentialsToken;
}

+ (NSString *)anonymousUserId
{
    NSString *userId = [self persistedUserId];
    if (!userId) {
        userId = [self generatedRandomUserId];
        [self persistUserId:userId];
    }

    return userId;
}

+ (NSString *)persistedUserId
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    return [defaults stringForKey:kSPPersistedUserIdKey];
}

+ (void)persistUserId:(NSString *)generatedUserId
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:generatedUserId forKey:kSPPersistedUserIdKey];
    [defaults synchronize];
}

+ (NSString *)generatedRandomUserId
{
    NSString *generatedUserId = nil;
    
    Class uuidClass = NSClassFromString(@"NSUUID");
    if (uuidClass) {
        id uuidInstance = [[uuidClass alloc] init];
        generatedUserId = [uuidInstance performSelector:@selector(UUIDString)];
        [uuidInstance release];
    } else {
        static NSString *const alphabet = @"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        static const NSUInteger randomStringLength = 64;
        
        NSMutableString *randomString = [NSMutableString stringWithCapacity:randomStringLength];
        
        for (int i=0; i<randomStringLength; i++) {
            [randomString appendFormat: @"%C", [alphabet characterAtIndex: arc4random() % [alphabet length]]];
        }
        
        generatedUserId = randomString;
    }
    
    return generatedUserId;
}

+ (NSMutableDictionary *)activeCredentialsItems
{
    static NSMutableDictionary *credentialsItems;
    
    if (!credentialsItems) {
        credentialsItems = [[NSMutableDictionary alloc] initWithCapacity:kSPExpectedNumberOfDifferentCredentials];
    }
    
    return credentialsItems;
}

+ (SPCredentials *)uniqueCredentialsItem
{
    NSInteger credentialItemsCount = [self activeCredentialsItems].count;
    
    if (credentialItemsCount != 1) {
        NSString *exceptionReason = credentialItemsCount == 0 ?
        @"Please start the SDK with [SponsorPaySDK startForAppId:userId:securityToken:] before accessing any of its resources" :
        @"More than one active SponsorPay appId / userId. Please use the credentials token to specify the appId / userId combination for which you're accessing the desired resource.";
        
        NSException* noUniqueCredentialsException =
            [NSException exceptionWithName:@"SponsorPayNoUniqueCredentialsException"
                                    reason:exceptionReason
                                  userInfo:nil];
        @throw noUniqueCredentialsException;
    }
    
    return [[[self activeCredentialsItems] allValues] lastObject];
}

+ (SPCredentials *)credentialsForToken:(NSString *)credentialsToken
{
    SPCredentials *credentials = [[self activeCredentialsItems] objectForKey:credentialsToken];
    
    if (!credentials) {
        NSException *invalidCredentialsTokenException =
            [NSException exceptionWithName:@"SponsorPayInvalidCredentialsToken"
                                    reason:@"Please use [SponsorPaySDK startForAppId:userId:securityToken:] to obtain a valid credentials token. (No credentials found for the credentials token specified.)"
                                  userInfo:nil];
        @throw invalidCredentialsTokenException;
    }
    
    return credentials;
}

+ (void)sendAdvertiserCallbackForCredentials:(SPCredentials *)credentials
{
    [[SPAdvertiserManager advertiserManagerForAppId:credentials.appId] reportOfferCompleted];
}

#pragma mark - OfferWall

+ (SPOfferWallViewController *)offerWallViewController
{
    return [self offerWallViewControllerForCredentials:[self uniqueCredentialsItem].credentialsToken];
}

+ (SPOfferWallViewController *)offerWallViewControllerForCredentials:(NSString *)credentialsToken
{
    SPCredentials *credentials = [self credentialsForToken:credentialsToken];
    
    SPOfferWallViewController *offerWallVC = [[SPOfferWallViewController alloc] init];
    offerWallVC.appId = credentials.appId;
    offerWallVC.userId = credentials.userId;
    
    return [offerWallVC autorelease];
}

+ (SPOfferWallViewController *)showOfferWallWithParentViewController:
    (UIViewController<SPOfferWallViewControllerDelegate> *)parent
{
    SPOfferWallViewController *offerWallVC = [self offerWallViewController];
    offerWallVC.delegate = parent;
    [offerWallVC showOfferWallWithParentViewController:parent];
    
    return offerWallVC;
}

#pragma mark - Interstitial

+ (SPInterstitialViewController *)interstitialViewController
{
    return [self interstitialViewControllerForCredentials:[self uniqueCredentialsItem].credentialsToken];
}

+ (SPInterstitialViewController *)interstitialViewControllerForCredentials:(NSString *)credentialsToken
{
    SPCredentials *credentials = [self credentialsForToken:credentialsToken];
    
    SPInterstitialViewController *interstitialVC = [[SPInterstitialViewController alloc] init];
    interstitialVC.appId = credentials.appId;
    interstitialVC.userId = credentials.userId;
    
    return [interstitialVC autorelease];
}

+ (SPInterstitialViewController *)startLoadingInterstitialWithParentViewController:
    (UIViewController<SPInterstitialViewControllerDelegate> *)parent
{
    SPInterstitialViewController *interstitialVC = [self interstitialViewController];
    interstitialVC.delegate = parent;
    [interstitialVC startLoadingWithParentViewController:parent];
    
    return interstitialVC;
}

#pragma mark - VCS

+ (SPVirtualCurrencyServerConnector *)VCSConnector
{
    return [self VCSConnectorForCredentials:[self uniqueCredentialsItem].credentialsToken];
}

+ (SPVirtualCurrencyServerConnector *)VCSConnectorForCredentials:(NSString *)credentialsToken
{
    static NSMutableDictionary *VCSConnectorsPool;
    
    if (!VCSConnectorsPool) {
        VCSConnectorsPool = [[NSMutableDictionary alloc] initWithCapacity:kSPExpectedNumberOfDifferentCredentials];
    }
    
    SPVirtualCurrencyServerConnector *VCSConnector = [VCSConnectorsPool objectForKey:credentialsToken];

    if (!VCSConnector) {
        VCSConnector = [[SPVirtualCurrencyServerConnector alloc] init];
        SPCredentials *credentials = [self credentialsForToken:credentialsToken];
        VCSConnector.appId = credentials.appId;
        VCSConnector.userId = credentials.userId;
        [VCSConnectorsPool setObject:VCSConnector forKey:credentialsToken];
        [VCSConnector autorelease];
        VCSConnector.secretToken = credentials.securityToken;
    }
    
    
    return VCSConnector;
}

+ (SPVirtualCurrencyServerConnector *)requestDeltaOfCoinsNotifyingDelegate:
    (id<SPVirtualCurrencyConnectionDelegate>)delegate
{
    SPVirtualCurrencyServerConnector *VCSConnector = [self VCSConnector];
    VCSConnector.delegate = delegate;
    [VCSConnector fetchDeltaOfCoins];
    
    return VCSConnector;
}


#pragma mark - Rewarded Actions

+ (void)reportActionCompleted:(NSString *)actionID
{
    [self reportActionCompleted:actionID forCredentials:[self uniqueCredentialsItem].credentialsToken];
}

+ (void)reportActionCompleted:(NSString *)actionId forCredentials:(NSString *)credentialsToken
{
    SPCredentials *credentials = [self credentialsForToken:credentialsToken];

    [SPActionIdValidator validateOrThrow:actionId];
    
    [[SPAdvertiserManager advertiserManagerForAppId:credentials.appId]
     reportActionCompleted:actionId];
}

@end
