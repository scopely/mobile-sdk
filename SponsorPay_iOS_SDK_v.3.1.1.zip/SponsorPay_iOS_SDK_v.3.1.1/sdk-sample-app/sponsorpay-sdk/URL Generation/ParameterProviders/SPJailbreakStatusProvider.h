//
//  SPJailbreakStatusProvider.h
//  SponsorPaySample
//
//  Created by David Davila on 11/2/12.
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "SPURLParametersProvider.h"

@interface SPJailbreakStatusProvider : NSObject <SPURLParametersProvider>

@end
