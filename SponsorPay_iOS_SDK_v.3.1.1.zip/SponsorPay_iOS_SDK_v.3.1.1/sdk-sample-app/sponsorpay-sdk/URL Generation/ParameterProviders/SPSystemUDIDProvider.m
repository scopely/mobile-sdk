//
//  SPSystemUDIDProvider.m
//  SponsorPaySample
//
//  Created by David Davila on 11/1/12.
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import "SPSystemUDIDProvider.h"

static NSString *const kSPURLParamKeyUDID = @"device_id";

@implementation SPSystemUDIDProvider

- (NSDictionary *)dictionaryWithKeyValueParameters {
    UIDevice *device = [UIDevice currentDevice];
    
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    return [NSDictionary dictionaryWithObject:device.uniqueIdentifier forKey:kSPURLParamKeyUDID];
#pragma clang diagnostic pop
    
}
@end
