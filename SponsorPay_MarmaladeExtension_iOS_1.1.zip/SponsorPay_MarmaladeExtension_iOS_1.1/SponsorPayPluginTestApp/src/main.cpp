#include <cstdlib>
#include <sstream>

#include "s3e.h"
#include "IwUI.h"
#include "SponsorPayExtension.h"

// Attempt to lock to 25 frames per second.
#define MS_PER_FRAME (1000 / 25)

CIwUITextField* s_AppIDTextField = NULL;
CIwUITextField* s_UserIDTextField = NULL;
CIwUITextField* s_SecurityTokenTextField = NULL;

CIwUILabel* s_ResponseContentsLabel = NULL;
//CIwUILabel* s_TestResultsLabel = NULL;

int32 onSponsorPayExtensionCallbackReceived (void* systemData, void* userData);
const char* getEnteredAppID();
const char* getEnteredUserID();
const char* getEnteredSecurityToken();

int32 onSPDeltaOfCoinsSuccessfulResponse (void* systemData, void* userData);
int32 onSPDeltaOfCoinsRequestError (void* systemData, void* userData);


//-----------------------------------------------------------------------------
class SendAdvertiserCallbackButtonEventHandler : public CIwUIElementEventHandler
{
public:
    virtual bool HandleEvent(CIwEvent* pEvent)
    {
        if (pEvent->GetID() == IWUI_EVENT_BUTTON)
        {
            SP_SendAdvertiserCallbackNow(getEnteredAppID());
            return true;
        }

        return false;
    }
};


class LaunchOfferWallButtonEventHandler : public CIwUIElementEventHandler
{
public:
    virtual bool HandleEvent(CIwEvent* pEvent)
    {
        if (pEvent->GetID() == IWUI_EVENT_BUTTON)
        {
            SP_LaunchOfferWall(getEnteredAppID(), getEnteredUserID());
            return true;
        }

        return false;
    }
};

class GetDeltaOfCoinsButtonEventHandler : public CIwUIElementEventHandler
{
public:
    virtual bool HandleEvent(CIwEvent* pEvent)
    {
        if (pEvent->GetID() == IWUI_EVENT_BUTTON)
        {
            SP_RequestNewCoins(getEnteredAppID(), getEnteredUserID(), getEnteredSecurityToken());
            return true;
        }

        return false;
    }
};


void ExampleInit()
{
    //Initialise the IwUI module
    IwUIInit();

    //Instantiate the view and controller singletons.
    //IwUI will not instantiate these itself, since they can be subclassed to add functionality.
    new CIwUIController;
    new CIwUIView;

    IwGetResManager()->LoadGroup("SPPluginSample.group");

    //Create text input singleton
    new CIwUITextInput;

    //Create softkeyboard
    IwGetUITextInput()->CreateSoftKeyboard();

    //Choose type of soft keyboard
    IwGetUITextInput()->SetEditorMode(CIwUITextInput::eInlineKeyboard); 

    //Add ui structure to UIView singleton
    CIwUIElement* pMain = CIwUIElement::CreateFromResource("Main");
    IwGetUIView()->AddElementToLayout(pMain);

    pMain->LookupChildNamed(s_AppIDTextField, "AppIDTextField");
    pMain->LookupChildNamed(s_UserIDTextField, "UserIDTextField");
    pMain->LookupChildNamed(s_SecurityTokenTextField, "SecurityTokenTextField");


    pMain->LookupChildNamed(s_ResponseContentsLabel, "ResponseContentsLabel");

    if (SponsorPayExtensionAvailable()) {
      s_ResponseContentsLabel->SetCaption("SponsorPay Extension available");
    } else {
      s_ResponseContentsLabel->SetCaption("SponsorPay Extension not available!");
    }


    CIwUIButton* sendAdvertiserCallbackButton;
    pMain->LookupChildNamed(sendAdvertiserCallbackButton, "SendAdvertiserCallbackButton");
    sendAdvertiserCallbackButton->AddEventHandler(new SendAdvertiserCallbackButtonEventHandler);

    CIwUIButton* launchOfferWallButton;
    pMain->LookupChildNamed(launchOfferWallButton, "LaunchOfferWallButton");
    launchOfferWallButton->AddEventHandler(new LaunchOfferWallButtonEventHandler);

    CIwUIButton* getDeltaOfCoinsButton;
    pMain->LookupChildNamed(getDeltaOfCoinsButton, "GetDeltaOfCoinsButton");
    getDeltaOfCoinsButton->AddEventHandler(new GetDeltaOfCoinsButtonEventHandler);
 
}

//-----------------------------------------------------------------------------
void ExampleShutDown()
{
    delete IwGetUITextInput();
    delete IwGetUIController();
    delete IwGetUIView();

    //Terminate the IwUI module
    IwUITerminate();
}
//-----------------------------------------------------------------------------
bool ExampleUpdate()
{
    //Update the controller (this will generate control events etc.)
    IwGetUIController()->Update();

    //Update the view (this will do animations etc.) The example framework has
    //a fixed framerate of 20fps, so we pass that duration to the update function.
    IwGetUIView()->Update(1000/20);

    return true;
}
//-----------------------------------------------------------------------------
void ExampleRender()
{
    //Render the UI
    IwGetUIView()->Render();

    //Flush IwGx
    IwGxFlush();

    //Display the rendered frame
    IwGxSwapBuffers();
}

//-----------------------------------------------------------------------------
// Main global function
//-----------------------------------------------------------------------------
int main()
{
    //IwGx can be initialised in a number of different configurations to help the linker eliminate unused code.
    //Normally, using IwGxInit() is sufficient.
    //To only include some configurations, see the documentation for IwGxInit_Base(), IwGxInit_GLRender() etc.
    IwGxInit();

    // Example main loop
    ExampleInit();

    // Set screen clear colour
    IwGxSetColClear(0xff, 0xff, 0xff, 0xff);
    IwGxPrintSetColour(128, 128, 128);

    // Register for callbacks from the SponsorPay Extension
    s3eResult registrationResult = SponsorPayExtensionRegister(SPONSORPAYEXTENSION_CALLBACK_CURRENCY_REQUEST_SUCCESS,
                                                              onSPDeltaOfCoinsSuccessfulResponse,
                                                              NULL);
	registrationResult = SponsorPayExtensionRegister(SPONSORPAYEXTENSION_CALLBACK_CURRENCY_REQUEST_ERROR,
                                                     onSPDeltaOfCoinsRequestError,
                                                     NULL);
    
    while (1)
    {
        s3eDeviceYield(0);
        s3eKeyboardUpdate();
        s3ePointerUpdate();

        int64 start = s3eTimerGetMs();

        bool result = ExampleUpdate();
        if  (
            (result == false) ||
            (s3eKeyboardGetState(s3eKeyEsc) & S3E_KEY_STATE_DOWN) ||
            (s3eKeyboardGetState(s3eKeyAbsBSK) & S3E_KEY_STATE_DOWN) ||
            (s3eDeviceCheckQuitRequest())
            )
            break;

        // Clear the screen
        IwGxClear(IW_GX_COLOUR_BUFFER_F | IW_GX_DEPTH_BUFFER_F);
        ExampleRender();

        // Attempt frame rate
        while ((s3eTimerGetMs() - start) < MS_PER_FRAME)
        {
            int32 yield = (int32) (MS_PER_FRAME - (s3eTimerGetMs() - start));
            if (yield<0)
                break;
            s3eDeviceYield(yield);
        }
    }
    ExampleShutDown();
    IwGxTerminate();
    return 0;
}

int32 onSPDeltaOfCoinsSuccessfulResponse(void* systemData, void* userData) {
    SP_DeltaOfCoinsResponse *deltaOfCoinsResponse = (SP_DeltaOfCoinsResponse *)systemData;

    std::ostringstream results;
    results << "Delta of coins: " << deltaOfCoinsResponse->deltaOfCoins
		<< "\nLatest transaction ID: " << std::string(deltaOfCoinsResponse->latestTransactionId);

    s_ResponseContentsLabel->SetCaption(results.str().c_str());
    return 0;
}

int32 onSPDeltaOfCoinsRequestError (void* systemData, void* userData) {
	SP_ErrorResponse *errorResponse = (SP_ErrorResponse *)systemData;

	std::ostringstream results;
	results << "Error in delta of coins request:\nErrorType: " << errorResponse->errorType <<
		"\nErrorCode: " << std::string(errorResponse->errorCode) <<
		"\nErrorMessage: " << std::string(errorResponse->errorMessage);

	s_ResponseContentsLabel->SetCaption(results.str().c_str());
	return 0;
}



const char* getEnteredAppID() {
    return IwSafeCast<CIwUITextField*>(s_AppIDTextField)->GetCaption();
}
const char* getEnteredUserID() {
    return IwSafeCast<CIwUITextField*>(s_UserIDTextField)->GetCaption();
}
const char* getEnteredSecurityToken() {
    return IwSafeCast<CIwUITextField*>(s_SecurityTokenTextField)->GetCaption();
}

