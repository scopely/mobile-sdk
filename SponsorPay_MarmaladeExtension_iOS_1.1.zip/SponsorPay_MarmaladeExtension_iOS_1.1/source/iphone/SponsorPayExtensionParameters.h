//
//  SponsorPayExtensionParameters.h
//  SponsorPaySDKNativeiOS
//
//  Created by David on 8/1/12.
//  Copyright 2012 SponsorPay GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SPUrlFactory.h"

@interface SponsorPayExtensionParameters: NSObject <SPUrlParametersProvider> {

    @private
	NSDictionary *pluginParameters;
    
}

-(id)initWithPluginVersion:(NSString *)pluginVersion;

-(NSDictionary *)dictionaryWithKeyValueParameters;


@end
