//
//  SponsorPayExtensionParameters
//  SponsorPaySDKNativeiOS
//
//  Created by David on 8/1/12.
//  Copyright 2012 SponsorPay GmbH. All rights reserved.
//

#import "SponsorPayExtensionParameters.h"
#import "SPUrlFactory.h"

@interface SponsorPayExtensionParameters()

@property (retain) NSDictionary *pluginParameters;

@end



@implementation SponsorPayExtensionParameters

@synthesize pluginParameters;

-(id)initWithPluginVersion:(NSString *)pluginVersion
{
    self = [super init];
    if (self)
    {
        [SPUrlFactory customParametersProvider:self];
        
        self.pluginParameters = [NSDictionary dictionaryWithObjectsAndKeys:
                                 @"marmalade", @"framework",
                                 pluginVersion, @"plugin_version",
                                 nil];
    }
    return self;
}


- (NSDictionary *)dictionaryWithKeyValueParameters
{
    return [NSDictionary dictionaryWithDictionary:pluginParameters];
}


-(void)dealloc
{
    [self.pluginParameters release];
    
    [super dealloc];
}

@end
