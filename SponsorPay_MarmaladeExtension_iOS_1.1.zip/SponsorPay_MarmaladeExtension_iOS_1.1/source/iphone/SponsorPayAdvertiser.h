//
//  SponsorPayAdvertiser.h
//  SponsorPaySDKNativeiOS
//
//  Created by David on 8/1/12.
//  Copyright 2012 SponsorPay GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface SponsorPayAdvertiser : NSObject {

}

- (void) sendAdvertiserCallback:(NSString *)appId;


@end
