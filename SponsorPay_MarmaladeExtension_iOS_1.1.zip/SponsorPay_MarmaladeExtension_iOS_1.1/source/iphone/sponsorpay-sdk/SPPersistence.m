//
//  SPPersistence.m
//  SponsorPaySample
//
//  Created by David Davila on 9/28/11.
//  Copyright (c) 2011 SponsorPay. All rights reserved.
//

#import "SPPersistence.h"

#define SP_ADVERTISER_CALLBACK_SUCCESS_KEY                        @"SPDidAdvertiserCallbackSucceed"
#define SP_VCS_LATEST_TRANSACTION_IDS_KEY                         @"SPVCSLatestTransactionIds"
#define SP_MAY_ACCESS_SYSTEM_DEVICE_IDENTIFIER_KEY                @"SPMayAccessSystemDeviceIdentifier"
#define SP_USER_DID_ANSWER_ABOUT_PERMISSION_FOR_SYSTEM_UDID_KEY       @"SPUserDidAnswerAboutPermissionForSystemDeviceIdentifier"


@implementation SPPersistence

+ (BOOL)didAdvertiserCallbackSucceed
{
    return [[NSUserDefaults standardUserDefaults] boolForKey:SP_ADVERTISER_CALLBACK_SUCCESS_KEY]; 
}

+ (void)setDidAdvertiserCallbackSucceed:(BOOL)successValue
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setBool:successValue forKey:SP_ADVERTISER_CALLBACK_SUCCESS_KEY];
    [defaults synchronize];
}

+ (BOOL)userDidAnswerAboutPermissionForSystemDeviceIdentifier
{
    return [[NSUserDefaults standardUserDefaults] boolForKey:SP_USER_DID_ANSWER_ABOUT_PERMISSION_FOR_SYSTEM_UDID_KEY];
}

+ (BOOL)mayAccessSystemDeviceIdentifier
{
    return [[NSUserDefaults standardUserDefaults] boolForKey:SP_MAY_ACCESS_SYSTEM_DEVICE_IDENTIFIER_KEY];
}

+ (void)setMayAccessSystemDeviceIdentifier:(BOOL)permissionValue
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setBool:permissionValue forKey:SP_MAY_ACCESS_SYSTEM_DEVICE_IDENTIFIER_KEY];
    [defaults setBool:YES forKey:SP_USER_DID_ANSWER_ABOUT_PERMISSION_FOR_SYSTEM_UDID_KEY];
    [defaults synchronize];
}

+ (NSString *)latestVCSTransactionIdForAppId:(NSString *)appId
                                      userId:(NSString *)userId
{
    NSDictionary *fetchedTransactionIds =
    [[NSUserDefaults standardUserDefaults] dictionaryForKey:SP_VCS_LATEST_TRANSACTION_IDS_KEY];
    
    NSDictionary *transactionIdsForApp = [fetchedTransactionIds objectForKey:appId];
    NSString *transactionIdForAppAndUser = [transactionIdsForApp objectForKey:userId];
    
    if (!transactionIdForAppAndUser) {
        transactionIdForAppAndUser = SP_VCS_LATEST_TRANSACTION_ID_VALUE_NO_TRANSACTION;
    }
    
    return transactionIdForAppAndUser;
}

+ (void)setLatestVCSTransactionId:(NSString *)transactionId
                         forAppId:(NSString *)appId
                           userId:(NSString *)userId
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *fetchedTransactionIds = [defaults dictionaryForKey:SP_VCS_LATEST_TRANSACTION_IDS_KEY];
    NSMutableDictionary *editableTransactionIds =
    [NSMutableDictionary dictionaryWithDictionary:fetchedTransactionIds]; // TODO: test with null fetchedTransactions

    NSDictionary *transactionIdsForApp = [fetchedTransactionIds objectForKey:appId];
    NSMutableDictionary *editableTransactionIdsForApp =
    [NSMutableDictionary dictionaryWithDictionary:transactionIdsForApp]; // test with null
    
    [editableTransactionIdsForApp setObject:transactionId forKey:userId];
    
    [editableTransactionIds setObject:editableTransactionIdsForApp forKey:appId];
    [defaults setObject:editableTransactionIds forKey:SP_VCS_LATEST_TRANSACTION_IDS_KEY];
    [defaults synchronize];
}

+ (void)resetAllSDKValues
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults removeObjectForKey:SP_ADVERTISER_CALLBACK_SUCCESS_KEY];
    [defaults removeObjectForKey:SP_VCS_LATEST_TRANSACTION_IDS_KEY];
    [defaults removeObjectForKey:SP_MAY_ACCESS_SYSTEM_DEVICE_IDENTIFIER_KEY];
    [defaults removeObjectForKey:SP_USER_DID_ANSWER_ABOUT_PERMISSION_FOR_SYSTEM_UDID_KEY];
    
    [defaults synchronize];
}

@end
