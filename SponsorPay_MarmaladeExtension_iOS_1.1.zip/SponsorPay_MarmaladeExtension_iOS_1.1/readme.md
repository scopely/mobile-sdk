# Supported platforms

The SponsorPay Marmalade Extension supports currently Android and iOS.

# Installation

Copy the SponsorPay Extension into your Marmalade Extensions directory (e.g. `C:/Marmalade/6.0/Extensions`).

# If you want to run the test app (not required)

The test app is inside the `SponsorPayPluginTestApp` folder. Feel free to move it out of the extension folder and go through the following steps:

1. Run the `SponsorPayPluginTestApp.mkb` script inside the test app directory.
1. When your Marmalade IDE of choice (e.g. XCode) opens, run the app once with the "(x86) Debug" configuration. This is only to build the application resources. When the app runs in the simulator you may get some warnings. Just ignore them and close the app.
1. Now build the application with the "GCC (ARM) Release" configuration.
1. When the Marmalade System Deployment Tool opens, in the Select build section select "ARM GCC Release" and click "Next Stage".
1. In the "Select configuration(s)" section leave "Default" selected and click "Next Stage".
1. In the "Select Platform" section select "iPhone" and click "Next Stage".
1. Select if you want to just generate an iPhone package, or to install and run it too from the deployment tool, and click "Deploy All".

# How to integrate the SponsorPay Extension into your own project.

In your project's `mkb` file add `SponsorPayExtension` to the `subprojects` section and `<include sponsorpay-sdk-assets>` to the `assets` section, like this:

	subprojects
	{
	    SponsorPayExtension
	    [... some other subprojects your app depends on... ]
	}

	assets
	{
	    <include "sponsorpay-sdk-assets">
		[... some other assets your app depends on... ]
	}


# How to use the SponsorPay Extension

The extension defines a number of functions you can call to send the Advertiser Callback, launch the Mobile OfferWall, and request the amount of coins earned to the VCS.

All the SponsorPay Extension functions, enums and struct types are declared in [`SponsorPayExtension.h`](https://github.com/SponsorPay/marmalade-extension/blob/master/ios/h/SponsorPayExtension.h).

Before calling any function from the extension, you can make sure it's available in the platform your app is running by calling `SponsorPayExtensionAvailable()`. This function returns an `s3eBool` boolean result.

## How to send the Advertiser Callback

- To send the callback immediately, invoke `SP_SendAdvertiserCallbackNow(const char* appId)`, providing your App ID as its only parameter.
- To send the callback after a specified delay, call `SP_SendAdvertiserCallbackWithDelay(const char* appId, int delayMin)`, passing it your App ID and the desired delay in minutes.

## How to show the Mobile OfferWall

- To launch the OfferWall, invoke `SP_LaunchOfferWall(const char* appId, const char* userId)`

The function requires your App ID and the current user's ID as parameters.

## How to request the number of coins your user has earned since the last check (Delta of Coins request)

Call `SP_RequestNewCoins(const char* appId, const char* userId, const char* securityToken)`, providing your app ID, the current user's ID and your security token.

The answer will be delivered asynchronously to your registered function for the callback of type:

- `SPONSORPAYEXTENSION_CALLBACK_CURRENCY_REQUEST_SUCCESS`, if the request is successful,
- `SPONSORPAYEXTENSION_CALLBACK_CURRENCY_REQUEST_ERROR`, if the request fails.

Refer to the section [How to register for callbacks from the extension](#callbackRegistration) to learn more about callback registration.

### Example user defined function for the callback: delta of coins request successful

	int32 onSPDeltaOfCoinsSuccessfulResponse(void* systemData, void* userData) {
	    SP_DeltaOfCoinsResponse *deltaOfCoinsResponse = (SP_DeltaOfCoinsResponse *)systemData;
	
	    double amountOfNewCoins = deltaOfCoinsResponse->deltaOfCoins;
	
	    // Do something with the received amount of new coins.
	    // You can also access the latest transaction ID. 
	    // Refer to SponsorPayExtension.h for details about the SP_DeltaOfCoinsResponse type.
	
	    return 0;
	}

### Example user defined function for the callback: delta of coins request error

	int32 onSPDeltaOfCoinsRequestError (void* systemData, void* userData) {
	    SP_ErrorResponse *errorResponse = (SP_ErrorResponse *)systemData;
	
	    switch (errorResponse->errorType) {
	        case SP_ERROR_NO_INTERNET_CONNECTION:
	            // your own error handling code here
	        break;
	        
	        case SP_ERROR_INVALID_RESPONSE:
	            // your own error handling code here
	        break;
	        
	        case SP_ERROR_INVALID_RESPONSE_SIGNATURE:
	            // your own error handling code here
	        break;
	        
	        case SP_SERVER_RETURNED_ERROR:
	            // Access errorResponse->errorType and errorResponse->errorMessage
	            // to get more details about this error
	            // Refer to SponsorPayExtension.h for details about the SP_ErrorResponse type.
	        break;
	
	        case SP_ERROR_OTHER:
	        default:
	            // your own error handling code here
	        break;
	    }
	
	    return 0;
	}


<a id="callbackRegistration"> </a>
## How to register for callbacks from the extension

Some of the calls to the extension defined functions (most notably, those which send a request to the server and await for an answer) are performed asynchronously: your calling thread won't wait until the answer from the server is received, you will instead receive a callback from the SponsorPay extension to a function defined by you.

Those functions you can define and register to receive callbacks from the extension must conform to the Marmalade's `s3eCallback` callback function type (defined in `s3eTypes.h`). Here's an example:

	int32 onSomeCallbackFromTheSPExtensionReceived (void* systemData, void* userData);

As you can see, two parameters are passed: a pointer to `systemData` which is the data passed from the SponsorPay extension to your application, and a pointer to `userData`, which is some data yourself can provide when registering for callbacks from the extension (and it's absolutely not required).

And speaking about registering for callbacks from the extension, here's how to do it. Call this function:


	s3eResult SponsorPayExtensionRegister(SponsorPayExtensionCallback callbackID,
	                                      s3eCallback yourCallbackHandlingFunction,
	                                      void* userData);

The first parameter corresponds to the type of callback you're registering for. Take a look at the table below to see which kinds of callback the SponsorPay extension provides.

The second parameter, `yourCallbackHandlingFunction`, is the function defined by yourself that will handle callbacks from the extension. 
The last parameter you can safely ignore, just note that this corresponds with the `userData` pointer I referred to before and that you would get as a parameter to your callback handling function.

| **Callback type**                                           | **Description**                                           | **Type of `systemData`**       |
|:------------------------------------------------------------|:----------------------------------------------------------|:-------------------------------|
| `SPONSORPAYEXTENSION_CALLBACK_CURRENCY_REQUEST_SUCCESS`     | Successful answer received for the Delta of Coins request | `SP_DeltaOfCoinsResponse`      |
| `SPONSORPAYEXTENSION_CALLBACK_CURRENCY_REQUEST_ERROR`       | Error triggered by the Delta of Coins request             | `SP_ErrorResponse`             |


