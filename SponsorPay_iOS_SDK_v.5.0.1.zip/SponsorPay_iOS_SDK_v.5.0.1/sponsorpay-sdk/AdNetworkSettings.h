
//  ThirdPartySettings.h
//  SponsorPay iOS SDK
//
// Copyright 2011-2013 SponsorPay. All rights reserved.
//
//
//#define SPAdColonySDKAvailable_2_0_1_33
//#define SPAdColonyAppID @""
//#define SPAdColonySecretKey @""
//#define SPAdColonyVideoZoneID @""
//
//#define SPVungleSDKAvailable_1_3_2
//#define SPVungleAppID @""
//
//// Define SPFlurrySDKAvailable_4_2_1 to enable support for the Flurry SDK versions 4.2.1 to 4.2.3
//#define SPFlurrySDKAvailable_4_2_1
//#define SPFlurryAPIKey @""
//#define SPFlurryVideoAdsSpace @""
