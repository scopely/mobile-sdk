//
//  SPURLUtil.h
//  SponsorPay iOS SDK
//
//  Copyright 2011 SponsorPay. All rights reserved.
//


#import <Foundation/Foundation.h>

// Category to add URL encoding to the NSString class
@interface NSString(Escaping)

- (NSString*)stringWithPercentEscape;
- (NSString*)stringWithPercentUnescape;

@end


// Category to add parsing of the query string to the NSURL class
@interface NSURL(Parsing)

- (NSDictionary *)queryDictionary;

@end


// This is here as a hack to fix a bug with the compiler where categories
// get compiled out of static libs.
@interface CategoryDummy : NSObject {
	
}
@end

