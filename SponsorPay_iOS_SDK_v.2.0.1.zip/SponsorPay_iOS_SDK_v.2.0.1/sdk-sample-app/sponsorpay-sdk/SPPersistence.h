//
//  SPPersistence.h
//  SponsorPaySample
//
//  Created by David Davila on 9/28/11.
//  Copyright (c) 2011 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SPPersistence : NSObject

+ (BOOL)didAdvertiserCallbackSucceed;
+ (void)setDidAdvertiserCallbackSucceed:(BOOL)successValue;

+ (BOOL)userDidAnswerAboutPermissionForSystemDeviceIdentifier;
+ (BOOL)mayAccessSystemDeviceIdentifier;
+ (void)setMayAccessSystemDeviceIdentifier:(BOOL)permissionValue;

+ (NSString *)latestVCSTransactionIdForUser:(NSString *)userId;
+ (void)setLatestVCSTransactionId:(NSString *)idValue
                        forUserId:(NSString *)userId;

@end
