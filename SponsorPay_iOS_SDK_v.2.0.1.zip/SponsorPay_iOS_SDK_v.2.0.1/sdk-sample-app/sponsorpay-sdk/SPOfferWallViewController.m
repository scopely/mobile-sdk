//
//  SPOfferWallViewController.m
//  SponsorPay iOS SDK
//
//  Copyright 2011 SponsorPay. All rights reserved.
//

#import "SPOfferWallViewController.h"
#import "SPURLUtil.h"
#import "SP_URL_scheme.h"
#import "SP_SDK_versions.h"
#import "SPUrlFactory.h"
#import "SPPersistence.h"

// The base url to retrieve the offer wall from
#define OFFERWALL_BASE_URL		@"https://iframe.sponsorpay.com/mobile"

// URL parameters to pass on the query string
#define URL_PARAM_APP_ID		@"appid"
#define URL_PARAM_USER_ID		@"uid"

#define SHOULD_OFFERWALL_FINISH_ON_REDIRECT_DEFAULT NO

static NSString *offerWallBaseUrl = OFFERWALL_BASE_URL;

#define kSPOfferWallErrorAlertTag 10
#define kSPOfferWallUDIDPermissionAlertTag 11

// Private methods
@interface SPOfferWallViewController()

- (void)loadUrl:(NSString *) urlAddress;
- (void)animateLoadingViewIn;
- (void)animateLoadingViewOut;
@end

// Implementation
@implementation SPOfferWallViewController

@synthesize appId;
@synthesize userId;
@synthesize delegate;
@synthesize shouldFinishOnRedirect;

// Init the class with a userId and appId
-(id) initWithUserId:(NSString *) _userId appId:(NSString *)_appId {
	
	self = [super init];
	userId = [_userId retain];
	appId = [_appId retain];
	self.shouldFinishOnRedirect = SHOULD_OFFERWALL_FINISH_ON_REDIRECT_DEFAULT;
	return self;
}

/**
 * Overriden from UIViewController.
 * Creates the view that the controller manages.
 **/
- (void)loadView {
	// full screen webview
    CGPoint origin = {0, 0};
    CGRect applicationFrame = [[UIScreen mainScreen] applicationFrame];

    CGSize sizeForView;
    UIInterfaceOrientation currentOrientation = [UIDevice currentDevice].orientation;
    
    if (currentOrientation == UIInterfaceOrientationLandscapeLeft
        || currentOrientation == UIInterfaceOrientationLandscapeRight) {
        sizeForView.width = applicationFrame.size.height;
        sizeForView.height = applicationFrame.size.width;
    } else {
        sizeForView = applicationFrame.size;
    }
    
    CGRect viewFrame = {origin, sizeForView};

    webView = [[UIWebView alloc] initWithFrame:viewFrame];
	webView.delegate = self;
	self.view = webView;
	
    self.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(appWillEnterForegroundNotification:) 
												 name:UIApplicationWillEnterForegroundNotification 
											   object:nil];
}

- (SPLoadingProgressViewController *)loadingProgressView {
    if (nil == loadingProgressView)
        loadingProgressView = [[SPLoadingProgressViewController alloc] init];
    return loadingProgressView;
}

- (void)animateLoadingViewIn
{
    self.loadingProgressView.view.center = [self.loadingProgressView.view convertPoint:self.view.center fromView:self.view];

    if (self.loadingProgressView.view.superview) {
        [self.loadingProgressView.view removeFromSuperview];
    }
    
    [self.view addSubview: self.loadingProgressView.view];
    
    loadingProgressView.view.alpha = INITIAL_ALPHA_FOR_LOADING_VIEW;
    if ([[UIView class] respondsToSelector:@selector(animateWithDuration:animations:)]) {
        // Apply block-based animations
        [UIView animateWithDuration:INTRO_ANIMATION_LENGTH_FOR_LOADING_VIEW
                         animations:^{
                             loadingProgressView.view.alpha = FINAL_ALPHA_FOR_LOADING_VIEW;
                         }
         ];
    } else {
        // Use beginAnimations:context: / commitAnimations animation methods
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:INTRO_ANIMATION_LENGTH_FOR_LOADING_VIEW];
        loadingProgressView.view.alpha = FINAL_ALPHA_FOR_LOADING_VIEW;
        [UIView commitAnimations];
    }
}
- (void)animateLoadingViewOut
{
    if (!self.loadingProgressView.view.superview) {
        return;
    }
    
    if ([[UIView class] respondsToSelector:@selector(animateWithDuration:animations:)]) {
        // Apply block-based animations
        [UIView animateWithDuration:OUTRO_ANIMATION_LENGTH_FOR_LOADING_VIEW
                         animations:^{
                             self.loadingProgressView.view.alpha = INITIAL_ALPHA_FOR_LOADING_VIEW;
                         }
                         completion:^(BOOL finished){
                             [self.loadingProgressView.view removeFromSuperview];
                         }
         ];
    } else {
        // Use beginAnimations:context: / commitAnimations animation methods
        [UIView beginAnimations:LOADING_VIEW_OUTRO_ANIMATION_ID context:NULL];
        [UIView setAnimationDuration:OUTRO_ANIMATION_LENGTH_FOR_LOADING_VIEW];
        
        self.loadingProgressView.view.alpha = INITIAL_ALPHA_FOR_LOADING_VIEW;
        
        [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
        [UIView commitAnimations];
    }
}

-(void)animationDidStop:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context {
    if ([animationID isEqualToString:LOADING_VIEW_OUTRO_ANIMATION_ID]) {
        [self.loadingProgressView.view removeFromSuperview];
    }
}

-(void)startLoadingOfferWall {
    SPUrlFactory *urlFactory = [SPUrlFactory urlFactoryWithDefaultParametersProvidersWithBaseUrl:offerWallBaseUrl
                                                                                sdkVersionValue:SP_PUBLISHER_SDK_VERSION
                                                                 shouldUseSystemDeviceIdentifier:[SPPersistence mayAccessSystemDeviceIdentifier]];
    
    [urlFactory addKey:URL_PARAM_APP_ID withValue:self.appId];
    [urlFactory addKey:URL_PARAM_USER_ID withValue:self.userId];
    
    [urlFactory addDeviceInfo];
    
    NSString *urlString = [urlFactory urlString];
    
    NSLog(@"SponsorPay Mobile Offer Wall will be requested using url: %@", urlString);
    
    [self loadUrl:urlString];
}

- (void)askUserForSystemDeviceIdPermission {
#define kSPSystemDeviceIdentifierPermissionsAlertTitle @"Do you want to share and transmit your device information?"
#define kSPSystemDeviceIdentifierPermissionsAlertMessage @"If you share this information, more offers will be available to you."
#define kSPSystemDeviceIdentifierPermissionsAlertButtonYes @"Yes"
#define kSPSystemDeviceIdentifierPermissionsAlertButtonNo @"No"
 
    
    UIAlertView *permissionAlertView = [[UIAlertView alloc] initWithTitle:kSPSystemDeviceIdentifierPermissionsAlertTitle
                                                                  message:kSPSystemDeviceIdentifierPermissionsAlertMessage
                                                                 delegate:self
                                                        cancelButtonTitle:nil
                                                        otherButtonTitles:kSPSystemDeviceIdentifierPermissionsAlertButtonYes,
                                        kSPSystemDeviceIdentifierPermissionsAlertButtonNo, nil];

#define kSPSystemUDIDDialogAllowButtonIndex 0
#define kSPSystemUDIDDialogDoNotAllowButtonIndex 1
    
    permissionAlertView.tag = kSPOfferWallUDIDPermissionAlertTag;
    [permissionAlertView show];
    [permissionAlertView release];
}

/**
 * Overriden from UIViewController.
 * Called after the controller’s view is loaded into memory. 
 **/
- (void)viewDidLoad {
    [self animateLoadingViewIn];
    
    isRedirecting = NO;
    
    if ([SPPersistence userDidAnswerAboutPermissionForSystemDeviceIdentifier]) {
        [self startLoadingOfferWall];
    } else {
        [self askUserForSystemDeviceIdPermission];
    }
}

/**
 * Overriden from UIViewController.
 * Returns a Boolean value indicating whether the view controller supports the specified orientation.
 * As all orientations are supported, returns always YES.
 **/

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return YES;
}

/**
 * Overriden from UIViewController.
 * Called when the controller’s view is released from memory.
 **/
- (void)viewDidUnload {
	[[NSNotificationCenter defaultCenter] removeObserver:self];
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
	[webView release];
	webView = nil;
}

/**
 * Overriden from UIViewController.
 * Sent to the view controller when the application receives a memory warning.
 **/
- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

/**
 * Selector registered with the UIApplicationWillEnterForegroundNotification.
 * Used to reload the WebView if it hasn't been closed when the user was redirected
 * outside the app.
 **/
- (void)appWillEnterForegroundNotification:(NSNotification *)notification {
	if (webView != nil && webView.superview != nil ) {
		[webView reload];
	}
}

/**
 * Loads a given URL into the WebView
 */
-(void)loadUrl:(NSString *) urlAddress {
	//Create a URL object.
	NSURL *url = [NSURL URLWithString:urlAddress];
	
	//URL Requst Object
	NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
	
	//Load the request in the UIWebView.
	[webView loadRequest:requestObj];
}

/**
 * Selector from the UIWebViewDelegate protocol. Captures the links on which the user
 * clicks and intercepts those which start with the defined SPONSORPAY_URL_SCHEME in order
 * to close the WebView and / or redirect the user outside the app (i.e. to the App Store)
 **/
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {

	NSURL *url = [request URL];
	NSString *scheme = [url scheme];
	BOOL continueLoading = YES;
	
	if ([scheme isEqualToString:SPONSORPAY_URL_SCHEME]) {

//		NSLog(@"url caught: %@", [url absoluteString]);
//		NSLog(@"query string: %@", [url query]);
		
		// The path must be preceeded by '//', '/' or ':' are unacceptable
		NSString *path = [url host];
		
		if ([path isEqualToString:SPONSORPAY_EXIT_PATH]) {
			continueLoading = NO;
			isRedirecting = YES;
		
			NSDictionary *queryDict = [url queryDictionary];
			NSString *destination = [[queryDict valueForKey:@"url"] stringWithPercentUnescape];
			
//			NSLog(@"destination: %@, (destination == nil): %d, [destination isEqualToString:@""]: %d, self.shouldFinishOnRedirect %d",
//				  destination, (destination == nil), [destination isEqualToString:@""], self.shouldFinishOnRedirect);
			
			BOOL shouldFinish = (destination == nil) || [destination isEqualToString:@""] || self.shouldFinishOnRedirect;
			
			
			
			if (shouldFinish && delegate && [delegate respondsToSelector:@selector(offerWallViewController:isFinishedWithStatus:)]) {
				[delegate offerWallViewController:self isFinishedWithStatus:0];
			}
			
			
//			NSLog(@"Redirecting to url: %@", destination);
			[[UIApplication sharedApplication] openURL: [NSURL URLWithString:destination]];
		}
	}
	
	return continueLoading;
}

/**
 * Selector from the UIWebViewDelegate protocol. When an error is triggered
 * by the WebView, displays an alert dialog to the user with an error message
 * and calls the delegate with the SPONSORPAY_ERR_NETWORK error code.
 **/
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
    // Error -999 is triggered when the WebView starts a request before the previous one was completed.
    // We assume that kind of error can be safely ignored.
    if ([error code] != -999) {
        
        if (! isRedirecting) {
            
            // If the webview fails to load, present an alert for the user.
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle: [error localizedDescription]
                                                            message: nil
                                                           delegate: self
                                                  cancelButtonTitle: @"OK"
                                                  otherButtonTitles: nil];
            alert.tag = kSPOfferWallErrorAlertTag;
            [alert show];
            [alert autorelease];
                    
            isRedirecting = NO;
        }
    
    }    
}

/**
 * Method from the UIWebViewDelegate protocol. Called when web view finishes loading the mobile offerwall.
 **/
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [self animateLoadingViewOut];
}

/**
 * Handles user clicks on the dialogs' buttons.
 */
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {

    switch (alertView.tag) {
        case kSPOfferWallErrorAlertTag:
            if (delegate && [delegate respondsToSelector:@selector(offerWallViewController:isFinishedWithStatus:)]) {
                [delegate offerWallViewController:self isFinishedWithStatus:SPONSORPAY_ERR_NETWORK];
            }
            break;
        case kSPOfferWallUDIDPermissionAlertTag:
            if (kSPSystemUDIDDialogAllowButtonIndex == buttonIndex) {
                [SPPersistence setMayAccessSystemDeviceIdentifier:YES];
            } else {
                [SPPersistence setMayAccessSystemDeviceIdentifier:NO];
            }
            
            [self startLoadingOfferWall];
            break;
    }
}

+ (void)overrideBaseUrlWithUrl:(NSString *)newUrl {
    [offerWallBaseUrl release];
    offerWallBaseUrl = [newUrl retain];
}

+ (void)restoreBaseUrlToDefault {
    [SPOfferWallViewController overrideBaseUrlWithUrl:OFFERWALL_BASE_URL];
}

- (void)dealloc {
	self.appId = nil;
    self.userId = nil;
	[webView release];
    if (loadingProgressView) {
        [loadingProgressView release];
    }
    [super dealloc];
}

@end
