//
//  SPVirtualCurrencyConnector.m
//  SponsorPaySample
//
//  Created by David Davila on 9/23/11.
//  Copyright (c) 2011 SponsorPay. All rights reserved.
//

#import "SPVirtualCurrencyServerConnection.h"
#import "SPUrlFactory.h"
#import "SBJsonParser.h"
#import "SPSignature.h"
#import "SPPersistence.h"

#define SP_VCS_BASE_URL		(@"https://api.sponsorpay.com/vcs/v1/")
#define SP_CURRENCY_DELTA_REQUEST_RESOURCE (@"new_credit.json")

// URL parameters to pass on the query string
#define URL_PARAM_KEY_APP_ID                    @"appid"
#define URL_PARAM_KEY_USER_ID                   @"uid"
#define URL_PARAM_KEY_LAST_TRANSACTION_ID       @"ltid"
#define URL_PARAM_KEY_TIMESTAMP                 @"timestamp"

#define SP_VCS_JSON_KEY_DELTA_OF_COINS          @"delta_of_coins"
#define SP_VCS_JSON_KEY_LATEST_TRANSACTION_ID   @"latest_transaction_id"
#define SP_VCS_JSON_KEY_ERROR_CODE              @"code"
#define SP_VCS_JSON_KEY_ERROR_MESSAGE           @"message"

#define SP_VCS_RESPONSE_SIGNATURE_HEADER        @"X-Sponsorpay-Response-Signature"

@interface SPVirtualCurrencyServerConnection()
- (void)callDelegateWithError:(SPVirtualCurrencyRequestErrorType)error
                    errorCode:(NSString *)errorCode
                 errorMessage:(NSString *)errorMessage;
@property (retain) NSURLConnection *currentConnection;
@end

@implementation SPVirtualCurrencyServerConnection

@synthesize appId;
@synthesize userId;
@synthesize secretToken;
@synthesize responseSignature;
@synthesize delegate;
@synthesize shouldLogVerbosely;

- (NSString *)latestTransactionId
{
    return [SPPersistence latestVCSTransactionIdForUser:self.userId];
}

- (void)setLatestTransactionId:(NSString *)ltid
{
    [SPPersistence setLatestVCSTransactionId:ltid forUserId:self.userId];
}

- (id)initWithUserId:(NSString *)theUserId
             appId: (NSString *)theAppId
        secretToken:(NSString *)theSecretToken
{
    if (self = [super init]) {
        self.appId = theAppId;
        self.userId = theUserId;
        self.secretToken = theSecretToken;
    }
    return self;
}

- (NSURLConnection *)currentConnection
{
    return currentConnection;
}

- (void)setCurrentConnection:(NSURLConnection *)connection
{
    if (currentConnection) {
        [currentConnection cancel];
        [currentConnection release];
    }
    currentConnection = [connection retain];
}

- (void)fetchDeltaOfCoins
{
    NSString *resourceUrl = [SP_VCS_BASE_URL stringByAppendingString:SP_CURRENCY_DELTA_REQUEST_RESOURCE];
    
    SPUrlFactory *urlFactory = [SPUrlFactory urlFactoryWithDefaultParametersProvidersWithBaseUrl:resourceUrl
                                                                                sdkVersionValue:0
                                                                 shouldUseSystemDeviceIdentifier:[SPPersistence mayAccessSystemDeviceIdentifier]];
    
    [urlFactory addKey:URL_PARAM_KEY_APP_ID withValue:self.appId];
    [urlFactory addKey:URL_PARAM_KEY_USER_ID withValue:self.userId];
    [urlFactory addKey:URL_PARAM_KEY_LAST_TRANSACTION_ID
             withValue:self.latestTransactionId];
    
    NSNumber *timestamp = [NSNumber numberWithDouble:[[NSDate dateWithTimeIntervalSinceNow:0] timeIntervalSince1970] ];
    [urlFactory addKey:URL_PARAM_KEY_TIMESTAMP withIntegerValue:[timestamp integerValue]];

    [urlFactory addDeviceInfo];
    
    NSString *urlString = [urlFactory urlStringWithSignatureForSecretKey:self.secretToken];
    
    
    if (shouldLogVerbosely) NSLog(@"SponsorPay VCS request will be sent with url: %@", urlString);
    
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:urlString]
                                            cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData
                                        timeoutInterval:60.0];
    
    
    NSURLConnection *connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    
    if (connection) {
        if (responseData)
            [responseData release];
        responseData = [[NSMutableData data] retain];
        
        self.currentConnection = connection;
        
        if (shouldLogVerbosely) NSLog(@"Connection to SP VCS initialized");
    } else {
        NSLog(@"Connection to SP VCS initialization failed (%@)", connection);
        [self callDelegateWithError:ERROR_OTHER errorCode:nil errorMessage:nil];
    }
    
    [connection release];
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
	NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *) response;
    responseStatusCode = [httpResponse statusCode];
    NSDictionary *responseHeaders = [httpResponse allHeaderFields];
    self.responseSignature = [responseHeaders objectForKey:SP_VCS_RESPONSE_SIGNATURE_HEADER];
    
    if (shouldLogVerbosely) NSLog(@"Received response from SP VCS with status code: %d", responseStatusCode);
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    if (shouldLogVerbosely) NSLog(@"Connection to SP VCS did receive data");

    [responseData appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"Connection to SP VCS failed with error: %@", error);
    if ([error.domain isEqualToString:NSURLErrorDomain]) {
        [self callDelegateWithError:ERROR_NO_INTERNET_CONNECTION errorCode:nil errorMessage:nil];
    } else {
        [self callDelegateWithError:ERROR_OTHER errorCode:nil errorMessage:nil];
    }
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSString *body = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
    if (shouldLogVerbosely) NSLog(@"Connection to SP VCS finished loading. Body: %@", body);
   
    [responseData release];
    responseData = nil;
    
    SBJsonParser *parser = [[[SBJsonParser alloc] init] autorelease];
    id responseAsJson = [parser objectWithString:body];

    if (!responseAsJson) {
        NSLog(@"Parsing SP VCS response as JSONValue failed. Error is: %@", parser.error);
        [self callDelegateWithError:ERROR_OTHER errorCode:nil errorMessage:nil];
    }
    
    else if (![responseAsJson respondsToSelector:@selector(objectForKey:)]) {
        NSLog(@"Parsing SP VCS response as JSONValue failed. It doesn't look like a valid dictionary");
        [self callDelegateWithError:ERROR_INVALID_RESPONSE errorCode:nil errorMessage:nil];
    }
    
    else if (responseStatusCode == 200) {
        // Verify response signature
        if (![SPSignature isSignatureValid:self.responseSignature forText:body secretToken:self.secretToken]) {
            
            [self callDelegateWithError:ERROR_INVALID_RESPONSE_SIGNATURE errorCode:nil errorMessage:nil];
        
        } else {
            NSString *deltaOfCoins = [responseAsJson objectForKey:SP_VCS_JSON_KEY_DELTA_OF_COINS];
            NSString *returnedTransactionId = [responseAsJson objectForKey:SP_VCS_JSON_KEY_LATEST_TRANSACTION_ID];
            
            if (deltaOfCoins == nil || returnedTransactionId == nil) {
                NSLog(@"Parsing SP VCS response failed: missing expected keys.");
                [self callDelegateWithError:ERROR_INVALID_RESPONSE errorCode:nil errorMessage:nil];
            }
            
            else if (self.delegate
                     && [delegate respondsToSelector:@selector(virtualCurrencyConnector:didReceiveDeltaOfCoinsResponse:latestTransactionId:)]) {
                
                // Note that the latest transaction ID value gets updated only when delegate is registered and will be notified
                self.latestTransactionId = returnedTransactionId;
            
                NSNumberFormatter *nf = [[[NSNumberFormatter alloc] init] autorelease];
                [nf setLocale:[[[NSLocale alloc] initWithLocaleIdentifier:@"en_US"] autorelease]];
                nf.numberStyle = NSNumberFormatterDecimalStyle;
                
                [delegate virtualCurrencyConnector:self didReceiveDeltaOfCoinsResponse:[[nf numberFromString:deltaOfCoins] doubleValue]
                               latestTransactionId:returnedTransactionId];
            
            }
        }
    }
    
    else { // server returned error
        NSString *errorCode = [responseAsJson objectForKey:SP_VCS_JSON_KEY_ERROR_CODE];
        NSString *errorMessage = [responseAsJson objectForKey:SP_VCS_JSON_KEY_ERROR_MESSAGE];
        
        [self callDelegateWithError:SERVER_RETURNED_ERROR errorCode:errorCode errorMessage:errorMessage];
    }
    
    [body release];
}

- (void)callDelegateWithError:(SPVirtualCurrencyRequestErrorType)error
                    errorCode:(NSString *)errorCode
                 errorMessage:(NSString *)errorMessage
{
    if (self.delegate
        && [self.delegate respondsToSelector:@selector(virtualCurrencyConnector:failedWithError:errorCode:errorMessage:)]) {
        [delegate virtualCurrencyConnector:self failedWithError:error
                                 errorCode:errorCode
                              errorMessage:errorMessage];
    }
}


@end
