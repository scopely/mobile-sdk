//
//  SPSampleViewController.h
//  SponsorPay iOS Test App
//
//  Copyright 2011 SponsorPay. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SPInterstitialViewController.h"
#import "SPOfferWallViewController.h"
#import "SPVirtualCurrencyServerConnection.h"

#define DEFAULT_SECURITY_TOKEN  @"b6acfc0227c82edb41f118d638e3c1d4e9ce0189"

#define ENTERED_APPID_KEY                           @"ENTERED_APPID_KEY"
#define ENTERED_USERID_KEY                          @"ENTERED_USERID_KEY"
#define ENTERED_BACKGROUND_URL_KEY                  @"ENTERED_BACKGROUND_URL_KEY"
#define ENTERED_SKIN_NAME_KEY                       @"ENTERED_SKIN_NAME_KEY"
#define ENTERED_CLOSE_AFTER_CLICKING_ON_OFFER_KEY   @"ENTERED_CLOSE_AFTER_CLICKING_ON_OFFER_KEY"
#define ENTERED_SECURITY_TOKEN_KEY                  @"ENTERED_SECURITY_TOKEN_KEY"

@interface SPSampleViewController : UIViewController <UITextFieldDelegate,SPOfferWallViewControllerDelegate, SPInterstitialViewControllerDelegate,SPVirtualCurrencyConnectionDelegate> {
	
    UIScrollView *scrollView;
    UIView       *contentView;

	UITextField *appIdTextField;
	UITextField *userIdTextField;
	UITextField *backgroundUrlTextField;
    UITextField *skinNameTextField;
    UITextField *securityTokenTextField;
    
    UISwitch *closeAfterClickingOffer;

    
    UIButton *sendVCSDeltaRequestButton;
    
    SPOfferWallViewController *offerWallViewController;
	SPInterstitialViewController *interstitialViewController;
    SPVirtualCurrencyServerConnection *virtualCurrencyConnection;

    NSString *latestUsedVCSTransactionId;
}

- (void)interstitialViewController:(SPInterstitialViewController *)interstitialViewController
                   didChangeStatus:(SPInterstitialViewControllerStatus)status;

@property (retain) IBOutlet UIScrollView *scrollView;
@property (retain) IBOutlet UIView *contentView;
@property (retain) IBOutlet  UITextField *appIdTextField;
@property (retain) IBOutlet  UITextField *userIdTextField;
@property (retain) IBOutlet  UITextField *backgroundUrlTextField;
@property (retain) IBOutlet  UITextField *skinNameTextField;
@property (retain) IBOutlet  UITextField *securityTokenTextField;
@property (retain) IBOutlet  UISwitch *closeAfterClickingOffer;
@property (retain) IBOutlet UIButton *sendVCSDeltaRequestButton;

@property (retain) NSString *latestUsedVCSTransactionId;

- (IBAction)launchOfferWall:(id)sender;
- (IBAction)launchInterstitial:(id)sender;
- (IBAction)triggerAdvertiserCall:(id)sender;
- (IBAction)textFieldReturn:(id)sender;
- (IBAction)sendVCSDeltaRequest:(id)sender;

@end
