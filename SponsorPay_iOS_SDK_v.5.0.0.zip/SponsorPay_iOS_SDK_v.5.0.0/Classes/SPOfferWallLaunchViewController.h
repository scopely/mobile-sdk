//
//  SPOfferWallLaunchViewController.h
//  SponsorPay Sample App
//
//  Created by David Davila on 1/14/13.
//  Copyright (c) 2013 SponsorPay. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SPTestAppBaseViewController.h"

@interface SPOfferWallLaunchViewController : SPTestAppBaseViewController <SPOfferWallViewControllerDelegate>

@property (retain, nonatomic) IBOutlet UISwitch *closeOnFinishSwitch;
@property (retain, nonatomic) IBOutlet UIView *parametersGroup;
@property (retain, nonatomic) IBOutlet UIButton *launchOfferWallButton;

- (IBAction)launchOfferWall;
- (IBAction)showCustomParamsController;

@end
