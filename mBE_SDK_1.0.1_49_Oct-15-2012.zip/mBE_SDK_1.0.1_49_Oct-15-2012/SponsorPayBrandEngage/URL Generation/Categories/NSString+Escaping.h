//
//  NSString+Escaping.h
//  SponsorPay Mobile Brand Engage SDK
//
//

#import <Foundation/Foundation.h>

@interface NSString (Escaping)

- (NSString*)stringWithPercentEscape;
- (NSString*)stringWithPercentUnescape;

@end
