//
//  MBETestAppSettings.m
//  MBE TestApp
//
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import "MBETestAppSettings.h"

#define kSPAppAlreadyRanDefaultsKey         @"kSPAppAlreadyRanDefaultsKey"
#define kSPOverridenMBEURLDefaultsKey       @"kSPOverridenMBEURLDefaultsKey"


@interface MBETestAppSettings()

+ (BOOL)isFirstRunOnDevice;

@end

@implementation MBETestAppSettings

+ (BOOL)persistedBoolForKey:(NSString *)key
{
    return [[NSUserDefaults standardUserDefaults] boolForKey:key];
}

+ (void)persistBool:(BOOL)valueToPersist forKey:(NSString *)key
{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setBool:valueToPersist forKey:key];
    [userDefaults synchronize];
}

+ (NSInteger)persistedIntegerForKey:(NSString *)key
{
    return [[NSUserDefaults standardUserDefaults] integerForKey:key];
}

+ (void)persistInteger:(NSInteger)valueToPersist forKey:(NSString *)key
{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setInteger:valueToPersist forKey:key];
    [userDefaults synchronize];
}

+ (NSString *)overridenMBEURL
{
    return [[NSUserDefaults standardUserDefaults] stringForKey:kSPOverridenMBEURLDefaultsKey];
}

+ (void)setOverridenMBEURL:(NSString *)urlString
{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setObject:urlString forKey:kSPOverridenMBEURLDefaultsKey];
    [userDefaults synchronize];
}

+ (void)setDefaultsOnFirstRun
{
    if ([self isFirstRunOnDevice]) {
        [self setOverridenMBEURL:@""];
        [self persistBool:NO forKey:kSPVCSStagingDefaultsKey];
        [self persistBool:YES forKey:kSPShouldShowRewardNotificationDefaultsKey];
        [self persistBool:YES forKey:kSPShouldShowPayoffNotificationDefaultsKey];
        [self persistInteger:SPCurrencyRoundingModeRound
                      forKey:kSPPayoffNotificationCurrencyRoundingModeDefaultsKey];
        [self persistBool:NO forKey:kSPShouldSendUDIDDefaultsKey];
    }
}

+ (BOOL)isFirstRunOnDevice
{
    BOOL appAlreadyRan = [self persistedBoolForKey:kSPAppAlreadyRanDefaultsKey];
    
    BOOL isFirstRun = !appAlreadyRan;
    
    if (isFirstRun) {
        [self persistBool:YES forKey:kSPAppAlreadyRanDefaultsKey];
    }
    
    return isFirstRun;
}

@end
