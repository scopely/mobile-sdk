//
//  MBETestAppSettings.h
//  MBE TestApp
//
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import "SPBrandEngageClient.h"
#import "SPVirtualCurrencyServerConnector.h"
#import "MBETestAppSettings.h"

#define kSPMBEJSCoreURL_Staging             @"http://staging-iframe.sponsorpay.com/mbe"
#define kSPVCSBaseURL_Staging               @"https://staging-iframe.sponsorpay.com/vcs/v1/"

#define kSPShouldShowRewardNotificationDefaultsKey              @"kSPShouldShowRewardNotificationDefaultsKey"
#define kSPShouldShowPayoffNotificationDefaultsKey              @"kSPShouldShowPayoffNotificationDefaultsKey"
#define kSPPayoffNotificationCurrencyRoundingModeDefaultsKey    @"kSPPayoffNotificationCurrencyRoundingModeDefaultsKey"
#define kSPShouldSendUDIDDefaultsKey                            @"kSPShouldSendUDIDDefaultsKey"
#define kSPVCSStagingDefaultsKey                                @"kSPVCSStagingDefaultsKey"

#import <Foundation/Foundation.h>

@interface MBETestAppSettings : NSObject

+ (BOOL)persistedBoolForKey:(NSString *)key;
+ (void)persistBool:(BOOL)valueToPersist forKey:(NSString *)key;

+ (NSInteger)persistedIntegerForKey:(NSString *)key;
+ (void)persistInteger:(NSInteger)valueToPersist forKey:(NSString *)key;

+ (NSString *)overridenMBEURL;
+ (void)setOverridenMBEURL:(NSString *)urlString;

+ (void)setDefaultsOnFirstRun;

@end
