//
//  MBETestAppInfoSettingsViewController.h
//  MBE TestApp
//
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SPBrandEngageClient.h"
#import "SPVirtualCurrencyServerConnector.h"
#import "MBETestAppSettings.h"

typedef void (^SPSettingChangeHandler)(id newValue, NSDictionary *meta);

@interface MBETestAppInfoSettingsViewController : UIViewController

@property (retain, nonatomic) IBOutlet UITextField *baseURLTextField;
@property (retain, nonatomic) IBOutlet UISwitch *VCSStagingSwitch;
@property (retain, nonatomic) IBOutlet UISwitch *showRewardNotificationSwitch;
@property (retain, nonatomic) IBOutlet UISwitch *showPayoffNotificationSwitch;
@property (retain, nonatomic) IBOutlet UISwitch *sendUDIDSwitch;
@property (retain, nonatomic) IBOutlet UISegmentedControl *currencyRoundingModeSegmentedControl;

@property BOOL VCSStagingState;
@property (copy) SPSettingChangeHandler VCSStagingChangeHandler;

@property (retain, nonatomic) NSString *baseURLState;
@property (copy) SPSettingChangeHandler baseURLChangeHandler;

@property BOOL showRewardNotificationState;
@property (copy) SPSettingChangeHandler showRewardNotificationChangeHandler;

@property BOOL showPayoffCoinsNotificationState;
@property (copy) SPSettingChangeHandler showPayoffNotificationChangeHandler;

@property BOOL sendUDIDState;
@property (copy) SPSettingChangeHandler sendUDIDChangeHandler;

@property SPCurrencyRoundingMode payoffNotificationCurrencyRoundingModeState;
@property (copy) SPSettingChangeHandler payoffNotificationRoundingModeChangeHandler;

@property (retain, nonatomic) IBOutlet UINavigationBar *navigationBar;
@property (retain, nonatomic) IBOutlet UILabel *baseURLLabel;
@property (retain, nonatomic) IBOutlet UILabel *VCSStagingLabel;
@property (retain, nonatomic) IBOutlet UILabel *rewardNotificationLabel;
@property (retain, nonatomic) IBOutlet UILabel *payoffNotificationLabel;
@property (retain, nonatomic) IBOutlet UILabel *sendUDIDLabel;
@property (retain, nonatomic) IBOutlet UILabel *roundingModeLabel;

- (IBAction)baseURLTextFieldEditingDidEnd:(id)sender;
- (IBAction)setStagingURLbuttonTapped:(id)sender;
- (IBAction)VCSStagingValueChanged:(UISwitch *)sender;
- (IBAction)showRewardNotificationSwitchValueChanged:(UISwitch *)sender;
- (IBAction)showPayoffNotificationValueChanged:(UISwitch *)sender;
- (IBAction)sendUDIDValueChanged:(UISwitch *)sender;
- (IBAction)currencyRoundingModeSegmentedControlValueChanged:(UISegmentedControl *)sender;

- (IBAction)doneButtonTapped:(id)sender;

- (IBAction)textFieldDidEndOnExit:(id)sender;
@end
