# SponsorPay's Unity Plugin for Android #

The SponsorPay Unity plugin for Android lets you access from your Unity application features provided by the SponsorPay SDK  such as:

* Sending the Advertiser Callback right away or with a customized delay
* Launching the OfferWall
* Launching the Interstitial
* Communicating with the VCS to get the Delta of Coins
* Requesting and showing an Offer Banner
* Launching the Unlock OfferWall
* Obtaining the status of your Unlock Items

## PLUGIN SETUP ##

Follow these steps to integrate SponsorPay into your Unity Android project:

### If you don't have your own Android Manifest ###

1. Import the provided `SponsorPayUnityAndroidPlugin.unitypackage` assets package into your project by clicking on `Assets` > `Import Package` > `Custom Package…` from the Unity Editor.
2. Add the  provided game object `SponsorPayGameObject` to your scene (you can find it at `Plugins/Android/SponsorPayGameObject`).
3. You're done! Look at the provided test script for a demonstration on how to use the different features. You can also add it to a game object to see it in action.

### If you have your own Android Manifest ###

1. Import the provided `SponsorPayUnityAndroidPlugin.unitypackage` assets package into your project by clicking on `Assets` > `Import Package` > `Custom Package…` from the Unity Editor, but uncheck the `Plugins/Android/AndroidManifest.xml` file before hitting the "Import" button.
2. If you want to use the OfferWall or the Interstitial features add the corresponding activities to your manifest (inside the `application` element):

       <!-- SponsorPay OfferWall Activity -->
        <activity android:name="com.sponsorpay.sdk.android.publisher.OfferWallActivity"
                  android:configChanges="fontScale|keyboard|keyboardHidden|locale|mnc|mcc|navigation|orientation|screenLayout|screenSize|smallestScreenSize|uiMode|touchscreen"
                  android:screenOrientation="sensor" />
        <!-- SponsorPay Interstitial Activity -->
        <activity android:name="com.sponsorpay.sdk.android.publisher.InterstitialActivity"
                  android:configChanges="fontScale|keyboard|keyboardHidden|locale|mnc|mcc|navigation|orientation|screenLayout|screenSize|smallestScreenSize|uiMode|touchscreen"
                  android:screenOrientation="sensor"
                  android:theme="@android:style/Theme.Dialog" />                


3. Make sure your manifest contains the following permissions

		<uses-permission android:name="android.permission.INTERNET" />
		<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
		<uses-permission android:name="android.permission.READ_PHONE_STATE" />
		<uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />

4. Add the  provided game object `SponsorPayGameObject` to your scene (you can find it at `Plugins/Android/SponsorPayGameObject`).
5. You're done! Look at the provided test script for a demonstration on how to use the different features. You can also add it to a game object to see it in action.


## USING THE PLUGIN ##

An example script which uses each of the SDK features is provided in the sample project as `Assets/SponsorPaySDKDemo.cs`.

It demonstrates how to send the advertiser callback, launch the SponsorPay OfferWall and the Interstitial, request and show an Offer Banner and request the delta of coins as well as the status of the Unlock Items, and how to get responses back from the SDK.

It also includes code to draw a test UI which triggers calls to the SDK and displays its responses.


