/**
 * SponsorPay Android SDK
 *
 * Copyright 2011 - 2013 SponsorPay. All rights reserved.
 */

package com.sponsorpay.sdk.android.publisher.mbe.mediation;

public enum SPTPNVideoEvent {

    SPTPNVideoEventStarted("started"),
    SPTPNVideoEventAborted("aborted"),
    SPTPNVideoEventFinished("finished"),
    SPTPNVideoEventClosed("closed"),
    SPTPNVideoEventNoVideo("no_video"),
    SPTPNVideoEventTimeout("timeout"),
    SPTPNVideoEventError("error");

    private final String text;
	
	private SPTPNVideoEvent(final String text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return text;
    }

}
