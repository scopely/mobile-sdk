//
//  SponsorPayPublisher.h
//  SponsorPaySDKNativeiOS
//
//  Created by David on 8/1/12.
//  Copyright 2012 SponsorPay GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SPOfferWallViewController.h"
#import "SPVirtualCurrencyServerConnector.h"

#import "s3eEdk_iphone.h"

@interface SponsorPayPublisher : NSObject <SPOfferWallViewControllerDelegate, SPVirtualCurrencyConnectionDelegate>{
	@private
	SPOfferWallViewController *offerWallViewController;
    SPVirtualCurrencyServerConnector *vcsConnection;
}

@property (retain) SPVirtualCurrencyServerConnector *vcsConnection;

- (void) launchOfferWall:(NSString *)userId 
		  shouldStayOpen:(BOOL) shouldStayOpen
			   withAppId:(NSString *)appId;

- (void)requestNewCoins:(NSString *)userId 
			  withAppId:(NSString *)appId 
	   andSecurityToken:(NSString *)securityToken 
   sinceLastTransaction:(NSString *)lastTransactionID;

@end
