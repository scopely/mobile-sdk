//
//  SponsorPayPublisher.m
//  SponsorPaySDKNativeiOS
//
//  Created by David on 8/1/12.
//  Copyright 2012 SponsorPay GmbH. All rights reserved.
//

#import "SponsorPayPublisher.h"

#include "s3eEdk.h"
#include "s3eEdk_iphone.h"

#include "SponsorPayExtension_internal.h"

@interface SponsorPayPublisher ()

@property (retain) SPOfferWallViewController* offerWallViewController;

@end


@implementation SponsorPayPublisher

#pragma mark - Properties implementation

@synthesize offerWallViewController;
@synthesize vcsConnection;


#pragma mark - Utils

char* copyCString(NSString* original)
{
	if (original) {
		const char* pStr = [original UTF8String];
		char* pCopy = (char*) s3eEdkMallocOS(strlen(pStr) + 1);
		if (pCopy)
		{
			strcpy(pCopy, pStr);
			return pCopy;
		}
	}
	return NULL;
}


#pragma mark - Offer Wall

- (void) launchOfferWall:(NSString *)userId 
		  shouldStayOpen:(BOOL) shouldStayOpen
			   withAppId:(NSString *)appId	
{

	
	if (self.offerWallViewController) {
        [self.offerWallViewController.view removeFromSuperview];
		self.offerWallViewController = nil;
    }

	self.offerWallViewController = [[SPOfferWallViewController alloc] initWithUserId:userId
																		  appId:appId];
	[self.offerWallViewController release];
	
	self.offerWallViewController.delegate = self;
    
	self.offerWallViewController.shouldFinishOnRedirect = shouldStayOpen;
    
    
    UIView *s3eView = s3eEdkGetUIView();
    [s3eView addSubview:self.offerWallViewController.view];

     
}

- (void)offerWallViewController:(SPOfferWallViewController *)offerwallVC 
		   isFinishedWithStatus:(int) status
{
	if (self.offerWallViewController)
	{
		[self.offerWallViewController.view removeFromSuperview];
		self.offerWallViewController = nil;
	}
}

#pragma mark - VCS

- (void)requestNewCoins:(NSString *)userId 
			  withAppId:(NSString *)appId 
	   andSecurityToken:(NSString *)securityToken 
   sinceLastTransaction:(NSString *)lastTransactionID
{
	
    if (!self.vcsConnection) {
        self.vcsConnection =
        [[SPVirtualCurrencyServerConnector alloc] initWithUserId:userId
                                                     appId:appId
                                               secretToken:securityToken];
		
		[self.vcsConnection release];
		
        self.vcsConnection.shouldLogVerbosely = YES;
        self.vcsConnection.delegate = self;
    } else {
        self.vcsConnection.userId = userId;
        self.vcsConnection.appId = appId;
        self.vcsConnection.secretToken = securityToken;
    }
    
    [self.vcsConnection fetchDeltaOfCoins];
    
}

- (void)virtualCurrencyConnector:(SPVirtualCurrencyServerConnector *)vcConnector
  didReceiveDeltaOfCoinsResponse:(double)deltaOfCoins
             latestTransactionId:(NSString *)transactionId
{
    
    SP_DeltaOfCoinsResponse deltaOfCoinsResponse;
    deltaOfCoinsResponse.deltaOfCoins = deltaOfCoins;
    deltaOfCoinsResponse.latestTransactionId = copyCString(transactionId);
    
    s3eEdkCallbacksEnqueue(S3E_EXT_SPONSORPAYEXTENSION_HASH,
                           SPONSORPAYEXTENSION_CALLBACK_CURRENCY_REQUEST_SUCCESS,
                           &deltaOfCoinsResponse,
                           sizeof(SP_DeltaOfCoinsResponse),
                           NULL,
                           S3E_FALSE
                           );
    
 }


+(RequestErrorType)getErrorType:(SPVirtualCurrencyRequestErrorType)error
{
    RequestErrorType errorType;
    switch (error) {
        case NO_ERROR:
            errorType = SP_NO_ERROR;
            break;
        case ERROR_NO_INTERNET_CONNECTION:
            errorType = SP_ERROR_NO_INTERNET_CONNECTION;
            break;
        case ERROR_INVALID_RESPONSE:
            errorType = SP_ERROR_INVALID_RESPONSE;
            break;
        case ERROR_INVALID_RESPONSE_SIGNATURE:
            errorType = SP_ERROR_INVALID_RESPONSE_SIGNATURE;
            break;
        case SERVER_RETURNED_ERROR:
            errorType = SP_SERVER_RETURNED_ERROR;
            break;
        case ERROR_OTHER:
        default:
            errorType = SP_ERROR_OTHER;
            break;
    }
    return errorType;
}
     
     
- (void)virtualCurrencyConnector:(SPVirtualCurrencyServerConnector *)vcConnector
                 failedWithError:(SPVirtualCurrencyRequestErrorType)error
                       errorCode:(NSString *)errorCode
                    errorMessage:(NSString *)errorMessage
{
    SP_ErrorResponse errorResponse;
    errorResponse.errorType = [SponsorPayPublisher getErrorType:error];
    //NSLog(@"error type = %@", error);
    NSLog(@"error code = %s", errorCode);
    errorResponse.errorCode = copyCString(errorCode);
    errorResponse.errorMessage = copyCString(errorMessage);
    
    s3eResult res = s3eEdkCallbacksEnqueue(S3E_EXT_SPONSORPAYEXTENSION_HASH,
                           SPONSORPAYEXTENSION_CALLBACK_CURRENCY_REQUEST_ERROR,
                           &errorResponse,
                           sizeof(errorResponse),
                           NULL,
                           S3E_FALSE
                           );

}

#pragma mark - Memory management

-(void) dealloc
{
	[self.offerWallViewController release];
	[super dealloc];
}

@end
