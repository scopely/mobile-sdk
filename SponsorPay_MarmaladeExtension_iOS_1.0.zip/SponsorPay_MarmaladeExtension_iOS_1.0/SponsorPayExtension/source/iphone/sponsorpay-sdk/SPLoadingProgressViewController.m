//
//  LoadingProgressViewController.m
//  SponsorPaySample
//
//  Created by David Davila on 10/12/11.
//  Copyright (c) 2011 SponsorPay. All rights reserved.
//

#import "SPLoadingProgressViewController.h"

@implementation SPLoadingProgressViewController

@end
