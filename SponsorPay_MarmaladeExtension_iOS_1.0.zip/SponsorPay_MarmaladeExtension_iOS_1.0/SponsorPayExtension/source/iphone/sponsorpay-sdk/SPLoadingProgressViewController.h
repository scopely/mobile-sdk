//
//  LoadingProgressViewController.h
//  SponsorPaySample
//
//  Created by David Davila on 10/12/11.
//  Copyright (c) 2011 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#define INITIAL_ALPHA_FOR_LOADING_VIEW (0.0)
#define FINAL_ALPHA_FOR_LOADING_VIEW (0.95)

#define INTRO_ANIMATION_LENGTH_FOR_LOADING_VIEW (0.5)
#define OUTRO_ANIMATION_LENGTH_FOR_LOADING_VIEW (0.5)

#define LOADING_VIEW_OUTRO_ANIMATION_ID @"LOADING_VIEW_OUTRO_ANIMATION_ID"



@interface SPLoadingProgressViewController : UIViewController
@end
