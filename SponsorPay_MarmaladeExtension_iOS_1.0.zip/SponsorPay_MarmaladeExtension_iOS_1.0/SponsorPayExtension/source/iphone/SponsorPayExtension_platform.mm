/*
 * iphone-specific implementation of the SponsorPayExtension extension.
 * Add any platform-specific functionality here.
 */
/*
 * NOTE: This file was originally written by the extension builder, but will not
 * be overwritten (unless --force is specified) and is intended to be modified.
 */
#include "SponsorPayExtension_internal.h" 

#import "SponsorPayAdvertiser.h"
#import "SponsorPayPublisher.h"

#include "s3eEdk.h"
#include "s3eEdk_iphone.h"

SponsorPayAdvertiser* advertiser = nil;
SponsorPayPublisher* publisher = nil;

s3eResult SponsorPayExtensionInit_platform()
{
    // Add any platform-specific initialisation code here
    return S3E_RESULT_SUCCESS;
}

void SponsorPayExtensionTerminate_platform()
{
    // Add any platform-specific termination code here
    if(advertiser) [advertiser release];
	advertiser = nil;
	
	if(publisher) [publisher release];
	publisher = nil;
}

s3eResult SP_SendAdvertiserCallbackNow_platform(const char* appId)
{
    @try {
        
        NSString *overridenAppID = [NSString stringWithUTF8String:appId];
        
        if(!advertiser) advertiser = [[SponsorPayAdvertiser alloc] init];
        [advertiser sendAdvertiserCallback:overridenAppID];
    }
    @catch (NSException *exception) {
        
		NSLog(@"SponsorPay SDK Exception: %s", [exception.reason UTF8String] );
        
        s3eResult res = s3eEdkCallbacksEnqueue(S3E_EXT_SPONSORPAYEXTENSION_HASH,
                                               SPONSORPAYEXTENSION_CALLBACK_REQUEST_ERROR,
                                               &exception,
                                               sizeof(exception),
                                               NULL,
                                               S3E_FALSE);
        
        return res;
    }
    return S3E_RESULT_SUCCESS;
}

s3eResult SP_LaunchOfferWall_platform(const char* appId, const char* userId)
{
      
	if(!publisher) publisher = [[SponsorPayPublisher alloc] init];
	
	[publisher launchOfferWall:[NSString stringWithUTF8String:userId]
                shouldStayOpen:YES
                     withAppId:[NSString stringWithUTF8String:appId]];

    
    return S3E_RESULT_SUCCESS;
}

s3eResult SP_LaunchInterstitial_platform(const char* appId, const char* userId)
{
    return S3E_RESULT_ERROR;
}

s3eResult SP_RequestNewCoins_platform(const char* appId, const char* userId, const char* securityToken)
{
    if(!publisher) publisher = [[SponsorPayPublisher alloc] init];
	
	[publisher requestNewCoins:[NSString stringWithUTF8String:userId]
					 withAppId:[NSString stringWithUTF8String:appId]
			  andSecurityToken:[NSString stringWithUTF8String:securityToken]
		  sinceLastTransaction:nil];
    
    return S3E_RESULT_SUCCESS;
}
