//
//  SPPersistence.m
//  SponsorPaySample
//
//  Created by David Davila on 9/28/11.
//  Copyright (c) 2011 SponsorPay. All rights reserved.
//

#import "SPPersistence.h"

#define SP_ADVERTISER_CALLBACK_SUCCESS_KEY                        @"SPDidAdvertiserCallbackSucceed"
#define SP_VCS_LATEST_TRANSACTION_IDS_BY_USER_KEY                 @"SPVCSLatestTransactionIdsByUser"
#define SP_MAY_ACCESS_SYSTEM_DEVICE_IDENTIFIER_KEY                @"SPMayAccessSystemDeviceIdentifier"
#define SP_USER_DID_ANSWER_ABOUT_PERMISSION_FOR_SYSTEM_UDID       @"SPUserDidAnswerAboutPermissionForSystemDeviceIdentifier"

#define SP_VCS_LATEST_TRANSACTION_ID_VALUE_NO_TRANSACTION         @"NO_TRANSACTION"

#define SP_VCS_LATEST_TRANSACTION_DEFAULT_VALUE                   SP_VCS_LATEST_TRANSACTION_VALUE_NO_TRANSACTION

@implementation SPPersistence

+ (BOOL)didAdvertiserCallbackSucceed
{
    return [[NSUserDefaults standardUserDefaults] boolForKey:SP_ADVERTISER_CALLBACK_SUCCESS_KEY]; 
}

+ (void)setDidAdvertiserCallbackSucceed:(BOOL)successValue
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setBool:successValue forKey:SP_ADVERTISER_CALLBACK_SUCCESS_KEY];
    [defaults synchronize];
}

+ (BOOL)userDidAnswerAboutPermissionForSystemDeviceIdentifier
{
    return [[NSUserDefaults standardUserDefaults] boolForKey:SP_USER_DID_ANSWER_ABOUT_PERMISSION_FOR_SYSTEM_UDID];
}

+ (BOOL)mayAccessSystemDeviceIdentifier
{
    return [[NSUserDefaults standardUserDefaults] boolForKey:SP_MAY_ACCESS_SYSTEM_DEVICE_IDENTIFIER_KEY];
}

+ (void)setMayAccessSystemDeviceIdentifier:(BOOL)permissionValue
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setBool:permissionValue forKey:SP_MAY_ACCESS_SYSTEM_DEVICE_IDENTIFIER_KEY];
    [defaults setBool:YES forKey:SP_USER_DID_ANSWER_ABOUT_PERMISSION_FOR_SYSTEM_UDID];
    [defaults synchronize];
}

+ (NSString *)latestVCSTransactionIdForUser:(NSString *)userId;
{
    NSDictionary *fetchedTransactionIdsByUser = [[NSUserDefaults standardUserDefaults] dictionaryForKey:SP_VCS_LATEST_TRANSACTION_IDS_BY_USER_KEY];
    NSString *latestTransactionIdForUser = [fetchedTransactionIdsByUser objectForKey:userId];
    
    return
    latestTransactionIdForUser ?
    latestTransactionIdForUser : SP_VCS_LATEST_TRANSACTION_ID_VALUE_NO_TRANSACTION;
}

+ (void)setLatestVCSTransactionId:(NSString *)idValue
                        forUserId:(NSString *)userId
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *fetchedTransactions = [defaults dictionaryForKey:SP_VCS_LATEST_TRANSACTION_IDS_BY_USER_KEY];
    
    NSMutableDictionary *editableTransactions = [NSMutableDictionary dictionaryWithCapacity:[fetchedTransactions count]];
    
    [editableTransactions addEntriesFromDictionary:fetchedTransactions];
    
    [editableTransactions setObject:idValue forKey:userId];
    
    [defaults setObject:editableTransactions forKey:SP_VCS_LATEST_TRANSACTION_IDS_BY_USER_KEY];
    [defaults synchronize];
}

@end
