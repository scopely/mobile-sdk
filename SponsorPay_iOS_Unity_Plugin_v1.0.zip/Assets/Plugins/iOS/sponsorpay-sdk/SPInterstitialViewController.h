//
//  SPInterstitialViewController.h
//  SponsorPay iOS SDK
//
//  Copyright 2011 SponsorPay. All rights reserved.
//


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "SPLoadingProgressViewController.h"

typedef enum {
    NOT_WAITING,
    WAITING_FOR_INITIAL_REQUEST_RESPONSE,
    WAITING_FOR_WEBVIEW_TO_LOAD_INITIAL_CONTENTS
} SPInterstitialRequestStatus;

typedef enum {
	AD_SHOWN,
	NO_INTERSTITIAL_AVAILABLE,
    ERROR_NETWORK,
    ERROR_TIMEOUT,
    CLOSED
} SPInterstitialViewControllerStatus;

@interface SPInterstitialViewController : UIViewController <UIWebViewDelegate>  {
	NSString *appId;
	NSString *userId;
    SPLoadingProgressViewController *loadingProgressView;
    UIWebView *interstitialWebView;
    
    NSString *skin;
    NSString *backgroundImageUrl;
	BOOL isRedirecting;
	id delegate;
	
	BOOL shouldFinishOnRedirect;
	    
    NSURLConnection *initialRequestConnection;
    NSMutableData *downloadedInterstitialData;
    NSHTTPURLResponse *urlResponse;
    
    SPInterstitialRequestStatus requestStatus;
}

/** The application ID to send to SponsorPay */
@property (nonatomic, retain) NSString *appId;

/** The userID to send to SponsorPay */
@property (nonatomic, retain) NSString *userId;

/** The requested skin for the interstitial */
@property (nonatomic, retain) NSString *skin;

/** Url of the desired background image */
@property (nonatomic, retain) NSString *backgroundImageUrl;

/** The delegate to make callbacks to.  Must conform to SPInterstitialViewControllerDelegate protocol */
@property (nonatomic, retain) id delegate;

/** Whether the interstitial should close after a redirect **/
@property BOOL shouldFinishOnRedirect;

- (id)initWithUserId:(NSString *)theUserId
               appId:(NSString *)theAppId;

/** Calls the designated initializer with the default loadingTimeOut value **/
- (id)initWithUserId:(NSString *)theUserId
               appId:(NSString *)theAppId
       backgroundUrl:(NSString *)theBackgroundUrl
                skin:(NSString *)theSkinName;

/** Designated initializer. Initializes the interstitial object, sends a request for the
 * interstitial ad while showing a loading progress indicator. If an interstitial is returned
 * from the SponsorPay's server, the loading progress indicator will be hidden and the ad will be
 * shown.
 **/
- (id)initWithUserId:(NSString *)theUserId
               appId:(NSString *)theAppId
       backgroundUrl:(NSString *)theBackgroundUrl
                skin:(NSString *)theSkinName
      loadingTimeout:(NSTimeInterval)loadingTimeOut;

/** Cancels the request for the interstitial or the load of the interstitial page.
 * Hides the loading progress indication. Returns true on request or loading cancelled.
 * Returns false and does nothing else is the interstitial has already been loaded.
 **/
- (BOOL)cancelInterstitialRequest;

+ (void)overrideBaseUrlWithUrl:(NSString *)newUrl;
+ (void)restoreBaseUrlToDefault;
@end

/**
 * Protocol for the delegate of the interstitial to receive callbacks.
 */
@protocol SPInterstitialViewControllerDelegate
@optional
/**
 * Delegates will receive this callback as the interstitial controller lifecycle evolves.
 * Status will be a value of SPInterstitialViewControllerFinishStatus.
 */
- (void)interstitialViewController:(SPInterstitialViewController *)interstitialViewController
			  didChangeStatus:(SPInterstitialViewControllerStatus)status;

@end
