#import "SponsorPayUnityPlugin.h"
#define DEBUG_LOG_ENABLED

extern BOOL unityDisabled;

static SponsorPayUnityPlugin *sharedPluginInstance;

@implementation SponsorPayUnityPlugin

#pragma mark - Properties implementation
@synthesize offerWallViewController = _offerWallViewController;
@synthesize interstitialViewController = _interstitialViewController;
@synthesize interstitialBackgroundUrl, interstitialSkinName;
@synthesize vcsConnection = _vcsConnection;
@synthesize lastReceivedDeltaOfCoins;

- (NSString *)lastReceivedTransactionId {
    if (self.vcsConnection) {
        return self.vcsConnection.latestTransactionId;
    }
    return nil;
}

@synthesize lastReceivedCoinsRequestErrorCode, lastReceivedCoinsRequestErrorMessage;
@synthesize callbackGameObjectName;

#pragma mark -

// Factory Method
+ (SponsorPayUnityPlugin*)sharedInstance {
    if (!sharedPluginInstance) {
        sharedPluginInstance = [[super allocWithZone:NULL] init];
    }
    return sharedPluginInstance;
}

- (id)init {
	if (self = [super init]) {
        ;
    }
	return self;
}

#pragma mark - Offer Wall

- (void)launchOfferWallWithAppAndUserIds: (NSArray *)appAndUserIds {
    if (appAndUserIds.count < 2) {
        return;
    }
    
    [self launchOfferWallWithAppId:[appAndUserIds objectAtIndex:0] userId:[appAndUserIds objectAtIndex:1]];
}

void UnityPause(bool pause);

- (void)launchOfferWallWithAppId:(NSString *)appId userId:(NSString *)userId {

    if (![NSThread isMainThread]) {
        @autoreleasepool {
#ifdef DEBUG_LOG_ENABLED
            NSLog(@"launchOfferWallWithAppId:userId: was called on an secondary thread. Sending execution to main thread.");
#endif
            [self performSelectorOnMainThread:@selector(launchOfferWallWithAppAndUserIds:)
                                   withObject:[NSArray arrayWithObjects:appId, userId, nil]
                                waitUntilDone:YES];
        }
    } else {
#ifdef DEBUG_LOG_ENABLED
        NSLog(@"launchOfferWallWithAppId:userId: was invoked on the main thread.");
#endif
        if (self.offerWallViewController) {
            [self.offerWallViewController.view removeFromSuperview];
            self.offerWallViewController = nil;
        }
        SPOfferWallViewController *offerWall = [[SPOfferWallViewController alloc] initWithUserId:userId
                                                                                            appId:appId];    
        offerWall.delegate = self;
        offerWall.shouldFinishOnRedirect = NO;
        
        self.offerWallViewController = offerWall;
                
        [[[UIApplication sharedApplication] keyWindow] addSubview:self.offerWallViewController.view];
        
        [offerWall release];
    }
}

- (void)offerWallViewController:(SPOfferWallViewController *)offerwallVC isFinishedWithStatus:(int) status {
#ifdef DEBUG_LOG_ENABLED
    NSLog(@"offerWallViewController:isFinishedWithStatus: was invoked");
#endif
    
    if (self.offerWallViewController) {
        [self.offerWallViewController.view removeFromSuperview];
        self.offerWallViewController = nil;
    }
}

#pragma mark - Interstitial

- (void)launchInterstitialWithAppAndUserIds: (NSArray *)appAndUserIds {
    if (appAndUserIds.count < 2) {
        return;
    }
    
    [self launchInterstitialWithAppId:[appAndUserIds objectAtIndex:0] userId:[appAndUserIds objectAtIndex:1]];
}

- (void)launchInterstitialWithAppId:(NSString *)appId userId:(NSString *)userId {
    if (![NSThread isMainThread]) {
        @autoreleasepool {
            [self performSelectorOnMainThread:@selector(launchInterstitialWithAppAndUserIds:)
                                   withObject:[NSArray arrayWithObjects:appId, userId, nil]
                                waitUntilDone:YES];
        }
    } else {
        if (self.interstitialViewController) {
            [self.interstitialViewController cancelInterstitialRequest];
            [self.interstitialViewController.view removeFromSuperview];
            self.interstitialViewController = nil;
        }
        SPInterstitialViewController *interstitial = [[SPInterstitialViewController alloc] initWithUserId:userId
                                                                                                   appId:appId
                                                                                           backgroundUrl:self.interstitialBackgroundUrl
                                                                                                    skin:self.interstitialSkinName];
        interstitial.delegate = self;
        interstitial.shouldFinishOnRedirect = YES;

        self.interstitialViewController = interstitial;
        
        [[[UIApplication sharedApplication] keyWindow] addSubview:self.interstitialViewController.view];
        
        [interstitial release];
    }
}

- (void)removeAndReleaseInterstitialViewController {
    if (self.interstitialViewController) {
        [self.interstitialViewController cancelInterstitialRequest];
        [self.interstitialViewController.view removeFromSuperview];
        self.interstitialViewController = nil;
    }
}

- (void)interstitialViewController:(SPInterstitialViewController *)theInterstitialViewController
                   didChangeStatus:(SPInterstitialViewControllerStatus)status {
    
    NSString *statusAsString;
    
    switch (status) {
        case AD_SHOWN:
            statusAsString = @"AD_SHOWN";
            break;
        case NO_INTERSTITIAL_AVAILABLE:
            statusAsString = @"NO_INTERSTITIAL_AVAILABLE";
            [self removeAndReleaseInterstitialViewController];
            break;
        case ERROR_NETWORK:
            statusAsString = @"ERROR_NETWORK";
            [self removeAndReleaseInterstitialViewController];
            break;
        case ERROR_TIMEOUT:
            statusAsString = @"ERROR_TIMEOUT";
            [self removeAndReleaseInterstitialViewController];
            break;
        case CLOSED:
            statusAsString = @"CLOSED";
            [self removeAndReleaseInterstitialViewController];
            break;
    }
    
    NSLog(@"SponsorPayUnityPlugin did receive InterstitialViewController callback with status %@", statusAsString);
}


#pragma mark - VCS requests

- (void)sendVCSDeltaRequestWithAppId:(NSString *)appId
                                  userId:(NSString *)userId
                             secretToken: (NSString *)secretToken
{
    if (!self.vcsConnection) {
        SPVirtualCurrencyServerConnection *vcsConnection =
        [[SPVirtualCurrencyServerConnection alloc] initWithUserId:userId
                                                            appId:appId
                                                      secretToken:secretToken];
        vcsConnection.shouldLogVerbosely = NO;
        vcsConnection.delegate = self;
        self.vcsConnection = vcsConnection;
        
        [vcsConnection release];
    } else {
        self.vcsConnection.userId = userId;
        self.vcsConnection.appId = appId;
        self.vcsConnection.secretToken = secretToken;
    }
    
    [self.vcsConnection fetchDeltaOfCoins];
}

- (void)sendMessage:(const char *)message toGameObjectMethod:(const char *)methodName
{
    if (self.callbackGameObjectName) {
        UnitySendMessage([self.callbackGameObjectName UTF8String], methodName, message);
    } else {
        NSLog(@"SponsorPayPlugin error! No callback game object name was specified.");
    }
}

- (void)virtualCurrencyConnector:(SPVirtualCurrencyServerConnection *)vcConnector
  didReceiveDeltaOfCoinsResponse:(double)deltaOfCoins
             latestTransactionId:(NSString *)transactionId
{
    self.lastReceivedDeltaOfCoins = deltaOfCoins;
    [self sendMessage:"Delta of coins successfully received" toGameObjectMethod:"onDeltaOfCoinsReceived"];
}

- (void)virtualCurrencyConnector:(SPVirtualCurrencyServerConnection *)vcConnector
                 failedWithError:(SPVirtualCurrencyRequestErrorType)error
                       errorCode:(NSString *)errorCode
                    errorMessage:(NSString *)errorMessage
{
    
    const char *errorType;
    
    switch (error) {
        case NO_ERROR:
            errorType = "NO_ERROR";
            break;
        case ERROR_NO_INTERNET_CONNECTION:
            errorType = "ERROR_NO_INTERNET_CONNECTION";
            break;
        case ERROR_INVALID_RESPONSE:
            errorType = "ERROR_INVALID_RESPONSE";
            break;
        case ERROR_INVALID_RESPONSE_SIGNATURE:
            errorType = "ERROR_INVALID_RESPONSE_SIGNATURE";
            break;
        case SERVER_RETURNED_ERROR:
            errorType = "SERVER_RETURNED_ERROR";
            break;
        case ERROR_OTHER:
            errorType = "ERROR_OTHER";
            break;
        default:
            break;
    }
    
    self.lastReceivedCoinsRequestErrorCode = errorCode;
    self.lastReceivedCoinsRequestErrorMessage = errorMessage;
    
    [self sendMessage:errorType toGameObjectMethod:"onDeltaOfCoinsRequestError"];
}


#pragma mark - Implementations of base methods to ensure singleton behaviour

+ (id)allocWithZone:(NSZone *)zone {
    return [[self sharedInstance] retain];
}

- (id)copyWithZone:(NSZone *)zone {
    return self;
}

- (id)retain {
    return self;
}

- (NSUInteger)retainCount {
    return NSUIntegerMax;  //denotes an object that cannot be released
}

- (oneway void)release {
    //do nothing
}

- (id)autorelease {
    return self;
}

@end

char *copyCString(const char *original) {
    if (!original) {
        return NULL;
    }
    
    char* copy = (char*)malloc(strlen(original) + 1);
	strcpy(copy, original);
    return copy;

}

void _SPReportOfferCompleted(const char* appId) {
    @autoreleasepool {
        [[SPAdvertiserManager sharedManager]
         reportOfferCompleted:[NSString stringWithCString:appId
                                                 encoding:NSUTF8StringEncoding]];
    }
}

void _SPLaunchOfferWall(const char* appId, const char* userId) {
    // NSString objects will be created and released explicitly because we cannot count on the existence
    // of an autorelease pool on the thread in which this method has been invoked
    
    NSString *appIdAsNSString = [[NSString alloc] initWithCString:appId encoding:NSUTF8StringEncoding];
    NSString *userIdAsNSString = [[NSString alloc] initWithCString:userId encoding:NSUTF8StringEncoding];

    [[SponsorPayUnityPlugin sharedInstance] launchOfferWallWithAppId:appIdAsNSString
                                                              userId:userIdAsNSString];
    
    [appIdAsNSString release];
    [userIdAsNSString release];
}

void _SPLaunchInterstitial(const char* appId, const char* userId) {
    NSString *appIdAsNSString = [[NSString alloc] initWithCString:appId encoding:NSUTF8StringEncoding];
    NSString *userIdAsNSString = [[NSString alloc] initWithCString:userId encoding:NSUTF8StringEncoding];
    
    [[SponsorPayUnityPlugin sharedInstance] launchInterstitialWithAppId:appIdAsNSString
                                                                 userId:userIdAsNSString];
    
    [appIdAsNSString release];
    [userIdAsNSString release];
}

void _SPSetCallbackGameObjectName(const char* name) {
    NSString *nameAsNSString = [[NSString alloc] initWithCString:name encoding:NSUTF8StringEncoding];
    
    [[SponsorPayUnityPlugin sharedInstance] setCallbackGameObjectName:nameAsNSString];
    
    [nameAsNSString release];
}

void _SPSendDeltaOfCoinsRequest(const char* appId, const char* userId, const char*secretToken) {
    @autoreleasepool {
        NSString *appIdAsNSString = [NSString stringWithCString:appId encoding:NSUTF8StringEncoding];
        NSString *userIdAsNSString = [NSString stringWithCString:userId encoding:NSUTF8StringEncoding];
        NSString *secretTokenAsNSString = [NSString stringWithCString:secretToken encoding:NSUTF8StringEncoding];
        
        [[SponsorPayUnityPlugin sharedInstance] sendVCSDeltaRequestWithAppId:appIdAsNSString
                                                                      userId:userIdAsNSString 
                                                                 secretToken:secretTokenAsNSString];
    }
}

double _SPGetLastReceivedDeltaOfCoins() {
    double deltaOfCoins;
    
    @autoreleasepool {
        deltaOfCoins = [[SponsorPayUnityPlugin sharedInstance] lastReceivedDeltaOfCoins];
    }
    
    return deltaOfCoins;
}

const char * _SPGetLastReceivedTransactionId() {
    const char *transactionId;
    
    @autoreleasepool {
        transactionId = [[[SponsorPayUnityPlugin sharedInstance] lastReceivedTransactionId] UTF8String];
    }
    
    return copyCString(transactionId);
}

const char * _SPGetLastReceivedCoinsRequestErrorCode() {
    const char *errorCode;
    
    @autoreleasepool {
        errorCode = [[[SponsorPayUnityPlugin sharedInstance] lastReceivedCoinsRequestErrorCode] UTF8String];
    }
    
    return copyCString(errorCode);
}

const char * _SPGetLastReceivedCoinsRequestErrorMessage() {
    const char *errorMessage;
    
    @autoreleasepool {
        errorMessage = [[[SponsorPayUnityPlugin sharedInstance] lastReceivedCoinsRequestErrorMessage] UTF8String];
    }
    
    
    return copyCString(errorMessage);
}