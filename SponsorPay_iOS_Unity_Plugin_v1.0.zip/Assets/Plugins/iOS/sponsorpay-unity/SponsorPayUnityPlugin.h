#import "../sponsorpay-sdk/SPAdvertiserManager.h"
#import "../sponsorpay-sdk/SPOfferWallViewController.h"
#import "../sponsorpay-sdk/SPInterstitialViewController.h"
#import "../sponsorpay-sdk/SPVirtualCurrencyServerConnection.h"

@interface SponsorPayUnityPlugin : NSObject <SPOfferWallViewControllerDelegate, SPInterstitialViewControllerDelegate, SPVirtualCurrencyConnectionDelegate> {

}
@property (retain) SPOfferWallViewController *offerWallViewController;
@property (retain) SPInterstitialViewController *interstitialViewController;
@property (retain) NSString *interstitialBackgroundUrl;
@property (retain) NSString *interstitialSkinName;
@property (retain) SPVirtualCurrencyServerConnection *vcsConnection;
@property double lastReceivedDeltaOfCoins;
@property (readonly) NSString *lastReceivedTransactionId;
@property (retain) NSString *lastReceivedCoinsRequestErrorCode;
@property (retain) NSString *lastReceivedCoinsRequestErrorMessage;
@property (retain) NSString *callbackGameObjectName;

- (void)launchOfferWallWithAppId:(NSString *)appId userId:(NSString *)userId;
- (void)launchInterstitialWithAppId:(NSString *)appId userId:(NSString *)userId;
- (void)sendVCSDeltaRequestWithAppId:(NSString *)appId
                              userId:(NSString *)userId
                         secretToken: (NSString *)secretToken;
@end

void _SPReportOfferCompleted(const char* appId);

void _SPLaunchOfferWall(const char* appId, const char* userId);

void _SPLaunchInterstitial(const char* appId, const char* userId);

void _SPSetCallbackGameObjectName(const char* name);

void _SPSendDeltaOfCoinsRequest(const char* appId, const char* userId, const char*secretToken); 

double _SPGetLastReceivedDeltaOfCoins();

const char * _SPGetLastReceivedTransactionId();

const char * _SPGetLastReceivedCoinsRequestErrorCode();

const char * _SPGetLastReceivedCoinsRequestErrorMessage();