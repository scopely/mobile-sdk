using UnityEngine;
using System;
using System.Collections;
using System.Runtime.InteropServices;

public class SP_TestScript : MonoBehaviour {

	string appId = "1246";
	string userId = "test_user_id_1";
	string securityToken = "12345678";

	// Use this for initialization
	void Start () {
		SponsorPayPlugin.setCallbackGameObjectName("GameObject");
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnGUI() {
		// This will draw the test GUI to show the buttons and fields
		// which let you test the SDK features
		drawTestUI();
	}

	// Test user interface drawing code starts here

	static readonly float HorizontalMargin = 8;
	static readonly float GuiRectWidth = 0.96f * (Screen.width - (2 * HorizontalMargin));
	static readonly float GuiLabelHeight = 25;
	static readonly float GuiTapTargetHeight = 45;
	static readonly float GuiRectSmallPadding = 0;
	static readonly float GuiRectBigPadding = 15;
	static readonly	float HorizontalPadding = 5;

	string coinsLabel = "";

	void drawTestUI() {
		float y = 5.0f; // Top margin
		float x = HorizontalMargin;

		GUI.Label(new Rect(x, y, GuiRectWidth, GuiLabelHeight),  "App ID:");
		y += GuiLabelHeight + GuiRectSmallPadding;

		appId = GUI.TextField(new Rect(x, y, GuiRectWidth, GuiTapTargetHeight), appId);
		y += GuiTapTargetHeight + GuiRectBigPadding;

		GUI.Label(new Rect(x, y, GuiRectWidth, GuiLabelHeight),  "User ID: ");
		y += GuiLabelHeight + GuiRectSmallPadding;

		userId = GUI.TextField(new Rect(x, y, GuiRectWidth, GuiTapTargetHeight), userId);
		y += GuiTapTargetHeight + GuiRectBigPadding;

		GUI.Label(new Rect(x, y, GuiRectWidth, GuiLabelHeight),  "Security Token: ");
		y += GuiLabelHeight + GuiRectSmallPadding;

		securityToken = GUI.TextField(new Rect(x, y, GuiRectWidth, GuiTapTargetHeight), securityToken);
		y += GuiTapTargetHeight + GuiRectBigPadding;

		if (GUI.Button(new Rect (x, y, GuiRectWidth, GuiTapTargetHeight), "Send advertiser callback now")) {
			SponsorPayPlugin.sendAdvertiserCallback(appId);
		}
		y += GuiTapTargetHeight + GuiRectBigPadding;

		float buttonWidth = (GuiRectWidth / 3.0f) - (HorizontalPadding);

		if (GUI.Button(new Rect (x, y, buttonWidth, GuiTapTargetHeight), "Launch OfferWall")) {
			SponsorPayPlugin.launchOfferWall(appId, userId);
		}
		x += buttonWidth + HorizontalPadding;

		if (GUI.Button(new Rect (x, y, buttonWidth, GuiTapTargetHeight), "Launch Interstitial")) {
			SponsorPayPlugin.launchInterstitial(appId, userId);
		}
		x += buttonWidth + HorizontalPadding;

		if (GUI.Button(new Rect (x, y, buttonWidth, GuiTapTargetHeight), "Get delta of coins")) {
			coinsLabel = "Waiting for response from VCS...";
			SponsorPayPlugin.sendDeltaOfCoinsRequest(appId, userId, securityToken);
		}
		x = HorizontalMargin;
		y += GuiTapTargetHeight + GuiRectSmallPadding;

		GUI.Label(new Rect(x, y, GuiRectWidth, GuiLabelHeight * 3),  coinsLabel);
		y += GuiLabelHeight * 3 + GuiRectBigPadding;
	}

	void onDeltaOfCoinsReceived(string message) {
		coinsLabel = String.Format("Delta of Coins: {0}. Transaction ID: {1}",
			SponsorPayPlugin.getLastReceivedDeltaOfCoins(), SponsorPayPlugin.getLastReceivedTransactionId());
	}

	void onDeltaOfCoinsRequestError(string errorType) {
		coinsLabel = String.Format("Delta of coins request failed: {0}\nerror code: {1}\nerror message: {2}",
			errorType, SponsorPayPlugin.getLastReceivedCoinsRequestErrorCode(),
			SponsorPayPlugin.getLastReceivedCoinsRequestErrorMessage());
	}
}
