using UnityEngine;
using System.Collections;
using System.Runtime.InteropServices;

public class SponsorPayPlugin : MonoBehaviour {

	[DllImport ("__Internal")]
	public static extern void _SPReportOfferCompleted(string appId);
	
	[DllImport ("__Internal")]
	public static extern void _SPLaunchOfferWall(string appId, string userId);

	[DllImport ("__Internal")]
	public static extern void _SPLaunchInterstitial(string appId, string userId);

	[DllImport ("__Internal")]
	public static extern void _SPSetCallbackGameObjectName(string name);

	[DllImport ("__Internal")]
	public static extern void _SPSendDeltaOfCoinsRequest(string appId, string userId, string secretToken); 

	[DllImport ("__Internal")]
	public static extern double _SPGetLastReceivedDeltaOfCoins();

	[DllImport ("__Internal")]
	public static extern string _SPGetLastReceivedTransactionId();

	[DllImport ("__Internal")]
	public static extern string _SPGetLastReceivedCoinsRequestErrorCode();

	[DllImport ("__Internal")]
	public static extern string _SPGetLastReceivedCoinsRequestErrorMessage();

	// Sends the advertiser callback for the specified application ID
	public static void sendAdvertiserCallback(string appId) {
		_SPReportOfferCompleted(appId);
	}

	// Launches the offer wall with the specified application and user IDs
	public static void launchOfferWall(string appId, string userId) {
		_SPLaunchOfferWall(appId, userId);
	}

	// Launches the interstitial with the specified application and user IDs
	public static void launchInterstitial(string appId, string userId) {
		_SPLaunchInterstitial(appId, userId);
	}

	// Sets the name of the Unity game object which will receive the answer
	// for the Delta Of Coins Request
	public static void setCallbackGameObjectName(string name) {
		_SPSetCallbackGameObjectName(name);
	}

	// Asks the server for the amount of coins the user has earned since the last time
	// the backend was queried. This is an asynchronous call, and the results will be delivered
	// to the game object you registered with setCallbackGameObjectName(string name). 
	// That object must implement the following methods:
	//
	// void onDeltaOfCoinsReceived(string message)
	// void onDeltaOfCoinsRequestError(string errorType)
	//
	// which will be called when the result of the request is available.
	public static void sendDeltaOfCoinsRequest(string appId, string userId, string securityToken) {
		_SPSendDeltaOfCoinsRequest(appId, userId, securityToken);
	}

	// Gets the latest amount of coins returned by the server as an answer
	// to the delta of coins request.
	public static double getLastReceivedDeltaOfCoins() {
		return _SPGetLastReceivedDeltaOfCoins();
	}

	// Gets the last transaction ID returned by the server as part of the latest answer
	// for the delta of coins request.
	public static string getLastReceivedTransactionId() {
		return _SPGetLastReceivedTransactionId();
	}

	// Returns the error code of the last triggered error.
	public static string getLastReceivedCoinsRequestErrorCode() {
		return _SPGetLastReceivedCoinsRequestErrorCode();
	}

	// Returns the error message of the last triggered error.
	public static string getLastReceivedCoinsRequestErrorMessage() {
		return _SPGetLastReceivedCoinsRequestErrorMessage();
	}
}
