The SponsorPay Unity plugin for iOS comes with a sample Unity project which can be set up and run to see a demonstration of how to use from your unity application some of the SponsorPay SDK's features, such as:

* Sending the Advertiser Callback
* Launching the OfferWall
* Launching the Interstitial
* Communicating with the VCS to get the Delta of Coins

Follow these steps to integrate SponsorPay into your Unity project for iOS:

** SDK SETUP **

1. Build your Unity project for the iOS platform:
	- Open your unity project, and on the Unity menu go to File > Build Settings...
	- Select iOS on the "Platform" column and click on "Build"
	- Unity will generate an XCode project, but first it will prompt you for the desired name for this project. Enter the name and click on "Save". Once the project is generated, open it with XCode.
	-  Now it's the time to add the native files of the SDK into the project: add the sponsorpay-sdk and sponsorpay-unity folders into the "Classes" folder of the XCode project, either by dragging them to XCode or by right clicking on the folder and choosing "Add files to...". You can find these folders in the Assets/Plugins/iOS folder of the provided sample Unity project.
	- Go to the Build Settings of your project and set "Enable Objective-C Exceptions" to "Yes".
	- Build the XCode project. If you followed this process with the provided demo Unity project, you can go ahead and run it on the device.

** USING THE SDK **

We provide a C# script called SponsorPayPlugin.cs as a convenience to interact with the plugin's native functions and methods. Refer to the file's comments over each method definition for the details on how to use them.

* Callbacks from the SponsorPay plugin to your code

Before you request the amount of coins that the user has earned through the VCS, which is an asynchronous operation, you need to specify the name of the Unity game object in your project which will receive the answer from the server. Use the following call for this purpose:

SponsorPayPlugin.setCallbackGameObjectName(string name);

This game object must have an attached script with the following methods: 

void onDeltaOfCoinsReceived(string message) {
	// Use SponsorPayPlugin.getLastReceivedDeltaOfCoins() to obtain the amount of coins
	// returned by the server
}

void onDeltaOfCoinsRequestError(string errorType) {
	// Use errorType, SponsorPayPlugin.getLastReceivedCoinsRequestErrorCode(),
	// and SponsorPayPlugin.getLastReceivedCoinsRequestErrorMessage()
	// to fetch more information about the error
}