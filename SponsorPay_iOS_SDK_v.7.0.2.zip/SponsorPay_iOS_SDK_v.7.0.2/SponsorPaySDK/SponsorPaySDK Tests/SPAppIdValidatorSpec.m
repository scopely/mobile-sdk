//
//  SPAppIdValidatorSpec.m
//  SponsorPaySDK
//
//  Created by Daniel Barden on 17/04/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import <Specta/Specta.h>
#define EXP_SHORTHAND
#import <Expecta/Expecta.h>

#import "SPAppIdValidator.h"

SpecBegin(SPAppIdValidator)

describe (@"SPAppIdValidator", ^{

    sharedExamplesFor(@"throw an exception", ^(NSDictionary *data) {
        it(@"should raise SPInvalidAppIdException", ^{
            expect(^{
                NSString *appId = data[@"appId"];
                [SPAppIdValidator validateOrThrow:appId];
            }).to.raise(SPInvalidAppIdException);
        });
    });

    it(@"should not throw exception when valid", ^{
        expect(^{
            [SPAppIdValidator validateOrThrow:@"valid appId"];
        }).toNot.raiseAny();
    });

    itShouldBehaveLike(@"throw an exception", @{@"appId": @"0"});
    itShouldBehaveLike(@"throw an exception", @{@"appId": @""});
    itShouldBehaveLike(@"throw an exception", @{});

});

SpecEnd
