//
//  NSDictionary_StringSerializationSpec.m
//  SponsorPaySDK
//
//  Created by Daniel Barden on 17/03/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import <Specta/Specta.h>
#define EXP_SHORTHAND
#import <Expecta/Expecta.h>

#import "NSDictionary+SPSerialization.h"

SpecBegin(NSDictionary_SPSerialization)

describe(@"StringSerialization", ^{
    it (@"should return a the entries serialized using defaults", ^{
        NSDictionary *testDict= @{@"foo": @"bar", @"fuu" : @"bar"};
        NSString *serializedString = [testDict SPComponentsJoined];
        NSString *expectedString = @"foo : 'bar', fuu : 'bar'";
        expect(serializedString).to.equal(expectedString);
    });
});

SpecEnd
