//
//  SPInterstitialEventSpec.m
//  SponsorPaySDK
//
//  Created by Daniel Barden on 27/10/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import <Specta/Specta.h>
#define EXP_SHORTHAND
#import <Expecta/Expecta.h>

#import "SPInterstitialEvent.h"

SpecBegin(SPInterstitialEvent)

describe(@"SPInterstitialEvent", ^{
    __block SPInterstitialEvent *sut;
    it(@"should serialize tracking params", ^{
        sut = [[SPInterstitialEvent alloc] initWithEventType:SPInterstitialEventTypeClick
                                                     network:@"fyber"
                                                        adId:@"232"
                                                   requestId:@"12344"
                                              trackingParams:@{@"dsp": @"DSP1",
                                                               @"x": @123}];
        NSDictionary *getParams = [sut dictionaryWithKeyValueParameters];
        expect(getParams[@"dsp"]).to.equal(@"DSP1");
        expect(getParams[@"x"]).to.equal(@123);
    });
});
SpecEnd
