//
//  main.m
//  sample2test
//
//  Created by David Davila on 4/6/11.
//  Copyright 2011-2013 SponsorPay. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    @autoreleasepool {
        int retVal = UIApplicationMain(argc, argv, nil, nil);
        return retVal;
    }
}
