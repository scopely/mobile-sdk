module(..., package.seeall)

local widget = require( "widget" )

local helper = require( "scripts.helper" )

local tableMap = helper.tableMap()

local yInc = 22

-- UI widgets creation 
function createButton( text, reference, parent, onReleaseListener )
  local btn = widget.newButton {
      top = reference.y + yInc,
      height = 35,
      label = text,
      width = display.contentWidth - 70,
      onRelease = onReleaseListener
    }
  btn.x = display.contentWidth * 0.5
  parent:insert( btn )

  helper.centerObject( btn )

  return btn
end

function createLabel( textContent, reference, parent )
  local label = display.newText( textContent, 20, reference.y + yInc, native.systemFont, 14 )
  label:setTextColor( 0 )  -- black
  label.anchorX = 0
  label.anchorY = 0
  -- label.x = 20
  -- label.y = reference.y + yInc
  parent:insert( label )
  return label
end


function createInputField( reference, parent, id )
  local field = native.newTextField( 30, 50 , display.contentWidth - 60, 36 )
  field.anchorX = 0
  field.isVisible = false
  field:addEventListener( "userInput", helper.onUserInput ) 
  
  local rect =  display.newRect( 30, reference.y + yInc + 10, display.contentWidth - 60, 24  )
  rect:setFillColor( 0.93, 0.93, 0.93 )
  rect.x = display.contentWidth * 0.5
  
  local label = display.newText( "", display.contentWidth * 0.5, rect.y, native.systemFont, 14 )
  label:setTextColor( 0 )  -- black
  
  tableMap[rect] = field
  tableMap[field] = label
  tableMap[id] = field
  
  parent:insert( rect )
  parent:insert( label )
  rect:addEventListener( "touch", helper.ontouch )

  helper.centerObject( label )
  helper.centerObject( rect )

  return rect
end

function createSwitch( text, reference, parent, onReleaseListener )
  local switch = widget.newSwitch {
    top = reference.y + yInc,
    height = 35,
    style = "checkbox",
    onRelease = onReleaseListener,
    initialSwitchState = true
  }
  
  switch.x = 40
  local label = display.newText( text, switch.x + 20, switch.y, native.systemFont, 12 )
  label.anchorX = 0
  label:setTextColor( 0 )	-- black
  
  parent:insert( switch )
  parent:insert( label )
  
  return switch
end
