-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- show default status bar (iOS)
display.setStatusBar( display.HiddenStatusBar )

local widget = require( "widget" )

local sponsorpay = require "plugin.sponsorpay"

local ui = require( "scripts.ui" )

local helper = require( "scripts.helper" )

local tableMap = helper.tableMap()

local queryVCSAfterMBE = true


local function onStartSDKButtonRelease( event )
  local appId = tableMap.appId.text
  local userId = tableMap.userId.text
  local securityToken = tableMap.securityToken.text
  sponsorpay.start( appId, userId, securityToken )
end

local function resultListener( event )
  native.showAlert( event.name, event.status, { "OK" } )
end

local function onLaunchOfwButtonRelease( event )
  local currencyName = tableMap.customCurrency.text
  sponsorpay.launchOfferWall( resultListener, currencyName )
end

local function vcsListener( event )
  local message = ""
  if event.success then
    message = "Delta of coins: " .. event.vcsTransaction.deltaOfCoins .. "\nLatest transaction: " .. event.vcsTransaction.latestTransactionId
  else
    message = "Error\nMessage: " .. event.error.message .. "\nType: " .. event.error.type .. "\nCode: " .. event.error.code
  end
  native.showAlert( event.name, message , { "OK" } )
end

local function onRequestVCSButtonRelease( event )
  local currencyName = tableMap.customCurrency.text
  sponsorpay.requestNewCoins( vcsListener, currencyName )
end

local function onReportOfferButtonRelease( event )
  local actionId = tableMap.actionId.text
  sponsorpay.reportActionCompletion( actionId )
end

local function onShouldShowVCSRewardNotificationCheck( event )
  sponsorpay.shouldShowVCSRewardNotification(event.target.isOn)
end

local function mbeListener( event )
  local message = ""
  if event.success then
    message = "Has offers? " .. tostring(event.mbe.hasOffers)
  else
    message = "Error\nMessage: " .. event.error.message .. "\nType: " .. event.error.type .. "\nCode: " .. event.error.code
  end
  native.showAlert( event.name, message , { "OK" } )
end

local function onRequestOffersButtonRelease( event )
  local currencyName = tableMap.customCurrency.text
  if queryVCSAfterMBE then
    sponsorpay.requestMBEOffers( mbeListener, currencyName, vcsListener )
  else
    sponsorpay.requestMBEOffers( mbeListener )
  end
end

local function onStartEngagementButtonRelease( event )
  sponsorpay.startMBEEngagement( resultListener )
end
                                   
local function onShouldShowMBERewardNotificationCheck( event )
  sponsorpay.setShowMBERewardNotification(event.target.isOn)
end                                
        
local function onQueryVCSAfterMBECheck( event )
  queryVCSAfterMBE = event.target.isOn
end            
                                     
local function onSDKError( event )    
  local message = event.error.message 
  native.showAlert( event.name, message , { "OK" } )
end
                                    
-- register the error event listener                                     
sponsorpay.errorEventHandler( onSDKError )


local function init() 
  sponsorpay.enableLogging( true )
  local size = display.contentHeight
  
  if display.contentWidth > display.contentHeight then
    size = display.contentWidth
  end

  local titleBg = display.newRect( 0, 0, size, 76 )
  titleBg.anchorX = 0
  titleBg.anchorY = 0
  titleBg:setFillColor( 0.8, 0.78, 0.78 )	-- gray


  local function scrollviewListener(event)
    helper.hideInputField()
  end
     
  local contentGroup = display.newGroup()

  local scrollViewPortrait = widget.newScrollView {
    top = titleBg.height,
    height = display.contentHeight - titleBg.height,
    width = display.contentWidth,
    listener = scrollviewListener
  }

  local scrollViewLandscape = widget.newScrollView {
    top = titleBg.height,
    height = display.contentWidth - titleBg.height,
    width = display.contentHeight,
    listener = scrollviewListener
  }

  scrollViewLandscape.isVisible = false

  -- rotation issue fix
  Runtime:addEventListener("orientation", 
    function(event)
      if event.type == "portrait" or event.type == "portraitUpsideDown" then
        if scrollViewLandscape.isVisible then
          scrollViewPortrait:insert ( contentGroup )
          scrollViewLandscape.isVisible = false
          scrollViewPortrait.isVisible = true
        end
      elseif event.type == "landscapeLeft" or event.type == "landscapeRight" then
        if scrollViewPortrait.isVisible then
          scrollViewLandscape:insert ( contentGroup )
          scrollViewPortrait.isVisible = false
          scrollViewLandscape.isVisible = true
        end  
      end
    end
  )

  local appIdLbl = ui.createLabel( "AppId", contentGroup, contentGroup )
  appIdLbl.y = 0
  local appId = ui.createInputField( appIdLbl, contentGroup, "appId" )
  
  local userIdLbl = ui.createLabel( "UserId", appId, contentGroup)
  local userId = ui.createInputField( userIdLbl, contentGroup, "userId" )
  
  local securityTokenLbl = ui.createLabel( "SecurityToken", userId, contentGroup )
  local securityToken = ui.createInputField( securityTokenLbl, contentGroup, "securityToken" )
  
  local startSDKBtn = ui.createButton( "Start SDK", securityToken, contentGroup, onStartSDKButtonRelease)
  
  local customCurrencyLbl = ui.createLabel( "Custom Currency", startSDKBtn, contentGroup )
  local customCurrency = ui.createInputField( customCurrencyLbl, contentGroup, "customCurrency" )
  
  local ofwBtn = ui.createButton( "Launch OfferWall", customCurrency, contentGroup, onLaunchOfwButtonRelease)

  local vcsBtn = ui.createButton( "Request new coins", ofwBtn, contentGroup, onRequestVCSButtonRelease )

  local showVCSToastSwitch = ui.createSwitch( "Show VCS notification?", vcsBtn, contentGroup, onShouldShowVCSRewardNotificationCheck)
  
  local actionIdLbl = ui.createLabel( "ActionId", showVCSToastSwitch, contentGroup )
  local actionId = ui.createInputField( actionIdLbl, contentGroup, "actionId" )

  local offerCompletionBtn = ui.createButton( "Report Offer Completion", actionId, contentGroup, onReportOfferButtonRelease )
  
  local mbeLbl = ui.createLabel( "Mobile BrandEngage", offerCompletionBtn, contentGroup )

  local requestOffersMBEBtn = ui.createButton( "Request Offers", mbeLbl, contentGroup, onRequestOffersButtonRelease )

  local startEngagementBtn = ui.createButton( "Start Engagement", requestOffersMBEBtn, contentGroup, onStartEngagementButtonRelease )

  local showMBERewardSwitch = ui.createSwitch( "Show MBE Reward notification?", startEngagementBtn, contentGroup, onShouldShowMBERewardNotificationCheck)
  
  local queryVCSAfterEngagementSwitch = ui.createSwitch( "Query VCS after engagement?", showMBERewardSwitch, contentGroup, onQueryVCSAfterMBECheck)

  titleBg:toFront()
	local title = display.newText( "SP Corona TestApp", display.contentWidth * 0.5, 20, native.systemFont, 24 )
	title:setTextColor( 0 )	-- black
  
  local version = display.newText ( "Version " .. sponsorpay.getPluginVersion(), display.contentWidth * 0.5, title.y + 30, native.systemFont, 16 )
	version:setTextColor( 0 )	-- black

  helper.centerObject( version )
  helper.centerObject( title )

  scrollViewPortrait:insert( contentGroup )
end

init()
