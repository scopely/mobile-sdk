-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- show default status bar (iOS)
display.setStatusBar( display.DefaultStatusBar )

local widget = require( "widget" )

local sponsorpay = require "plugin.sponsorpay"

local ui = require( "scripts.ui" )

local helper = require( "scripts.helper" )

local tableMap = helper.tableMap()

local queryVCSAfterMBE = true

local function onStartSDKButtonRelease( event )
  local appId = tableMap.appId.text
  local userId = tableMap.userId.text
  local securityToken = tableMap.securityToken.text
  sponsorpay.start( appId, userId, securityToken )
end

local function resultListener( event )
  native.showAlert( event.name, event.status, { "OK" } )
end

local function onLaunchOfwButtonRelease( event )
  local currencyName = tableMap.customCurrency.text
  sponsorpay.launchOfferWall( resultListener, currencyName )
end

local function vcsListener( event )
  local message = ""
  if event.success then
    message = "Delta of coins: " .. event.vcsTransaction.deltaOfCoins .. "\nLatest transaction: " .. event.vcsTransaction.latestTransactionId
  else
    message = "Error\nMessage: " .. event.error.message .. "\nType: " .. event.error.type .. "\nCode: " .. event.error.code
  end
  native.showAlert( event.name, message , { "OK" } )
end

local function onRequestVCSButtonRelease( event )
  local currencyName = tableMap.customCurrency.text
  sponsorpay.requestNewCoins( vcsListener, currencyName )
end

local function onReportOfferButtonRelease( event )
  local actionId = tableMap.actionId.text
  sponsorpay.reportActionCompletion( actionId )
end

local function onShouldShowVCSRewardNotificationCheck( event )
  sponsorpay.shouldShowVCSRewardNotification(event.target.isOn)
end

local function mbeListener( event )
  local message = ""
  if event.success then
    message = "Has offers? " .. tostring(event.mbe.hasOffers)
  else
    message = "Error\nMessage: " .. event.error.message .. "\nType: " .. event.error.type .. "\nCode: " .. event.error.code
  end
  native.showAlert( event.name, message , { "OK" } )
end

local function onRequestOffersButtonRelease( event )
  local currencyName = tableMap.customCurrency.text
  if queryVCSAfterMBE then
    sponsorpay.requestMBEOffers( mbeListener, currencyName, vcsListener )
  else
    sponsorpay.requestMBEOffers( mbeListener )
  end
end

local function onStartEngagementButtonRelease( event )
  sponsorpay.startMBEEngagement( resultListener )
end
                                   
local function onShouldShowMBERewardNotificationCheck( event )
  sponsorpay.setShowMBERewardNotification(event.target.isOn)
end                                
        
local function onQueryVCSAfterMBECheck( event )
  queryVCSAfterMBE = event.target.isOn
end            
                                     
local function onSDKError( event )    
  local message = event.error.message 
  native.showAlert( event.name, message , { "OK" } )
end
                                    
-- register the error event listener                                     
sponsorpay.errorEventHandler( onSDKError )

                             

local function init() 
	local titleBg = display.newRect( 0, 0, display.contentWidth, 76 )
	titleBg:setFillColor( 205, 201, 201 )	-- gray	


  local function scrollviewListener(event)
    helper.hideInputField()
  end
     
  local scrollView = widget.newScrollView {
    top = titleBg.contentHeight,
    height = display.contentHeight - titleBg.height,
    width = display.contentWidth,
    listener = scrollviewListener
}

  local appIdLbl = ui.createLabel( "AppId", scrollView, scrollView )
  appIdLbl.y = 0
  local appId = ui.createInputField( appIdLbl, scrollView, "appId" )
  
  local userIdLbl = ui.createLabel( "UserId", appId, scrollView)
  local userId = ui.createInputField( userIdLbl, scrollView, "userId" )
  
  local securityTokenLbl = ui.createLabel( "SecurityToken", userId, scrollView )
  local securityToken = ui.createInputField( securityTokenLbl, scrollView, "securityToken" )
  
  local startSDKBtn = ui.createButton( "Start SDK", securityToken, scrollView, onStartSDKButtonRelease)
  
  local customCurrencyLbl = ui.createLabel( "Custom Currency", startSDKBtn, scrollView )
  local customCurrency = ui.createInputField( customCurrencyLbl, scrollView, "customCurrency" )
  
  local ofwBtn = ui.createButton( "Launch OfferWall", customCurrency, scrollView, onLaunchOfwButtonRelease)

  local vcsBtn = ui.createButton( "Request new coins", ofwBtn, scrollView, onRequestVCSButtonRelease )

  local showVCSToastSwitch = ui.createSwitch( "Show VCS notification?", vcsBtn, scrollView, onShouldShowVCSRewardNotificationCheck)
  
  local actionIdLbl = ui.createLabel( "ActionId", showVCSToastSwitch, scrollView )
  local actionId = ui.createInputField( actionIdLbl, scrollView, "actionId" )

  local offerCompletionBtn = ui.createButton( "Report Offer Completion", actionId, scrollView, onReportOfferButtonRelease )
  
  local mbeLbl = ui.createLabel( "Mobile BrandEngage", offerCompletionBtn, scrollView )

  local requestOffersMBEBtn = ui.createButton( "Request Offers", mbeLbl, scrollView, onRequestOffersButtonRelease )

  local startEngagementBtn = ui.createButton( "Start Engagement", requestOffersMBEBtn, scrollView, onStartEngagementButtonRelease )

  local showMBERewardSwitch = ui.createSwitch( "Show MBE Reward notification?", startEngagementBtn, scrollView, onShouldShowMBERewardNotificationCheck)
  
  local queryVCSAfterEngagementSwitch = ui.createSwitch( "Query VCS after engagement?", showMBERewardSwitch, scrollView, onQueryVCSAfterMBECheck)

  titleBg:toFront()
	local title = display.newRetinaText( "SP Corona TestApp", 0, 0, native.systemFont, 24 )
	title:setTextColor( 0 )	-- black
	title:setReferencePoint( display.TopCenterReferencePoint )
	title.x = display.contentWidth * 0.5
	title.y = 20
  
  local version = display.newRetinaText ( "Version " .. sponsorpay.getPluginVersion(), 0, 0, native.systemFont, 16 )
	version:setTextColor( 0 )	-- black
	version:setReferencePoint( display.TopCenterReferencePoint )
	version.x = display.contentWidth * 0.5
	version.y = title.y + 30
end

init()
