module(..., package.seeall)

local widget = require( "widget" )

local helper = require( "scripts.helper" )

local tableMap = helper.tableMap()

local yInc = 22

-- UI widgets creation 
function createButton( text, reference, parent, onReleaseListener )
  local btn = widget.newButton {
      top = reference.y + yInc,
      height = 35,
      label = text,
      width = display.contentWidth - 70,
      onRelease = onReleaseListener
    }
  btn.x = display.contentWidth * 0.5
  parent:insert( btn )
  return btn
end

function createLabel( textContent, reference, parent )
  local label = display.newText( textContent, 0, 0, native.systemFont, 14 )
  label:setTextColor( 0 )  -- black
  label:setReferencePoint( display.TopLeftReferencePoint )
  label.x = 20
  label.y = reference.y + yInc
  parent:insert( label )
  return label
end


function createInputField( reference, parent, id )
  local field = native.newTextField( 30, 50 , display.contentWidth - 60, 36 )
  field.isVisible = false
  field:addEventListener( "userInput", helper.onUserInput ) 
  
  local rect =  display.newRect( 30, reference.y + yInc + 5, display.contentWidth - 60, 24  )
  rect:setFillColor( 238, 238, 238 )
  
  local label = display.newText( "", 0, 0, native.systemFont, 14 )
  label:setTextColor( 0 )  -- black
  label.x = display.contentWidth * 0.5
  label.y = rect.y
  
  tableMap[rect] = field
  tableMap[field] = label
  tableMap[id] = field
  
  parent:insert( rect )
  parent:insert( label )
  rect:addEventListener( "touch", helper.ontouch )
  
  return rect
end

function createSwitch( text, reference, parent, onReleaseListener )
  local switch = widget.newSwitch {
    top = reference.y + yInc,
    height = 35,
    style = "checkbox",
    onRelease = onReleaseListener,
    initialSwitchState = true
  }
  
  switch.x = 40
  local label = display.newText( text, switch.x + 20, 0, native.systemFont, 12 )
  label:setTextColor( 0 )	-- black
  label.y = switch.y
  parent:insert( switch )
  parent:insert( label )
  
  return switch
end
