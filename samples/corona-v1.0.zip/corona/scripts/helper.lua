module(..., package.seeall)

local map = {}

function tableMap()
  return map
end

local inputField = nil

-- Listeners
function onUserInput( event )
  if event.phase == "ended" or event.phase == "submitted"  then
    native.setKeyboardFocus( nil )
    hideInputField()
  end
end

function ontouch(event)
  if event.phase == "ended" then
    showInputField( map[event.target] )
  end
  return true
end

-- Helper methods
function hideInputField()
  if inputField ~= nil then
    inputField.isVisible = false
    map[inputField].text = inputField.text
  end
end

function showInputField( newInputField )
  hideInputField()
  inputField = newInputField
  inputField.isVisible = true
  native.setKeyboardFocus(inputField)
end