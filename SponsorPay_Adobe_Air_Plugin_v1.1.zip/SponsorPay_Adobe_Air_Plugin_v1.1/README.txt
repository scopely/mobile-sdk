SponsorPaySDKLibrary is a native extension for use with Adobe AIR.
It provides the following features from the native SDK:
- Offerwall
- Unlock Offerwall
- Virtual Currency Server
- Advertiser Callback


Requirements:
=============

Adobe Flash Builder 4.6 IDE


Getting Started:
================

1) Download the latest SponsorPaySDKLibrary.ane

2) On your Flex project, click on "Properties"

3) Go to "Flex Build Path" and "Native Extensions" tab 

4) Click on "Add ANE..." and browse to the download location of the SponsorPaySDKLibrary.ane file, select and click "Finish".

5) Check that the Native extension is exported when you package your application. On the project's properties, select "Flex Build Packaging" and "Google Android" and /or "iOS". On the "Native Extensions" tab, SponsorPaySDKLibrary should be present and check "Package". Click "OK".


Note:
-----
For more information on how to use the plugin, you can refer to the SponsorPay Adobe AIR test application.
