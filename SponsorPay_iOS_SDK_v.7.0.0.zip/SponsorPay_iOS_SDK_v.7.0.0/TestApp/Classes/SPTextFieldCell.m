//
//  SPTextFieldCell.m
//  SponsorPayTestApp
//
//  Created by Piotr  on 21/07/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import "SPTextFieldCell.h"

@implementation SPTextFieldCell

@end
