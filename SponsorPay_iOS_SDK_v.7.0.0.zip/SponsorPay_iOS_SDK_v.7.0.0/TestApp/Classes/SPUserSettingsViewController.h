//
//  SPUserSettingsViewController.h
//  SponsorPayTestApp
//
//  Created by Piotr  on 21/07/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import "SPTestAppBaseViewController.h"
#import "SPSwitchCell.h"
#import <CoreLocation/CoreLocation.h>

@interface SPUserSettingsViewController : SPTestAppBaseViewController

///----------------------------------------------
/// @name View controller for user settings table
///----------------------------------------------

@end
