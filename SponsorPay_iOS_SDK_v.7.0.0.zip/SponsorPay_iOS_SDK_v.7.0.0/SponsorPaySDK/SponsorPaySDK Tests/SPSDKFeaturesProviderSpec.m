//
//  SPSDKFeaturesProviderSpec.m
//  SponsorPaySDK
//
//  Created by Daniel Barden on 12/03/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//
 
#define EXP_SHORTHAND
#import <Specta/Specta.h>
#import <Expecta/Expecta.h>
#import "SPSDKFeaturesProvider.h"

SpecBegin(SPSDKFeaturesProvider)

describe(@"SPSDKFeaturesProvider", ^{
    __block SPSDKFeaturesProvider *sut;

    beforeEach(^{
        sut = [[SPSDKFeaturesProvider alloc] init];
    });

    it(@"should return the correct dictionary", ^{
        NSDictionary *testDict = @{@"sdk_features" : @"INS,VPL"};

        NSDictionary *sutDict = [sut dictionaryWithKeyValueParameters];
        expect(testDict).to.equal(sutDict);
    });
});

SpecEnd

