//
//  SPVirtualCurrencyServerConnector+SPTesting.m
//  SponsorPaySDK
//
//  Created by Daniel Barden on 22/09/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import "SPVirtualCurrencyServerConnector+SPTesting.h"

@implementation SPVirtualCurrencyServerConnector_SPTesting

@end
