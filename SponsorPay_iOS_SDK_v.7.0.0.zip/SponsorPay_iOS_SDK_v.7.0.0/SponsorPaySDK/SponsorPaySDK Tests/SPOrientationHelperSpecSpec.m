//
//  SPOrientationHelperSpecSpec.m
//  SponsorPayTestApp
//
//  Created by Titouan on 23/06/14.
//  Copyright 2014 SponsorPay. All rights reserved.
//

#import <Specta/Specta.h>
#define EXP_SHORTHAND
#import <Expecta/Expecta.h>

#import <UIKit/UIKit.h>
#import "SPOrientationHelper.h"


SpecBegin(SPOrientationHelperSpec)

describe(@"SPOrientationHelperSpec", ^{
    
    it(@"returns the right frame for the given orientation", ^{
        CGRect applicationFrame = [[UIScreen mainScreen] bounds];

        expect([SPOrientationHelper fullScreenFrameForInterfaceOrientation:UIInterfaceOrientationPortrait]).to.equal(applicationFrame);
        expect([SPOrientationHelper fullScreenFrameForInterfaceOrientation:UIInterfaceOrientationPortraitUpsideDown]).to.equal(applicationFrame);
        
        CGRect expectedFrame = CGRectMake(applicationFrame.origin.y,
                                          applicationFrame.origin.x,
                                          applicationFrame.size.height,
                                          applicationFrame.size.width);
        
        expect([SPOrientationHelper fullScreenFrameForInterfaceOrientation:UIInterfaceOrientationLandscapeLeft]).to.equal(expectedFrame);
        expect([SPOrientationHelper fullScreenFrameForInterfaceOrientation:UIInterfaceOrientationLandscapeRight]).to.equal(expectedFrame);
    });
    
});

SpecEnd
