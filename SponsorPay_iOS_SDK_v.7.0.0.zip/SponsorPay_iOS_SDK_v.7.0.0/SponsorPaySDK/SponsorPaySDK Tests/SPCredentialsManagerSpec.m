//
//  SPCredentialsManagerTest.m
//  SponsorPaySDK
//
//  Created by David Davila on 21/11/13.
//  Copyright (c) 2013 SponsorPay. All rights reserved.
//

#define EXP_SHORTHAND
#import <Specta/Specta.h>
#import <Expecta/Expecta.h>
#import "SPCredentialsManager.h"
#import "SPCredentials.h"

static NSString *const kDummyProductKey = @"kDummyProductKey";

SpecBegin(SPCredentialsManager)

#if 0

// SPCredentialsManager class has changed!
// Test has not been updated since then

describe(@"SPCredentialsManager", ^{
    __block SPCredentialsManager *sut;
    __block NSArray *testCredentialsItems;

    // Helper block to fill the manager with credentials
    void (^fillCredentials)(SPCredentialsManager*, NSArray*) = ^(SPCredentialsManager *manager, NSArray *credentials) {
        for (SPCredentials *credential in credentials) {
            [manager addCredentialsItem:credential forToken:credential.credentialsToken];
        }
    };

    beforeAll(^{
        NSArray *testAppIds = @[@"1357", @"136402", @"1245"];
        NSArray *testUserIds = @[@"op-vim-har-ic-sod-ag-bi",
                                 @"rip-vub-heph-mam-belm-i",
                                 @"tal-cap-no-qui-wryn-mi-"];
        NSArray *testSecurityTokens = @[@"eg7hyp9yoth7zij5rit4ard9ig6jeeb4yud9nov",
                                        @"eith2vib7voac5good2nil7yur6os3ec5wud5li",
                                        @"ned5ev5yot8chi4hin7fe2oj7yib9gis2jeet9g"];

        NSUInteger itemCount = [testAppIds count];
        NSMutableArray *credentialsItems = [NSMutableArray arrayWithCapacity:itemCount];

        for (NSInteger i = 0; i < itemCount; i++) {
            SPCredentials *credentials = [SPCredentials credentialsWithAppId:testAppIds[i]
                                                                      userId:testUserIds[i]
                                                               securityToken:testSecurityTokens[i]];
            [credentialsItems addObject:credentials];
        }

        testCredentialsItems = credentialsItems;

    });

    beforeEach(^{
        sut = [[SPCredentialsManager alloc] init];
    });

    afterEach(^{
        sut = nil;
    });

    it(@"should raise SPNoCredentialsException when requesting credential and none available", ^{
        expect(^{
            [sut currentCredentials];
        }).to.raise(SPNoCredentialsException);
    });

    it(@"should raise SPInvalidCredentialsTokenException with requesting invalid token", ^{
        SPCredentials *result = [sut credentialsForToken:@"tokenForNonExistingCredentials"];
        expect(result).to.beNil();
    });

    it(@"should retrieve credentials by token correctly", ^{
        fillCredentials(sut, testCredentialsItems);
        for (SPCredentials *credentials in testCredentialsItems) {
            SPCredentials *retrievedCredentials = [sut credentialsForToken:credentials.credentialsToken];
            expect(retrievedCredentials).to.equal(credentials);
        }
    });

    it(@"should update the current credentials successfully", ^{
        fillCredentials(sut, testCredentialsItems);

    });
});
#endif

SpecEnd
