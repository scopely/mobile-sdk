//
//  SPInterstitialEventHubSpec.m
//  SponsorPaySDK
//
//  Created by Daniel Barden on 17/04/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import <Specta/Specta.h>
#define EXP_SHORTHAND
#import <Expecta/Expecta.h>

#import "SPInterstitialEventHub.h"
#import "SPConstants.h"

SpecBegin(SPInterstitialEventHub)

describe(@"SPInterstitialHub", ^{
    __block SPInterstitialEventHub *hub;
    before(^{
        hub = [[SPInterstitialEventHub alloc] init];
    });

    it(@"Should throw an exception when used with wrong parameter", ^{
        expect(^{
            [[NSNotificationCenter defaultCenter] postNotificationName:SPInterstitialEventNotification object:@"some object that is not correct"];
        }).will.raise(NSInvalidArgumentException);
    });
});

SpecEnd
