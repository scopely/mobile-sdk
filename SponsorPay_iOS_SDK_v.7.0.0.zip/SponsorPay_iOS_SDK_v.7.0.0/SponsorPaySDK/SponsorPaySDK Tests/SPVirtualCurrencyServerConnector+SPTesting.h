//
//  SPVirtualCurrencyServerConnector+SPTesting.h
//  SponsorPaySDK
//
//  Created by Daniel Barden on 22/09/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SPVirtualCurrencyServerConnector (SPTesting)

- (void)setDefaultCurrencyId:(NSString *)currencyId;

@end
