//
//  SPActionIdValidatorSpec.m
//  SponsorPaySDK
//
//  Created by Daniel Barden on 17/04/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import <Specta/Specta.h>
#define EXP_SHORTHAND
#import <Expecta/Expecta.h>

#import "SPActionIdValidator.h"

SpecBegin(SPActionIdValidator)

describe(@"SPActionIdValidator validate:reasonForInvalid:", ^{

    sharedExamplesFor(@"validate invalid input", ^(NSDictionary *data) {
        it(@"should fail", ^{
            NSString *exceptionReason = nil;
            // Lowcase Characters
            NSString *actionId = data[@"entry"];
            BOOL result = [SPActionIdValidator validate:actionId reasonForInvalid:&exceptionReason];
            expect(result).to.beFalsy();
            expect(exceptionReason).toNot.beNil();
        });
    });


    it(@"should succeed with valid input", ^{
        NSString *exceptionReason = nil;
        // Lowcase Characters
        BOOL result = [SPActionIdValidator validate:@"dsds" reasonForInvalid:&exceptionReason];
        expect(result).to.beFalsy();
        expect(exceptionReason).toNot.beNil();
    });

    itShouldBehaveLike(@"validate invalid input", @{@"entry": @"lowecase"});
    itShouldBehaveLike(@"validate invalid input", @{@"entry": @""});
    itShouldBehaveLike(@"validate invalid input", @{});


});

describe(@"SPActionIdValidator validateOrThrow:", ^{
    sharedExamples(@"validate invalid input", ^(NSDictionary *data) {
        it(@"should throw exception", ^{

            expect(^{
                NSString *actionId = data[@"entry"];
                [SPActionIdValidator validateOrThrow:actionId];
            }).to.raise(SPInvalidActionIdException);
        });
    });

    itShouldBehaveLike(@"validate invalid input", @{@"entry": @"lowecase"});
    itShouldBehaveLike(@"validate invalid input", @{@"entry": @""});
    itShouldBehaveLike(@"validate invalid input", @{});

});
SpecEnd
