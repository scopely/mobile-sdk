//
//  UIScreen+Additions.h
//  SponsorPaySDK
//
//  Created by tito on 21/07/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIScreen (SPAdditions)

+ (BOOL)isRetina;

@end
