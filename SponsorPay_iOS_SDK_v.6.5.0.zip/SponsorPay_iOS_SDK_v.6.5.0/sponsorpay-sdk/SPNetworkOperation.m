//
//  SPNetworkOperation.m
//  SponsorPayTestApp
//
//  Created by Daniel Barden on 11/11/13.
//  Copyright (c) 2013 SponsorPay. All rights reserved.
//

#import "SPNetworkOperation.h"
#import "SPURLGenerator.h"
#import "SPLogger.h"

static const NSTimeInterval SPCallbackOperationTimeout = 60.0;

@interface SPNetworkOperation () <NSURLConnectionDelegate>

@property (strong, nonatomic, readwrite) NSURLConnection *connection;
@property (strong, nonatomic, readwrite) NSURL *url;
@property (strong, nonatomic, readwrite) NSMutableData *responseData;
@property (strong, nonatomic, readwrite) NSHTTPURLResponse *response;

@end

@implementation SPNetworkOperation

- (id) initWithUrl:(NSURL *)url {
    self = [self init];
    if (self) {
        _url = url;
    }
    return self;
}

#pragma mark - Private

- (BOOL)isConcurrent {
    return YES;
}

-(void)start
{
    [self willChangeValueForKey:@"isExecuting"];
    _isExecuting = YES;
    [self didChangeValueForKey:@"isExecuting"];

    [self startRequest];
}

- (void) startRequest {
    if ([self performCancel]) {
        return;
    }

    NSMutableURLRequest* request = [[NSMutableURLRequest alloc] initWithURL:self.url
                                                                cachePolicy:NSURLRequestReloadIgnoringCacheData
                                                            timeoutInterval:SPCallbackOperationTimeout];

    [self.headerParameters enumerateKeysAndObjectsUsingBlock:^(NSString *key, NSString *value, BOOL *stop) {
        [request addValue:value forHTTPHeaderField:key];
    }];

    self.connection = [[NSURLConnection alloc] initWithRequest:request delegate:self startImmediately:NO];
    [self.connection start];
    CFRunLoopRun();
}

- (BOOL) performCancel {
	if ([self isCancelled]){
		[self finish];
		return YES;
	}
	return NO;
}

- (void)finish {
    self.url = nil;
    [self.connection cancel];

    [self willChangeValueForKey:@"isExecuting"];
    [self willChangeValueForKey:@"isFinished"];

    _isExecuting = NO;
    _isFinished = YES;

    [self didChangeValueForKey:@"isExecuting"];
    [self didChangeValueForKey:@"isFinished"];

    CFRunLoopStop(CFRunLoopGetCurrent());
}

#pragma mark - Accessors
-(NSMutableData *)responseData {
    if (!_responseData) {
        _responseData = [[NSMutableData alloc] init];
    }
    return _responseData;
}

#pragma mark - NSURLConnectionDelegate

-(void)connection:(NSURLConnection*)connection didReceiveResponse:(NSURLResponse*)response {
    SPLogDebug(@"Received configuration request response");
    if ([response isKindOfClass:[NSHTTPURLResponse class]]) {
        self.response = (NSHTTPURLResponse*)response;
    }
}
-(void)connection:(NSURLConnection*)connection didReceiveData:(NSData*)data {
    if ([self performCancel]) {
        return;
    }
    SPLogDebug(@"Received configuration request data");
    [self.responseData appendData:data];
}
-(void)connection:(NSURLConnection*)connection didFailWithError:(NSError*)error {
    SPLogError(@"Loading configuration failed with error: %@", error.description);

    if (self.networkOperationFailedBlock) {
        self.networkOperationFailedBlock(error);
    }
    [self finish];
}
-(void)connectionDidFinishLoading:(NSURLConnection*)connection {
    SPLogDebug(@"Finished loading configuration request");

    if (self.networkOperationSuccessBlock) {
        self.networkOperationSuccessBlock();
    }
    [self finish];
}

- (BOOL)connection:(NSURLConnection *)connection canAuthenticateAgainstProtectionSpace:(NSURLProtectionSpace *)protectionSpace {
    return [protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust];
}
@end
