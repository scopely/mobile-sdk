//
//  SPProviderManager.m
//  SponsorPayTestApp
//
//  Created by Daniel Barden on 30/12/13.
//  Copyright (c) 2013 SponsorPay. All rights reserved.
//

#import "SPBaseNetwork.h"
#import "SPTPNManager.h"
#import "SPLogger.h"
#import "SPSemanticVersion.h"
#import "SPConfigurationRequestManager.h"
#import "SPCredentials.h"
#import "SPVersionChecker.h"

typedef void (^SPNetworkCompletionBlock)(NSArray *networks);

static NSString *const SPNetworkName = @"name";
static NSString *const SPNetworkParameters = @"settings";

static const NSInteger SPAdapterSupportedVersion = 3;

@interface SPTPNManager ()

@property (nonatomic, strong) NSMutableDictionary *networks;

@end

@implementation SPTPNManager

#pragma mark - Class methods
+ (instancetype)sharedInstance
{
    static SPTPNManager *sharedInstance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ sharedInstance = [[SPTPNManager alloc] init]; });
    return sharedInstance;
}

+ (void)startNetworksWithCredentials:(SPCredentials *)credentials;
{
    [[self sharedInstance] startNetworksWithCredentials:(SPCredentials *)credentials];
}

+ (id<SPTPNVideoAdapter>)getRewardedVideoAdapterForNetwork:(NSString *)networkName
{
    return [[self sharedInstance] getRewardedVideoAdapterForNetwork:networkName];
}

+ (NSArray *)getAllRewardedVideoAdapters
{
    return [[self sharedInstance] getAllRewardedVideoAdapters];
}

+ (id<SPInterstitialNetworkAdapter>)getInterstitialAdapterForNetwork:(NSString *)networkName
{
    return [[self sharedInstance] getInterstitialAdapterForNetwork:networkName];
}

+ (NSArray *)getAllInterstitialAdapters
{
    return [[self sharedInstance] getAllInterstitialAdapters];
}

#pragma mark - Lifecycle
- (id)init
{
    self = [super init];
    if (self) {
        _networks = [[NSMutableDictionary alloc] init];
    }
    return self;
}

- (SPNetworkCompletionBlock) networkCompletionBlock {
    return ^void(NSArray *networks) {
        [networks enumerateObjectsUsingBlock:^(id providerData, NSUInteger idx, BOOL *stop) {
            NSString *networkName = providerData[SPNetworkName];
            NSString *networkClassName = [self getClassName:networkName];

            Class NetworkClass = NSClassFromString(networkClassName);
            if (!NetworkClass) {
                SPLogError(@"Class %@ could not be found", networkClassName);
                return;
            }


            if (![NetworkClass isSubclassOfClass:[SPBaseNetwork class]]) {
                SPLogError(@"Class %@ is not a subclass of %@", NSStringFromClass(NetworkClass), NSStringFromClass([SPBaseNetwork class]));
                return;
            }

            if (![self isAdapterVersionValid:[NetworkClass adapterVersion]]) {
                SPLogError(@"Could not add %@: Adapter version is %@ but this SDK version support only adapters with version %d.X.X", networkName, [NetworkClass adapterVersion], SPAdapterSupportedVersion);
                return;
            }

            SPBaseNetwork *network = [self getNetworkWithClass:NetworkClass];
            if (!network) {
                network = [[NetworkClass alloc] init];
            }

            // Starts the SDK and Adapters
            BOOL sdkStarted = [network startNetworkWithName:networkName data:providerData[SPNetworkParameters]];
            
            if (!sdkStarted) {
                [self.networks removeObjectForKey:[network.name lowercaseString]];
                return;
            }

            [self.networks setObject:network forKey:[network.name lowercaseString]];
        }];
    };
}

- (void)startNetworksWithCredentials:(SPCredentials *)credentials
{
    if (SPFoundationVersionNumber < NSFoundationVersionNumber_iOS_5_0) {
               SPLogError(@"The device is running a version of iOS (%f) that is inferior to the lowest iOS version (%f) "
                          @"compatible with Fyber's SDK",
                          SPFoundationVersionNumber,
                          NSFoundationVersionNumber_iOS_5_0);
        SPLogInfo(@"Network adapters will not be started");
        return;
    }

    // Add configuration request from server side
    SPConfigurationRequestManager *configManager = [[SPConfigurationRequestManager alloc] initWithCredentials:credentials completionBlock:[self networkCompletionBlock]];
    configManager.configurationFailedBlock = ^void(NSError *error) {
        SPLogError(@"%@", error);
    };
    [configManager requestConfiguration];
}

- (id<SPTPNVideoAdapter>)getRewardedVideoAdapterForNetwork:(NSString *)networkName
{
    SPBaseNetwork *network = self.networks[[networkName lowercaseString]];
    if (network.supportedServices & SPNetworkSupportRewardedVideo) {
        return [network rewardedVideoAdapter];
    } else {
        return nil;
    }
}

- (NSArray *)getAllRewardedVideoAdapters
{
    __block NSMutableArray *videoAdapters = [[NSMutableArray alloc] init];
    NSArray *networks = [self.networks allValues];
    [networks enumerateObjectsUsingBlock:^(SPBaseNetwork *network, NSUInteger idx, BOOL *stop) {
    if ([network supportedServices] & SPNetworkSupportRewardedVideo) {
        [videoAdapters addObject:[network rewardedVideoAdapter]];
    }
    }];
    return [NSArray arrayWithArray:videoAdapters];
}

- (id<SPInterstitialNetworkAdapter>)getInterstitialAdapterForNetwork:(NSString *)networkName
{
    SPBaseNetwork *network = self.networks[[networkName lowercaseString]];

    if (network.supportedServices & SPNetworkSupportInterstitial) {
        return [network interstitialAdapter];
    } else {
        return nil;
    }
}

- (NSArray *)getAllInterstitialAdapters
{
    __block NSMutableArray *interstitialAdapters = [[NSMutableArray alloc] init];
    NSArray *networks = [self.networks allValues];
    [networks enumerateObjectsUsingBlock:^(SPBaseNetwork *network, NSUInteger idx, BOOL *stop) {
    if ([network supportedServices] & SPNetworkSupportInterstitial) {
        [interstitialAdapters addObject:[network interstitialAdapter]];
    }
    }];
    return [NSArray arrayWithArray:interstitialAdapters];
}

#pragma mark - Helper Methods

- (SPBaseNetwork *)getNetworkWithClass:(__unsafe_unretained Class)networkClass
{
    // Checks if the provider is already integrated. Since we won't reuse networks, we can check if an object of the
    // network class exists in the networks
    // Also, sometimes the provider.name is different than suffix used to instantiate the class
    NSArray *integratedNetworks = [self.networks allValues];
    NSUInteger index = [integratedNetworks indexOfObjectPassingTest:^BOOL(id obj, NSUInteger idx, BOOL *stop) {
    if ([obj class] == networkClass) {
        *stop = YES;
        return YES;
    }
    return NO;
    }];

    if (index == NSNotFound) {
        return nil;
    } else {
        return integratedNetworks[index];
    }
}

// The adapter's major version reflects the version of the interface between the sdk <-> adapter.
- (BOOL)isAdapterVersionValid:(SPSemanticVersion *)adapterVersion
{
    return adapterVersion.major == SPAdapterSupportedVersion;
}

// Gets the provider class name by concatenating the name.
- (NSString *)getClassName:(NSString *)networkName
{
    NSString *trimmedNetworkName = [networkName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSString *networkClassName = [NSString stringWithFormat:@"SP%@Network", trimmedNetworkName];
    return networkClassName;
}

@end
