ios-sdk-testapp
===============


Repository for the Sponsorpay SDK + TestApp.

Contributing
------------
1. Create your own fork
2. Implementation and test. Coding guideline: [here](http://wiki.sponsorpay.com/wiki/objc-style-guide)
3. Send Pull Request

Releasing a new version
-----------------------

General instructions can be found [here](http://wiki.sponsorpay.com/wiki/release-process)
