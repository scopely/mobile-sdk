When /^I set the App ID to "([^\"]*)"$/ do |app_id|
  macro %Q|I go to the "Start" tab|
  macro %Q<My Application is "#{app_id}">
end

When /^I set the User ID to "([^\"]*)"$/ do |user_id|
  macro %Q|I go to the "Start" tab|
  timestamped_user_id = user_id + Time.now.to_i.to_s
  macro %Q<I am user "#{timestamped_user_id}">
end

When /^I set the Security Token to "(.*?)"$/ do |token|
  macro %Q|I go to the "Start" tab|
  macro %Q<My security token is "#{token}">
end

Given /^I am user "([^\"]*)"$/ do |name|
  keep_using_set_text("textField accessibilityLabel:'UserID_TextField'", name)
  sleep(STEP_PAUSE)
end

Given /^My Application is "([^\"]*)"$/ do |appid|
  keep_using_set_text("textField accessibilityLabel:'AppID_TextField'", appid)
  sleep(STEP_PAUSE)
end

Given /^My security token is "([^\"]*)"$/ do |token|
  keep_using_set_text("textField accessibilityLabel:'VCSKey_TextField'", token)
  sleep(STEP_PAUSE)
end

Given /^I start the SDK$/ do
  touch("button accessibilityLabel:'StartSDK_Button'")
end

Then /^I should get the Invalid App ID error$/ do
  raise "This doesn't seem to be the Invalid App ID error" unless get_alert_message.include? "A valid App ID must be specified"
end

When /^I accept the Invalid App ID error$/ do
  click_dialog_button "OK"
end

Then /^I see the You Need to Start the SDK error$/ do
  raise "This doesn't seem to be the You Need to Start the SDK error" unless get_alert_message.include? "(No credentials found for the credentials token specified.)"
end

When /^I set the Currency Name to "(.*?)"$/ do |currency_name|
  macro %Q|I go to the "Start" tab|
  touch("textField accessibilityLabel:'CurrencyName_TextField'")
  sleep(STEP_PAUSE)
  keyboard_enter_text currency_name
  keyboard_enter_char 'Return'
  sleep(STEP_PAUSE)
end