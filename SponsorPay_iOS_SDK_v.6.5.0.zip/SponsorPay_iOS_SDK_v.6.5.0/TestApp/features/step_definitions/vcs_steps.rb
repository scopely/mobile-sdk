When /^I request the Delta of Coins$/ do
  macro %Q|I go to the "VCS" tab|
  touch("button accessibilityLabel:'RequestDeltaOfCoins_Button'")
  sleep(STEP_PAUSE)
end

Then /^the Delta Of Coins should be "(.*?)"$/ do |expected_delta_of_coins|
  bad =  query("view {accessibilityLabel == 'deltaOfCoinsField' and text == '#{expected_delta_of_coins}'}").empty?
  screenshot_and_raise "The Delta Of Coins I see is not the one I expect (#{expected_delta_of_coins})" if bad
end

Then /^the Delta Of Coins should be greater than zero$/ do
  screenshot_and_raise "Delta of Coins is not greater than zero" unless (query("view {accessibilityLabel == 'deltaOfCoinsField'}", :text)[0].to_f > 0)
end

Then /^the Received Last Transaction ID should be "(.*?)"$/ do |expected_ltid|
  screenshot_and_raise "The Received Last Transaction ID I see is not the one I expect (#{expected_ltid})" if response_ltid_value != expected_ltid
end

Then /^the Received Last Transaction ID should be some Transaction ID$/ do
  no_transaction_id_value = "NO_TRANSACTION"

  screenshot_and_raise "The Received Last Transaction ID is set to #{no_transaction_id_value}" if response_ltid_value == no_transaction_id_value
end

Then /^I should get the error ERROR_INVALID_APPID$/ do
  raise "This doesn't seem to be the ERROR_INVALID_APPID error" unless get_alert_message.include? "ERROR_INVALID_APPID"
end

Then /^I should get the error ERROR_INVALID_SIGNATURE$/ do
  raise "This doesn't seem to be the ERROR_INVALID_SIGNATURE error" unless get_alert_message.include? "ERROR_INVALID_SIGNATURE"
end

Then /^I should eventually see the Coins Reward Toast$/ do
  wait_for( :timeout => 15  ) { query("view accessibilityIdentifier:'ToastView'").length > 0  }
end