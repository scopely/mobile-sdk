#include Calabash::Cucumber::TestsHelpers

def screenshot_host_embed(options={:prefix => nil, :name => nil, :label => nil})
  path = screenshot_host(options)
  embed(path, "image/png", options[:label] || File.basename(path))
end

def screenshot_host(options={:prefix => nil, :name => nil})
  prefix = options[:prefix]
  name = options[:name]
  @@screenshot_count ||= 0
    #res = http({:method => :get, :path => 'screenshot'})
    prefix = prefix || ENV['SCREENSHOT_PATH'] || ""
    if name.nil?
      name = "host_screenshot"
    else
      if File.extname(name).downcase == ".png"
        name = name.split(".png")[0]
      end
    end
    
    path = "#{prefix}#{name}_#{@@screenshot_count}.png"
    
  %x{osascript<<APPLESCRIPT
    set picPath to "#{path}" as string
    do shell script "screencapture " & quoted form of picPath
  APPLESCRIPT} 
  
  @@screenshot_count += 1
  path
end

Then /^(?:I\s)(?:T|t)ake (?:picture|screenshot) of host$/ do
	screenshot_host_embed
end

Then /^(?:L|l)ock the device$/ do
	press_lock_on_simulator
end
