When /^I launch the OfferWall$/ do
  macro "I try to launch the OfferWall"
  wait_for( :timeout => 15  ) { offerwall_visible? }
  sleep(1)
end

When /^I try to launch the OfferWall$/ do
  macro %Q|I go to the "OfferWall" tab|
  touch("button accessibilityLabel:'LaunchOfferWall_Button'")
  sleep(STEP_PAUSE)
end

Then /^I see the Bad Request message on the WebView$/ do
  screenshot_and_raise "I don't see the Bad Request message" unless bad_request?
end

Then /^I see the Cookies Required message on the WebView$/ do
  screenshot_and_raise "I don't see the Cookies Required message" unless cookies_required?
end

Then /^I see the OfferWall$/ do
    screenshot_and_raise "I don't see the OfferWall" unless offerwall_visible?
end

When /^I scroll the OfferWall down until I see the More Offers button$/ do
  screenshot_and_raise "I don't see the OfferWall" unless offerwall_visible?
  times_scrolled = 0;
  until more_offers_button_visible?
  	scroll("webView", :down)
    sleep(STEP_PAUSE)
    times_scrolled += 1
    screenshot_and_raise "I've been scrolling and scrolling and I don't see the More Offers button" unless times_scrolled < 15
  end
  #break unless 
  
  #screenshot_and_raise "I couldn't find the More Offers button after scrolling down for a while" unless more_offers_button_visible?
end

When /^I touch the More Offers button$/ do
  touch_more_offers_button
end

When /^I scroll the OfferWall a bit further down$/ do
  scroll("webView", :down)
end

When /^I click on the last offer I see$/ do
  offer_css_selector = "webView css:'#offers ul li'"
  cnt_offers = query(offer_css_selector).length
  screenshot_and_raise "I don't see any offers" unless cnt_offers > 0
  touch(offer_css_selector)[cnt_offers - 1]
end	

When /^I scroll to the bottom of the OfferWall$/ do
  scroll_until_offerwall_bottom
end

When /^I touch the Support button$/ do
  touch("webView css:'#btn-supp'")
end

Then /^I see the Support page$/ do
  found = query("webView css:'#main header h1'")
  screenshot_and_raise("This doesn't look like the Support page") unless found.length > 0 and found[0]["textContent"] == "Support"
end

When /^I touch the Help button$/ do
  touch("webView css:'#btn-help'")
end

When /^I touch the Privacy button$/ do
  touch("webView css:'#btn-priv'")
end

Then /^I see the Privacy page$/ do
  found = query("webView css:'#main header h1'")
  screenshot_and_raise("This doesn't look like the Privacy page") unless found.length > 0 and found[0]["textContent"] == "Privacy"
end

When /^I close the OfferWall$/ do
  touch("webView css:'#btn-back'")
  sleep(2)
end

Given /^that offer with LPID (-?\d+) is available$/ do |lpid|
  screenshot_and_raise "Offer is not available" unless offer_with_lpid? lpid.to_i, true
  sleep 2
end

Then /^I click the Offer with LPID (\d+)$/ do |lpid|
  click_offer_with_lpid lpid.to_i, true
  sleep 2
end

Then /^the OfferWall should show "(.*?)" as currency name$/ do |currency_name|
  screenshot_and_raise "OfferWall doesn't show the right currency name" unless query("webView css:'.page-offers header h1'")[0]["textContent"].include? currency_name
end
