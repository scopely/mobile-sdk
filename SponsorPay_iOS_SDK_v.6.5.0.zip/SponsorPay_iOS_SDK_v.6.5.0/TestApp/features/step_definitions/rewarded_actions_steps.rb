When /^I enter the Rewarded Action ID "(.*?)"$/ do |action_id|
  macro %Q|I go to the "Actions" tab|
  keep_using_set_text("textField accessibilityLabel:'ActionID_TextField'", action_id)
  sleep(STEP_PAUSE)
end

When /^I report the Rewarded Action as completed$/ do
  touch("button accessibilityLabel:'ReportActionCompleted_Button'")
end

Then /^I should get an Invalid Action ID Format error from the SDK$/ do
  raise "This doesn't seem to be the Action ID Format error" unless get_alert_message.include? "actionId must consist exclusively of uppercase latin characters, numbers and the underscore symbol (_)"
end

Then /^I should get an Action ID Must Not Be Empty error from the SDK$/ do
  raise "This doesn't seem to be the Action ID Must Not Be Empty error" unless get_alert_message.include? "actionId must not be empty"
end