require './features/support/host_scripting.rb'
include Frank::Cucumber::HostScripting

Given /^I press Home button$/ do
	press_home_on_simulator
end

Then /^I start recording$/ do
	start_recording
end

Then /^I stop recording$/ do
	stop_recording
end

Then /^I manually (.*)$/ do |action|
  # Do nothing
end

When /^I rotate the device to the left$/ do
  rotate(:left)
  sleep(STEP_PAUSE)
end

Given /^I wait for the network activity indicator to disappear$/ do
  wait_for_no_network_indicator
  sleep(STEP_PAUSE)
end
