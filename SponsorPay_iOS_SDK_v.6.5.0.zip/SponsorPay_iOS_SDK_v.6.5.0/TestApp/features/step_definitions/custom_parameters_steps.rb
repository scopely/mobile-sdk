When /^I open the Additional Parameters screen$/ do
  macro %Q|I go to the "OfferWall" tab|
  touch("button accessibilityLabel:'SetCustomParameters_Button'")
  sleep(STEP_PAUSE)
end

When /^I add a parameter with key: "(.*?)" and value: "(.*?)"$/ do |key, value|
  keep_using_set_text("textField accessibilityLabel:'Key_TextField'", key)
  keep_using_set_text("textField accessibilityLabel:'Value_TextField'", value)
  touch("button accessibilityLabel:'AddKeyValue_Button'")
  sleep(STEP_PAUSE)
end

When /^I close the Additional Parameters screen$/ do
  touch("button accessibilityLabel:'Done'")
  sleep(STEP_PAUSE)
end