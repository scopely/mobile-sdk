def bad_request?
    query("webView css:'#badrequest'").size > 0
  rescue
    false
end

def cookies_required?
    query("webView css:'#cookies-required'").size > 0
  rescue
    false
end

def offerwall_visible?
  query("webView css:'.hint'").size > 0
end

def cnt_offers_in_page
  raise "Offerwall is not displayed currently" unless offerwall_visible?
  query("webView css:'li'").size
end

def more_offers_button_visible?
    query("webView css:'#more .enabled'").length > 0
  rescue
    false
end

def touch_more_offers_button
  scroll_until_offerwall_bottom
  sleep(STEP_PAUSE)
  if more_offers_button_visible?
    touch("webView css:'#more .enabled'")
  end
end

def offerwall_bottom_visible?
  q_results = query("webView css:'#main footer'")
  #puts "OFW Bottom Query results: " + q_results.to_s
  q_results.length > 0
end

def scroll_until_offerwall_bottom
  times_scrolled = 0
  until offerwall_bottom_visible?
    screenshot_and_raise "I've been scrolling and scrolling and I don't see the OfferWall bottom" unless times_scrolled < 15
    scroll("webView", :down)
    sleep(STEP_PAUSE)
    times_scrolled += 1
  end
end

def more_offers?
  raise "Offerwall is not displayed currently" unless offerwall_visible?
  scroll_until_offerwall_bottom
  query("webView css:'div#more'").size != 0
end

def wait_for_offers
  wait_for( :timeout => 5  ) { cnt_offers_in_page > 0 }
end

def offer_with_lpid? (lpid, expandMoreOffers=false)
  raise "Invalid argument" unless lpid.is_a? Integer
  raise "Offerwall is not displayed currently" unless offerwall_visible?
  wait_for_offers
  query_string = "webView css:'li[data-lp=\"#{lpid}\"]'"
  offer = query(query_string).size == 1
  until (offer || !expandMoreOffers || !more_offers?) do
    touch_more_offers_button
    offer = query(query_string).size == 1
    sleep 2
  end
  offer
end

def click_offer_with_lpid (lpid, expandMoreOffers=false)
  raise "Offer is not available" unless offer_with_lpid? lpid, expandMoreOffers
  # touch("webView css:'li[data-lp=\"#{lpid}\"]'") would hang something deep inside calabash-cucumber,
  # even though query(ditto) works just fine
  # we have to go for a less elegant approach until that's fixed
  video_offer = query("webView css:'li[data-lp=\"89518\"] .tag.video'").size > 0
  touch(query("webView css:'li[data-lp=\"#{lpid}\"]'").first)
  if not video_offer
    begin
      click_on_interstitial_offer if interstitial_visible?
    rescue
    end
  end
end

def interstitial_visible?
  sleep(STEP_PAUSE)
  query("webView css:'.interstitial'").size > 0
end

def click_on_interstitial_offer
  sleep(STEP_PAUSE)
  touch("webView css:'.interstitial-btn'")
end

def udid_permission_dialog_visible?
  alert_dialog? and query("alertView", :title).first.include? "Do you want to share and transmit your device information?"
end
