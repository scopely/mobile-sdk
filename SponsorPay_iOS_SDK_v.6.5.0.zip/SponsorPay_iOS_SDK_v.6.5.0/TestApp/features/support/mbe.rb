def mbe_offers_available?
  raise "Not on MBE tab" unless tab? "MBE"
  query("button accessibilityLabel:'StartMBE_Button'", :isEnabled)[0] == "1"
end

def request_mbe_offers
  touch("view marked:'#{Frank::Cucumber::Localize.t(:request_offers)}'")
  #macro %Q|I touch "#{Frank::Cucumber::Localize.t(:request_offers)}"|
  #macro %Q|I wait for 3 seconds|
  sleep 3
end

def start_mbe_engagement
  wait_for_elements_exist( ["view accessibilityLabel:'StartMBE_Button' isEnabled:1"], :timeout => 15)
  touch("view marked:'#{Frank::Cucumber::Localize.t(:start_mbe)}'")
  sleep 5
  screenshot_embed
  #macro %Q|I touch "#{Frank::Cucumber::Localize.t(:start_mbe)}"|
  #macro %Q|I wait for 5 seconds|
  #macro %Q|I take picture|
end

def cpi_page?
  query("movieView").empty? &&\
  query("webView css:'.action-button'").size > 0 &&\
  query("view:'SPBrandEngageWebView'").size > 0
end

def install_offer
  raise "Not on CPI page" unless cpi_page?
  touch("webView css:'.action-button'")
  sleep 2
end

def x_close_button_visible?
  query("webView css:'.x-close'").size > 0
end

def click_on_x_close_button
  raise "X close button is not visible" unless x_close_button_visible?
  touch("webView css:'.x-close'")
  sleep 1
end

def get_banner_message
  get_banner["textContent"]
end

def banner_visible?
  query("webView css:'div.topbar.translucent'").size > 0
end

def get_banner
  raise "No banner at the moment" unless banner_visible?
  query("webView css:'div.topbar.translucent'").first
end
