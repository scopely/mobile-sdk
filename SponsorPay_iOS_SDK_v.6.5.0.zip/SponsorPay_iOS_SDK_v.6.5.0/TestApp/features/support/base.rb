def keep_using_set_text(field, text)
  unless query(field, :text).first == text
    touch(field)
    map(field, :setText, '')
    # wait_poll(:until_exists => "#{field} text:''", :timeout => 20) do
    #   keyboard_enter_char 'Delete'
    # end
    sleep(STEP_PAUSE)
    keyboard_enter_text text
    done
  end
end