def click_dialog_button (button)
  raise "There's no alert dialog at the moment" unless alert_dialog?
  index = query("alertButton", :title).index button
  sleep(STEP_PAUSE)
  touch("alertButton index:#{index}")
  sleep(STEP_PAUSE)
end

def alert_dialog?
  query('alertView').size > 0 ||
  query('modalView').size > 0
end

def get_alert_message
  raise "There's no alert dialog" unless alert_dialog?
  #performAction('get_view_property', 'android:id/message', 'text')["message"]
  query("alertView", :message).first
end

def touch_alert_button_yes
  touch("alertButton title:'Yes'").first
end

def error_no_credentials?
  (get_alert_message =~ /No credentials found for the credentials/) != nil
end