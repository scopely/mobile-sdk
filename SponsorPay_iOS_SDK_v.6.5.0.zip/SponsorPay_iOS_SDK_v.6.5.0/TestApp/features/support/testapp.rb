def use_staging_urls (staging=true)
  if staging? ^ staging
    touch("switch accessibilityLabel:'UseStagingURLs_Switch'")
  end
end

def staging?
  check_main_tab
  query("switch accessibilityLabel:'UseStagingURLs_Switch'", :isOn).first == "1"
end

def main_tab?
  tab? "Start"
end

def check_main_tab
  raise "Not on main tab" unless main_tab?
end

def switch_to_tab (title)
  unless tab? title #this can be optimized checking the title of the controller
    if tab_bar_contains? title
      touch("tabBarButton accessibilityLabel:'#{title}'")
    else
      touch("tabBarButton accessibilityLabel:'More'")
      touch("tabBarButton accessibilityLabel:'More'") unless query("tableViewCell").size > 0
      sleep(STEP_PAUSE)
      touch("tableViewCell text:'#{title}'")
    end
  end
end

def tab_bar_contains? (title)
  query("tabBarButton", :accessibilityLabel).include? title
end

def current_tab
  opened_tab
end

def opened_tab
  query("tabBar", :selectedItem, "title").first
end

def tab? (title)
  opened_tab == title
end
