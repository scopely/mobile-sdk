def get_index_path(section, row_text) 
  each_cell(:post_scroll=>0.2) do |row, sec|
    return row,sec if section == sec && !query("tableViewCell indexPath:#{row},#{sec} {text CONTAINS '#{row_text}'}").empty?
  end
end

def get_section(section)
  case section
  when "Validation Events" 
    0
  when "Video Playing Events" 
    1 
  end
end