//
//  SPLogViewController.h
//  SponsorPay Sample App
//
//  Created by David Davila on 1/14/13.
// Copyright 2011-2013 SponsorPay. All rights reserved.
//

#import "SPTestAppBaseViewController.h"

@interface SPLogViewController : SPTestAppBaseViewController<UITextViewDelegate>

@property (strong, nonatomic) IBOutlet UITextView *logMessagesTextView;

@end
