//
//  SPStartSDKSettingsViewController.h
//  
//
//  Created by Daniel Barden on 30/10/13.
//
//

#import <UIKit/UIKit.h>

@interface SPStartSDKSettingsViewController : UIViewController<UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) IBOutlet UITableView *tableView;

- (IBAction)dismiss:(id)sender;

@end
