//
//  SPSettingsViewController.h
//  SponsorPay Sample App
//
//  Created by David on 9/14/12.
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SPUrlUtil.h"

@interface SPSettingsViewController : UIViewController <UITextFieldDelegate, UITableViewDataSource, UITableViewDelegate>

@property (strong, nonatomic) IBOutlet UITextField *keyTextField;
@property (strong, nonatomic) IBOutlet UITextField *valueTextField;
@property (strong, nonatomic) IBOutlet UITableView *paramsTableView;
@property (strong, nonatomic) IBOutlet UITextField *urlOverriderTextField;
@property (strong, nonatomic) IBOutlet UISwitch *overrideSwitch;

- (IBAction)doneButtonTapped:(id)sender;
- (IBAction)addButtonTapped:(id)sender;
- (IBAction)urlOverriderSwitchValueChanged:(UISwitch *)sender;

@end
