//
//  SPSettingsTableViewController.m
//  SponsorPayTestApp
//
//  Created by Pierre Bongen on 26.05.14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import "SPSettingsTableViewController.h"

// SponserPay Test App.
#import "SPBlocks.h"
#import "SPTestAppSettings.h"
#import "SPSettingsTableViewCell.h"
#import "SPStrings.h"



//
// Constants
//

SP_KEY( SPSettingsTableViewCellIdentifier )



#pragma mark  

@interface SPSettingsTableViewController ()

#pragma mark  
#pragma mark Private Properties -

#pragma mark  
#pragma mark User Interface

@property ( nonatomic, strong, readonly ) UIBarButtonItem *doneButtonItem;

#pragma mark  
#pragma mark Data

// Intentionally strong.
@property ( nonatomic, strong, readonly ) NSMutableDictionary *
    footerTitleBySettingsGroupName;
    
// Intentionally strong.
@property ( nonatomic, strong, readonly ) NSMutableDictionary *
    footerTitleBySettingsGroupNameLazy;
    
// Intentionally strong.
@property ( nonatomic, strong, readwrite ) NSArray *groupNamesOrdered;

// Intentionally strong.
@property ( nonatomic, strong, readonly ) NSArray *groupNamesOrderedLazy;

// Intentionally strong.
@property ( nonatomic, strong, readwrite ) NSMutableDictionary *
	settingsByGroupName;

// Intentionally strong.
@property ( nonatomic, strong, readonly ) NSMutableDictionary *
	settingsByGroupNameLazy;

#pragma mark  
#pragma mark State

@property ( nonatomic, assign ) BOOL didScheduleReload;

@end



#pragma mark  
#pragma mark  
#pragma mark  

@implementation SPSettingsTableViewController
{
@private

    //
    // User Interface
    //
    
    UIBarButtonItem *doneButtonItem;
    
    //
    // Settings
    //
    
    NSMutableDictionary *footerTitleBySettingsGroupName;
    NSArray *groupNamesOrdered;
    NSMutableDictionary *settingsByGroupName;
    
    //
    // State
    //

    BOOL didScheduleReload;
    
}

#pragma mark  
#pragma mark Private Properties -

#pragma mark  
#pragma mark User Interface

- (UIBarButtonItem *)doneButtonItem
{
    if ( !self->doneButtonItem ) {
    
        self->doneButtonItem = [[UIBarButtonItem alloc] 
        	initWithBarButtonSystemItem:UIBarButtonSystemItemDone
            target:self
            action:@selector( dismiss: )];
        
        self->doneButtonItem.tintColor = [UIColor 
        	colorWithRed:0.5
            green:0.
            blue:0.
            alpha:1.];
    
    }
    
    return self->doneButtonItem;
}

#pragma mark  
#pragma mark Data

@synthesize footerTitleBySettingsGroupName = footerTitleBySettingsGroupName;
@synthesize groupNamesOrdered = groupNamesOrdered;
@synthesize settingsByGroupName = settingsByGroupName;

#pragma mark  

- (NSMutableDictionary *)footerTitleBySettingsGroupNameLazy
{
    NSMutableDictionary *result = self.footerTitleBySettingsGroupName;
    
    if ( !result )
    {
        result = [NSMutableDictionary new];
        self.footerTitleBySettingsGroupName = result;
    }
    
    return result;
}

- (NSArray *)groupNamesOrderedLazy
{
    NSArray *result = self.groupNamesOrdered;
    
    if ( !result ) {
    
        result = [[self.settingsByGroupName allKeys] sortedArrayUsingSelector:
        	@selector( localizedCompare: )];
    
        self.groupNamesOrdered = result;
    }
    
    return result;
}

- (void)setFooterTitleBySettingsGroupName:(NSMutableDictionary *)
	newFooterTitleBySettingsGroupName
{
    //
    // Check parameter.
    //
    
    NSAssert(
        !newFooterTitleBySettingsGroupName
            || [newFooterTitleBySettingsGroupName isKindOfClass:
            	[NSMutableDictionary class]],
        @"Expecting %@ to be nil or to be kind of class NSMutableDictionary.",
        SP_STRINGIFY( newFooterTitleBySettingsGroupName ) );
    
    //
    // Check state.
    //
    
    if (
        newFooterTitleBySettingsGroupName 
        	== self->footerTitleBySettingsGroupName
        || [newFooterTitleBySettingsGroupName isEqualToDictionary:
        	self->footerTitleBySettingsGroupName]
    ){
        return;
    }
    
    //
    // Set new footer titles.
    //
    
    self->footerTitleBySettingsGroupName = newFooterTitleBySettingsGroupName;
    
    // Schedule reload of data since the footer titles might have changed.
    [self scheduleReload];
}

- (void)setGroupNamesOrdered:(NSArray *)newGroupNamesOrdered
{
    //
    // Check parameter.
    //
    
    NSAssert(
        !newGroupNamesOrdered 
        	|| [newGroupNamesOrdered isKindOfClass:[NSArray class]],
        @"Expecting %@ to be nil or kind of class NSArray.",
        SP_STRINGIFY( newGroupNamesOrdered ) );

    //
    // Check state.
    //
    
    if ( [self->groupNamesOrdered isEqualToArray:newGroupNamesOrdered] ) {
    
        return;
    }

    //
    // Set new group names.
    //
    
    self->groupNamesOrdered = newGroupNamesOrdered;
    
    // Schedule reload of data since the order might have changed.
    [self scheduleReload];
}

- (void)setSettingsByGroupName:(NSMutableDictionary *)newSettingsByGroupName
{
    //
    // Check parameter.
    //
    
    NSAssert(
        !newSettingsByGroupName 
        	|| [newSettingsByGroupName isKindOfClass:[NSDictionary class]],
        @"Expecting %@ parameter to be nil or kind of class NSDictionary.",
        SP_STRINGIFY( newSettingsByGroupName ) );
    
    //
    // Check state.
    //
    
    if ( 
    	[self->settingsByGroupName isEqualToDictionary:
    		newSettingsByGroupName] 
    ) {
        return;
    }
    
    //
    // Set new settings.
    //
    
    self->settingsByGroupName = newSettingsByGroupName;
    
    // --- Reset depending properties.
    
    self.groupNamesOrdered = nil;
    
    // --- Update UI.
    
    [self scheduleReload];
}

- (NSMutableDictionary *)settingsByGroupName
{
    return self->settingsByGroupName;
}

- (NSMutableDictionary *)settingsByGroupNameLazy
{
    NSMutableDictionary *result = self.settingsByGroupName;
    
    if ( !result ) {
    
        result = [NSMutableDictionary new];
        
        self.settingsByGroupName = result;
    
    }
    
    return result;
}

#pragma mark  
#pragma mark State

@synthesize didScheduleReload = didScheduleReload;

#pragma mark  
#pragma mark  
#pragma mark Public Methods -

#pragma mark  
#pragma mark Initialisation

- (id)init
{
    self = [super initWithStyle:UITableViewStyleGrouped];

    if (self) {
    }

    return self;
}

#pragma mark  
#pragma mark Managing Settings

- (void)addSettings:(SPTestAppSettings *)settings 
	toGroupWithName:(NSString *)aGroupName
{
    //
    // Check parameters.
    //
    
    NSAssert(
        [settings isKindOfClass:[SPTestAppSettings class]],
        @"Expecting %@ parameter to be kind of class %@.",
        SP_STRINGIFY( settings ),
        NSStringFromClass( [SPTestAppSettings class] ) );
    
    NSAssert(
        [aGroupName isKindOfClass:[NSString class]] 
        	&& [[aGroupName stringByTrimmingCharactersInSet:
            	[NSCharacterSet whitespaceAndNewlineCharacterSet]] length],
        @"Expecting %@ parameter to be a non-empty, visible string.",
        SP_STRINGIFY( aGroupName ) );
    
    //
    // Get settings group.
    //
    
    NSMutableDictionary * const settingsByGroupNameOfSelf = 
    	self.settingsByGroupNameLazy;
        
    NSMutableArray *settingsOfGroup = [settingsByGroupNameOfSelf objectForKey:
    	aGroupName];
    
    if ( !settingsOfGroup ) {
    
        settingsOfGroup = [NSMutableArray new];
        
        [settingsByGroupNameOfSelf 
        	setObject:settingsOfGroup 
            forKey:aGroupName];
    
    }
    
    //
    // Add settings.
    //
    
    [settingsOfGroup addObject:settings];

    // Must be recomputed -- so reset!
    self.groupNamesOrdered = nil;
    
    //
    // Update UI.
    //
    
    [self scheduleReload];
}

- (SPTestAppSettings *)settingsAtIndexPath:(NSIndexPath *)indexPath
{
    //
    // Check parameter.
    //
    
    NSAssert( 
    	[indexPath isKindOfClass:[NSIndexPath class]],
        @"Expecting %@ parameter to be kind of class NSIndexPath.",
        SP_STRINGIFY( indexPath ) );

    //
    // Determine settings.
    //
    
    NSArray * const groupNamesOrderedOfSelf = self.groupNamesOrderedLazy;
    
    if ( [groupNamesOrderedOfSelf count] <= indexPath.section ) {
    
        return nil;
    
    }

    NSString * const groupName = groupNamesOrderedOfSelf[ indexPath.section ];
    NSArray * const settingsInGroup = [self settingsInGroupWithName:groupName];
    
    if ( [settingsInGroup count] <= indexPath.row ) {
    
        return nil;
    
    }
    
    SPTestAppSettings * const result = settingsInGroup[ indexPath.row ];
    
    return result;
}

- (NSArray *)settingsInGroupWithName:(NSString *)aGroupName
{
    //
    // Check parameters.
    //
    
    NSAssert(
        [aGroupName isKindOfClass:[NSString class]] 
        	&& [[aGroupName stringByTrimmingCharactersInSet:
            	[NSCharacterSet whitespaceAndNewlineCharacterSet]] length],
        @"Expecting %@ parameter to be a non-empty, visible string.",
        SP_STRINGIFY( aGroupName ) );
    
    //
    // Get settings group.
    //
    
    NSArray * const result = [self.settingsByGroupName objectForKey:aGroupName];
    
    NSAssert( 
    	!result || [result isKindOfClass:[NSArray class]],
        @"Expected the group %@ to be kind of class NSArray.",
        aGroupName );
    
    return result;
}

#pragma mark  
#pragma mark Managing Settings Groups

- (NSString *)footerTitleForSettingsGroupWithName:(NSString *)aGroupName
{
    //
    // Check parameters.
    //
    
    NSAssert(
        [aGroupName isKindOfClass:[NSString class]],
        @"Expecting %@ parameter to be kind of class NSString.",
        SP_STRINGIFY( aGroupName ) );
    
    //
    // Return footer title.
    //
    
    return self.footerTitleBySettingsGroupName[ aGroupName ];
}

- (void)setFooterTitle:(NSString *)newLocalizedTitle
	forSettingsGroupWithName:(NSString *)aGroupName
{
    //
    // Check parameters.
    //

    NSAssert(
        !newLocalizedTitle || [newLocalizedTitle isKindOfClass:[NSString class]],
        @"Expecting %@ parameter to be kind of class NSString.",
        SP_STRINGIFY( newLocalizedTitle ) );
        
    NSAssert(
        [aGroupName isKindOfClass:[NSString class]],
        @"Expecting %@ parameter to be kind of class NSString.",
        SP_STRINGIFY( aGroupName ) );
    
    //
    // Check state.
    //
    
    NSString * const currentTitle = 
    	self.footerTitleBySettingsGroupName[ aGroupName ];
    
    if ( 
        currentTitle == newLocalizedTitle
            || [newLocalizedTitle isEqualToString:currentTitle]
    ){
        return;
    }
    
    //
    // Set new footer title.
    //
    
    if ( newLocalizedTitle )
    {
        [self.footerTitleBySettingsGroupNameLazy
            setObject:newLocalizedTitle
            forKey:aGroupName];
    }
    else
    {
        [self.footerTitleBySettingsGroupName removeObjectForKey:aGroupName];
    }
    
    [self scheduleReload];
}

#pragma mark  
#pragma mark  
#pragma mark Method Overrides -

#pragma mark  
#pragma mark UIViewController: Managing the View

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.navigationItem.rightBarButtonItem = self.doneButtonItem;
}

#pragma mark  
#pragma mark  
#pragma mark Protocol Methods -

#pragma mark  
#pragma mark UITableViewDelegate: Configuring a Table View


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [self.groupNamesOrderedLazy count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView 
	cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //
    // Get a cell.
    //
    
    SPSettingsTableViewCell *cell = [self.tableView 
    	dequeueReusableCellWithIdentifier:SPSettingsTableViewCellIdentifier];
    
    NSAssert( 
    	!cell || [cell isKindOfClass:[SPSettingsTableViewCell class]],
        @"Expected dequeued cell to be kind of class %@.",
        NSStringFromClass( [SPSettingsTableViewCell class] ) );
    
    if ( !cell ) {
    
        cell = [[SPSettingsTableViewCell alloc] initWithReuseIdentifier:
        	SPSettingsTableViewCellIdentifier];
    }
    
    //
    // Prepare cell.
    //
    
    cell.settings = [self settingsAtIndexPath:indexPath];
    
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView 
    numberOfRowsInSection:(NSInteger)section
{
    //
    // Check parameter.
    //
    
    NSAssert(
        section < [self.groupNamesOrderedLazy count],
        @"%@ parameter is out of bounds ([0 .. %lld[).",
        SP_STRINGIFY( section ),
        (long long)[self.groupNamesOrderedLazy count] );
    
    //
    // Determine number of rows ( == number of settings in group ).
    //
    
    NSArray * const group = [self settingsInGroupWithName:
    	self.groupNamesOrderedLazy[ section ]];

    return [group count];
}

- (NSString *)tableView:(UITableView *)tableView 
	titleForFooterInSection:(NSInteger)section
{
    //
    // Check parameter.
    //
    
    NSArray * const groupNamesOrderedOfSelf = self.groupNamesOrderedLazy;
    
    NSAssert(
        [groupNamesOrderedOfSelf count] >= section,
        @"%@ parameter is out of bounds ([0 .. %lld[).",
        SP_STRINGIFY( section ),
        (long long)[groupNamesOrderedOfSelf count] );
    
    //
    // Determine footer title.
    //
    
    NSString * const groupName = groupNamesOrderedOfSelf[ section ];

    return [self footerTitleForSettingsGroupWithName:groupName];
}

- (NSString *)tableView:(UITableView *)tableView 
	titleForHeaderInSection:(NSInteger)section
{
    // NOTE: For now, we simply return the (non-localized) setting group's name.
    
    //
    // Check parameter.
    //
    
    NSArray * const groupNamesOrderedOfSelf = self.groupNamesOrderedLazy;
    
    NSAssert(
        [groupNamesOrderedOfSelf count] >= section,
        @"%@ parameter is out of bounds ([0 .. %lld[).",
        SP_STRINGIFY( section ),
        (long long)[groupNamesOrderedOfSelf count] );
    
    //
    // Determine section title.
    //
    
    NSString * const result = groupNamesOrderedOfSelf[ section ];

    return result;
}

#pragma mark  
#pragma mark UITableViewDelegate: Managing Selections

- (void)tableView:(UITableView *)tableView 
	didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //
    // Apply settings.
    //
    
    SPTestAppSettings * const settings = [self settingsAtIndexPath:indexPath];
    
    NSAssert( 
    	[settings isKindOfClass:[SPTestAppSettings class]],
        @"Expecting an existing settings object." );
    
    [settings apply];
    
    //
    // Update cells.
    //
    
    // --- Deselect selected cell.
    
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];

    //
    // --- Realise all cells' state and data.
    //
    //      NOTE: The active property might have changed of any of the settings
    //            objects.
    //
    
    NSArray * const visibleCells = [self.tableView visibleCells];
    Class const SPSettingsTableViewCellClass = [SPSettingsTableViewCell class];
    
    for ( UITableViewCell *visibleCell in visibleCells ) {
    
        if ( ![visibleCell isKindOfClass:SPSettingsTableViewCellClass] ) {
        
            continue;
        
        }
        
        [(SPSettingsTableViewCell *)visibleCell realizeStateAndData];
    }
    
}

- (NSIndexPath *)tableView:(UITableView *)tableView 
	willSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //
    // Determine row to select.
    //
    
    SPTestAppSettings * const settings = [self settingsAtIndexPath:indexPath];
    
    NSAssert( 
    	[settings isKindOfClass:[SPTestAppSettings class]],
        @"Expecting an existing settings object." );
    
    return settings.available
        ? indexPath
        : nil;
}

#pragma mark  
#pragma mark  
#pragma mark Private Methods -

#pragma mark  
#pragma mark Actions

- (IBAction)dismiss:(id)sender
{
    [self.presentingViewController 
    	dismissViewControllerAnimated:YES 
        completion:nil];
}

#pragma mark  
#pragma mark Reloading Table Data

- (void)scheduleReload
{
    //
    // Check state.
    //
    
    if ( self.didScheduleReload ) {
    
        return;
    
    }
    
    //
    // Schedule reload.
    //
    
    self.didScheduleReload = YES;
    
    SP_WEAK_SELF();
    
    dispatch_async( dispatch_get_main_queue(), ^( void ) {
         
         SP_STRONG_SELF_RETURN_IF_NIL();

         strongSelf.didScheduleReload = NO;
         
         [strongSelf.tableView reloadData];
         
    });
}

@end

#pragma mark  

