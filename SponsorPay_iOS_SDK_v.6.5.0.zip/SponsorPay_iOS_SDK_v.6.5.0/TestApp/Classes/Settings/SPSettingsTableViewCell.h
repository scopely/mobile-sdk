//
//  SPSettingsTableViewCell.h
//  SponsorPayTestApp
//
//  Created by Pierre Bongen on 27.05.14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>



@class SPTestAppSettings;



#pragma mark  

@interface SPSettingsTableViewCell : UITableViewCell

#pragma mark  
#pragma mark Public Properties -

#pragma mark  
#pragma mark Cell Data

@property ( nonatomic, strong ) SPTestAppSettings *settings;

#pragma mark  
#pragma mark Public Methods -

#pragma mark  
#pragma mark Initialisation

- (instancetype)init;

//!Designated initialiser.
- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier;

#pragma mark  
#pragma mark Realising Cell State and Data

/*!
    \brief Realises the cell's state and its associated date.
    
    This method will check the cell's state and data to identify entities that
    need to be updated (texts, colours, accessories etc.). If identified the
    entity will be updated so that it reflects the cell's state and data.
*/
- (void)realizeStateAndData;

@end

#pragma mark  
