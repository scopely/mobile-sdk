//
//  SPDictionaryBasedSettings.h
//  SponsorPayTestApp
//
//  Created by Pierre Bongen on 26.05.14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import "SPTestAppSettings.h"



#pragma mark  

/*!
    \brief Class encapsulating settings stored as a dictionary of values with
        key-paths as keys.
    \remarks If there is need for other kinds of encapsulations (e.g. block-
        based) this class should be broken into two parts: base class (with
        name, description, states) and the concrete class (dictionary-based
        settings). The methods of the group "Applying Setting" would be abstract
        methods in the base class.
*/
@interface SPDictionaryBasedSettings : SPTestAppSettings

#pragma mark  
#pragma mark Public Properties -

#pragma mark  
#pragma mark Target

//!The target of the settings. May be nil if there is no target available.
@property ( nonatomic, strong, readonly ) id target;

#pragma mark  
#pragma mark Settings

@property ( nonatomic, copy, readonly ) NSDictionary *settingsValues;

#pragma mark  
#pragma mark State

//!If the receiver is found to be active this property is set to YES.
@property ( nonatomic, assign, readonly, getter = isActive ) BOOL active;

//!Returns if the setting is available and thereby can be applied. 
@property ( nonatomic, assign, readonly, getter = isAvailable ) BOOL available;

#pragma mark  
#pragma mark  
#pragma mark Public Methods -

#pragma mark  
#pragma mark Initialisation

- (instancetype)initWithName:(NSString *)aLocalizedName
    description:(NSString *)aLocalizedDescription
    values:(NSDictionary *)someValues
    forTarget:(id)aTarget;


/*!
    \brief Creates a dictionary-based settings object.
    \param aLocalizedName The localized name of the settings.
    \param aLocalizedDescription A brief, localized description of the settings (e.g.
        what it does, when to use etc.).
    \param someValues The values part of the settings. Their keys are key-paths
        which are used to set the corresponding properties on the target given
        with the aTarget parameter.
    \param aTarget The target of the settings. May be nil if the target is not
        available. A reason for that might be if the network/SDK has not been
        initialised. Though such settings have no effect, they still might be
        regarded useful (e.g. for displaying disabled table view cells so that
        the settings are known to exist).
    \return The dictionary-based settings.
*/
+ (instancetype)settingsWithName:(NSString *)aLocalizedName
    description:(NSString *)aLocalizedDescription
    values:(NSDictionary *)someValues
    forTarget:(id)aTarget;
    
@end

#pragma mark  
