//
//  SPActionIdValidatorTest.m
//  SponsorPaySample
//
//  Created by David Davila on 12/6/12.
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import "SPActionIdValidatorTest.h"
#import "SPActionIdValidator.h"

@implementation SPActionIdValidatorTest{
    NSString *lastReasonForInvalidActionId;
    BOOL valid;
}

- (void)setUp
{
    [super setUp];
    lastReasonForInvalidActionId = nil;
}

- (void)tearDown
{
    [lastReasonForInvalidActionId release];
    [super tearDown];
}

- (void)testNilActionIdInvalid
{
    valid = [SPActionIdValidator validate:nil reasonForInvalid:&lastReasonForInvalidActionId];
    STAssertEquals(valid, NO, @"");
}

- (void)testEmptyActionIdInvalid
{
    valid = [SPActionIdValidator validate:@"" reasonForInvalid:&lastReasonForInvalidActionId];
    STAssertEquals(valid, NO, @"");
}

- (void)testEmptyWhitespaceActionInvalid
{
    valid = [SPActionIdValidator validate:@"        " reasonForInvalid:&lastReasonForInvalidActionId];
    STAssertEquals(valid, NO, @"");
}

- (void)testLowercaseContainingActionIdInvalid
{
    valid = [SPActionIdValidator validate:@"ACTION_ID_WITH_LoWERCASE" reasonForInvalid:&lastReasonForInvalidActionId];
    STAssertEquals(valid, NO, @"");
}

- (void)testSpaceContainingActionIdInvalid
{
    valid = [SPActionIdValidator validate:@"ACTION_ID_WITH SPACE" reasonForInvalid:&lastReasonForInvalidActionId];
    STAssertEquals(valid, NO, @"");
}

- (void)testForeignSymbolContainingActionIdInvalid
{
    valid = [SPActionIdValidator validate:@"ACTION-ID" reasonForInvalid:&lastReasonForInvalidActionId];
    STAssertEquals(valid, NO, @"");
}


- (void)testUppercaseActionIdValid
{
    valid = [SPActionIdValidator validate:@"NICEACTIONID" reasonForInvalid:&lastReasonForInvalidActionId];
    STAssertEquals(valid, YES, @"");
}

- (void)testUnderscoreContainingActionIdValid
{
    valid = [SPActionIdValidator validate:@"NICE_ACTION_ID" reasonForInvalid:&lastReasonForInvalidActionId];
    STAssertEquals(valid, YES, @"");
}

- (void)testNumberContainingActionIdValid
{
    valid = [SPActionIdValidator validate:@"NICEACTIONID1" reasonForInvalid:&lastReasonForInvalidActionId];
    STAssertEquals(valid, YES, @"");   
}

- (void)testNumberAndUnderscoreContainingActionIdValid
{
    valid = [SPActionIdValidator validate:@"NICE_ACTION_ID1" reasonForInvalid:&lastReasonForInvalidActionId];
    STAssertEquals(valid, YES, @"");
}


@end
