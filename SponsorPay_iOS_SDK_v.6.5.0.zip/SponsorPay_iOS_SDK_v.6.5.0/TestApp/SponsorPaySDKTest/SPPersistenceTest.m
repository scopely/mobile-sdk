//
//  SPPersistenceTest.m
//  SponsorPay iOS SDK
//
//  Created by David Davila on 7/18/12.
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import "SPPersistenceTest.h"
#import "SPPersistence.h"

// To test that values set by the old SDK will be correctly retrieved by the new one.
// This is the body of the old [SPPersistence setLatestVCSTransactionId:forAppId:userId:]
static void legacy_SetLatestVCSTransactionId(NSString *transactionId,
                                             NSString *appId,
                                             NSString *userId)
{
    static NSString *const SP_VCS_LATEST_TRANSACTION_IDS_KEY = @"SPVCSLatestTransactionIds";
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *fetchedTransactionIds = [defaults dictionaryForKey:SP_VCS_LATEST_TRANSACTION_IDS_KEY];
    NSMutableDictionary *editableTransactionIds =
    [NSMutableDictionary dictionaryWithDictionary:fetchedTransactionIds]; // TODO: test with null fetchedTransactions
    
    NSDictionary *transactionIdsForApp = [fetchedTransactionIds objectForKey:appId];
    NSMutableDictionary *editableTransactionIdsForApp =
    [NSMutableDictionary dictionaryWithDictionary:transactionIdsForApp]; // test with null
    
    [editableTransactionIdsForApp setObject:transactionId forKey:userId];
    
    [editableTransactionIds setObject:editableTransactionIdsForApp forKey:appId];
    [defaults setObject:editableTransactionIds forKey:SP_VCS_LATEST_TRANSACTION_IDS_KEY];
    [defaults synchronize];
}


@implementation SPPersistenceTest

- (void)setUp
{
    [super setUp];
    // Set-up code here.
    [SPPersistence resetAllSDKValues];
}

- (void)tearDown
{
    // Tear-down code here.    
    [super tearDown];
}

- (void)testDidAdvertiserCallbackSucceedPersistence
{
    // Test for NO after reset
    BOOL initialValue = [SPPersistence didAdvertiserCallbackSucceed];
    STAssertEquals(initialValue, NO, @"didAdvertiserCallbackSucceed should be equal to NO");
    
    // Test change to YES
    [SPPersistence setDidAdvertiserCallbackSucceed:YES];
    BOOL afterChangeValue = [SPPersistence didAdvertiserCallbackSucceed];
    STAssertEquals(afterChangeValue, YES, @"didAdvertiserCallbackSucceed should be equal to YES");
}

- (void)testChangingUDIDAccessPermissionToNOPersistsUserAnsweredAboutPermission
{
    // Test for NO after reset
    BOOL initialValue = [SPPersistence userDidAnswerAboutPermissionForSystemDeviceIdentifier];
    STAssertEquals(initialValue, NO, @"userDidAnswerAboutPermissionForSystemDeviceIdentifier should be equal to NO");
    
    // Set UDID access permissions to NO and test that userDidAnswerAboutPermissionForSystemDeviceIdentifier is set to YES
    [SPPersistence setMayAccessSystemDeviceIdentifier:NO];
    BOOL afterChangeValue = [SPPersistence userDidAnswerAboutPermissionForSystemDeviceIdentifier];
    STAssertEquals(afterChangeValue, YES, @"userDidAnswerAboutPermissionForSystemDeviceIdentifier should be equal to YES after setting UDID access permissions");
}

- (void)testChangingUDIDAccessPermissionToYESPersistsUserAnsweredAboutPermission
{
    // Test for NO after reset
    BOOL initialValue = [SPPersistence userDidAnswerAboutPermissionForSystemDeviceIdentifier];
    STAssertEquals(initialValue, NO, @"userDidAnswerAboutPermissionForSystemDeviceIdentifier should be equal to NO");
    
    // Set UDID access permissions to NO and test that userDidAnswerAboutPermissionForSystemDeviceIdentifier is set to YES
    [SPPersistence setMayAccessSystemDeviceIdentifier:YES];
    BOOL afterChangeValue = [SPPersistence userDidAnswerAboutPermissionForSystemDeviceIdentifier];
    STAssertEquals(afterChangeValue, YES, @"userDidAnswerAboutPermissionForSystemDeviceIdentifier should be equal to YES after setting UDID access permissions");
}

- (void)testChangingUDIDAccessPermissionToNO
{
    // Test for NO after reset
    BOOL initialValue = [SPPersistence mayAccessSystemDeviceIdentifier];
    STAssertEquals(initialValue, NO, @"UDID access permission should be equal to NO");
    
    // Test set to NO
    [SPPersistence setMayAccessSystemDeviceIdentifier:NO];
    BOOL afterSetValue = [SPPersistence mayAccessSystemDeviceIdentifier];
    STAssertEquals(afterSetValue, NO, @"UDID access permission should be equal to NO");
}

- (void)testChangingUDIDAccessPermissionToYES
{
    // Test for NO after reset
    BOOL initialValue = [SPPersistence mayAccessSystemDeviceIdentifier];
    STAssertEquals(initialValue, NO, @"UDID access permission should be equal to NO");
    
    // Test set to YES
    [SPPersistence setMayAccessSystemDeviceIdentifier:YES];
    BOOL afterSetValue = [SPPersistence mayAccessSystemDeviceIdentifier];
    STAssertEquals(afterSetValue, YES, @"UDID access permission should be equal to YES");
}

- (void)testSettingMultipleLatestTransactionIds
{
#define APP_ID_1 @"1273"
#define USER_ID_1 @"userTester1"
#define LTID_1 @"6192384"

#define APP_ID_2 @"3172"
#define USER_ID_2 @"testerUZDA4"
#define LTID_2 @"7178943"
    
#define NO_TRANSACTION @"NO_TRANSACTION"
    
    // Test for nil after reset
    NSString *initialValue1 =
    [SPPersistence latestVCSTransactionIdForAppId:APP_ID_1 userId:USER_ID_1 noTransactionValue:NO_TRANSACTION];
    STAssertTrue([initialValue1 isEqualToString:NO_TRANSACTION],
                 @"Non set transaction ID value should be %@ after reset",
                 NO_TRANSACTION);
    
    NSString *initialValue2 =
    [SPPersistence latestVCSTransactionIdForAppId:APP_ID_1 userId:USER_ID_1 noTransactionValue:NO_TRANSACTION];
    STAssertTrue([initialValue2 isEqualToString:NO_TRANSACTION],
                 @"Non set transaction ID value should be %@ after reset",
                 NO_TRANSACTION);
    
    // Set transaction IDs
    [SPPersistence setLatestVCSTransactionId:LTID_1 forAppId:APP_ID_1 userId:USER_ID_1];
    NSString *afterSetValue1 =
    [SPPersistence latestVCSTransactionIdForAppId:APP_ID_1 userId:USER_ID_1 noTransactionValue:NO_TRANSACTION];
    STAssertTrue([afterSetValue1 isEqualToString:LTID_1],
                 @"Set transaction id for the first time for app ID %@ and user ID %@", APP_ID_1, USER_ID_1);
    
    
    [SPPersistence setLatestVCSTransactionId:LTID_2 forAppId:APP_ID_2 userId:USER_ID_2];
    NSString *afterSetValue2 =
    [SPPersistence latestVCSTransactionIdForAppId:APP_ID_2 userId:USER_ID_2 noTransactionValue:NO_TRANSACTION];
    STAssertTrue([afterSetValue2 isEqualToString:LTID_2],
                 @"Set transaction id for the first time for app ID %@ and user ID %@", APP_ID_2, USER_ID_2);
    
    // Modify (swap) transaction IDs
    [SPPersistence setLatestVCSTransactionId:LTID_2 forAppId:APP_ID_1 userId:USER_ID_1];
    NSString *afterSwapValue1 =
    [SPPersistence latestVCSTransactionIdForAppId:APP_ID_1 userId:USER_ID_1 noTransactionValue:NO_TRANSACTION];
    STAssertTrue([afterSwapValue1 isEqualToString:LTID_2],
                  @"Modified transaction ID for app ID %@ and user ID %@", APP_ID_1, USER_ID_1);
    
    [SPPersistence setLatestVCSTransactionId:LTID_1 forAppId:APP_ID_2 userId:USER_ID_2];
    NSString *afterSwapValue2 =
    [SPPersistence latestVCSTransactionIdForAppId:APP_ID_2 userId:USER_ID_2 noTransactionValue:NO_TRANSACTION];
    STAssertTrue([afterSwapValue2 isEqualToString:LTID_1],
                 @"Modified transaction ID for app ID %@ and user ID %@", APP_ID_2, USER_ID_2);
    
}

- (void)testSettingRetrievingMultipleNestedValues
{
    static NSString *const PersistenceKey = @"TestSettingRetrievingMultipleNestedValuesPersistenceKey";
    
    // Clean up defaults related to this PersistenceKey which is used only on this test
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults removeObjectForKey:PersistenceKey];
    [defaults synchronize];
    
    NSArray *const NestedKeys1 = @[@"first", @"secondA", @"thirdA", @"fourthA", @"fifthA"];
    static NSString *const NestedValue1 = @"StashOne";

    NSArray *const NestedKeys2 = @[@"first", @"secondB", @"thirdA", @"fourthB"];
    static NSString *const NestedValue2 = @"StashTwo";
    
    static NSString *const DefaultValue = @"DefaultNestedValue";
    
    // Test for nil after reset
    NSString *initialValue1 = [SPPersistence nestedValueWithPersistenceKey:PersistenceKey
                                                                nestedKeys:NestedKeys1
                                                         defaultingToValue:DefaultValue];
    STAssertTrue([initialValue1 isEqualToString:DefaultValue], @"Retrieved nested value should have default value after reset");
    
    NSString *initialValue2 = [SPPersistence nestedValueWithPersistenceKey:PersistenceKey
                                                                nestedKeys:NestedKeys2
                                                         defaultingToValue:DefaultValue];
    STAssertTrue([initialValue2 isEqualToString:DefaultValue], @"Retrieved nested value should have default value after reset");

    // Set nested values
    [SPPersistence setNestedValue:NestedValue1 forPersistenceKey:PersistenceKey nestedKeys:NestedKeys1];
    [SPPersistence setNestedValue:NestedValue2 forPersistenceKey:PersistenceKey nestedKeys:NestedKeys2];
    
    // Retrieve nested values
    NSString *afterSetvalue1 = [SPPersistence nestedValueWithPersistenceKey:PersistenceKey
                                                                 nestedKeys:NestedKeys1
                                                          defaultingToValue:DefaultValue];
    STAssertTrue([afterSetvalue1 isEqualToString:NestedValue1], @"Expected value %@ for nested keys %@", NestedValue1, NestedKeys1);
    
    NSString *afterSetvalue2 = [SPPersistence nestedValueWithPersistenceKey:PersistenceKey
                                                                 nestedKeys:NestedKeys2
                                                          defaultingToValue:DefaultValue];
    STAssertTrue([afterSetvalue2 isEqualToString:NestedValue2], @"Expected value %@ for nested keys %@", NestedValue2, NestedKeys2);
    
    
    // Modify (swap) nested values
    [SPPersistence setNestedValue:NestedValue2 forPersistenceKey:PersistenceKey nestedKeys:NestedKeys1];
    [SPPersistence setNestedValue:NestedValue1 forPersistenceKey:PersistenceKey nestedKeys:NestedKeys2];

    // Retrieve swapped values
    NSString *afterSwapValue1 = [SPPersistence nestedValueWithPersistenceKey:PersistenceKey
                                                                 nestedKeys:NestedKeys1
                                                          defaultingToValue:DefaultValue];
    STAssertTrue([afterSwapValue1 isEqualToString:NestedValue2], @"Expected value %@ for nested keys %@", NestedValue2, NestedKeys1);
    
    NSString *afterSwapValue2 = [SPPersistence nestedValueWithPersistenceKey:PersistenceKey
                                                                 nestedKeys:NestedKeys2
                                                          defaultingToValue:DefaultValue];
    STAssertTrue([afterSwapValue2 isEqualToString:NestedValue1], @"Expected value %@ for nested keys %@", NestedValue1, NestedKeys2);

}

- (void)testNewTransactionIdGetterReadsOldTransactionIdSetter
{
#define APP_ID_1 @"1273"
#define USER_ID_1 @"userTester1"
#define LTID_1 @"6192384"
    
#define APP_ID_2 @"3172"
#define USER_ID_2 @"testerUZDA4"
#define LTID_2 @"7178943"
    
    // Test for nil after reset
    NSString *initialValue1 =
    [SPPersistence latestVCSTransactionIdForAppId:APP_ID_1 userId:USER_ID_1 noTransactionValue:NO_TRANSACTION];
    STAssertTrue([initialValue1 isEqualToString:NO_TRANSACTION],
                 @"Non set transaction ID value should be %@ after reset",
                 NO_TRANSACTION);
    
    NSString *initialValue2 =
    [SPPersistence latestVCSTransactionIdForAppId:APP_ID_1 userId:USER_ID_1 noTransactionValue:NO_TRANSACTION];
    STAssertTrue([initialValue2 isEqualToString:NO_TRANSACTION],
                 @"Non set transaction ID value should be %@ after reset",
                 NO_TRANSACTION);
    
    // Set transaction IDs
    legacy_SetLatestVCSTransactionId(LTID_1, APP_ID_1, USER_ID_1);
    NSString *afterSetValue1 =
    [SPPersistence latestVCSTransactionIdForAppId:APP_ID_1 userId:USER_ID_1 noTransactionValue:NO_TRANSACTION];
    STAssertTrue([afterSetValue1 isEqualToString:LTID_1],
                 @"Set transaction id for the first time for app ID %@ and user ID %@", APP_ID_1, USER_ID_1);
    
    
    legacy_SetLatestVCSTransactionId(LTID_2, APP_ID_2, USER_ID_2);
    NSString *afterSetValue2 =
    [SPPersistence latestVCSTransactionIdForAppId:APP_ID_2 userId:USER_ID_2 noTransactionValue:NO_TRANSACTION];
    STAssertTrue([afterSetValue2 isEqualToString:LTID_2],
                 @"Set transaction id for the first time for app ID %@ and user ID %@", APP_ID_2, USER_ID_2);
    
    // Modify (swap) transaction IDs
    legacy_SetLatestVCSTransactionId(LTID_2, APP_ID_1, USER_ID_1);
    NSString *afterSwapValue1 =
    [SPPersistence latestVCSTransactionIdForAppId:APP_ID_1 userId:USER_ID_1 noTransactionValue:NO_TRANSACTION];
    STAssertTrue([afterSwapValue1 isEqualToString:LTID_2],
                 @"Modified transaction ID for app ID %@ and user ID %@", APP_ID_1, USER_ID_1);
    
    legacy_SetLatestVCSTransactionId(LTID_1, APP_ID_2, USER_ID_2);
    NSString *afterSwapValue2 =
    [SPPersistence latestVCSTransactionIdForAppId:APP_ID_2 userId:USER_ID_2 noTransactionValue:NO_TRANSACTION];
    STAssertTrue([afterSwapValue2 isEqualToString:LTID_1],
                 @"Modified transaction ID for app ID %@ and user ID %@", APP_ID_2, USER_ID_2);
}

- (void)testBooleanNestedValues
{
    static NSString *const PersistenceKey = @"TestBooleanNestedValuesPersistenceKey";
    
    // Clean up defaults related to this PersistenceKey which is used only on this test
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults removeObjectForKey:PersistenceKey];
    [defaults synchronize];
    
    NSArray *const NestedKeys1 = @[@"first", @"secondA", @"thirdA", @"fourthA", @"fifthA"];
    NSArray *const NestedKeys2 = @[@"first", @"secondB", @"thirdA", @"fourthB"];
    NSNumber *const boxedYES = [NSNumber numberWithBool:YES];
    NSNumber *const boxedNO = [NSNumber numberWithBool:NO];
    NSNumber *const NestedValue1 = boxedYES;
    NSNumber *const NestedValue2 = boxedNO;
    
    NSNumber *const DefaultValue = boxedNO;
    
    // Test for nil after reset
    NSNumber *initialValue1 = [SPPersistence nestedValueWithPersistenceKey:PersistenceKey
                                                                nestedKeys:NestedKeys1
                                                         defaultingToValue:DefaultValue];
    STAssertTrue([initialValue1 isEqualToNumber:DefaultValue], @"Retrieved nested value should have default value after reset");
    
    NSNumber *initialValue2 = [SPPersistence nestedValueWithPersistenceKey:PersistenceKey
                                                                nestedKeys:NestedKeys2
                                                         defaultingToValue:DefaultValue];
    STAssertTrue([initialValue2 isEqualToNumber:DefaultValue], @"Retrieved nested value should have default value after reset");
    
    // Set nested values
    [SPPersistence setNestedValue:NestedValue1 forPersistenceKey:PersistenceKey nestedKeys:NestedKeys1];
    [SPPersistence setNestedValue:NestedValue2 forPersistenceKey:PersistenceKey nestedKeys:NestedKeys2];
    
    // Retrieve nested values
    NSNumber *afterSetvalue1 = [SPPersistence nestedValueWithPersistenceKey:PersistenceKey
                                                                 nestedKeys:NestedKeys1
                                                          defaultingToValue:DefaultValue];
    STAssertTrue([afterSetvalue1 isEqualToNumber:NestedValue1], @"Expected value %@ for nested keys %@", NestedValue1, NestedKeys1);
    
    NSNumber *afterSetvalue2 = [SPPersistence nestedValueWithPersistenceKey:PersistenceKey
                                                                 nestedKeys:NestedKeys2
                                                          defaultingToValue:DefaultValue];
    STAssertTrue([afterSetvalue2 isEqualToNumber:NestedValue2], @"Expected value %@ for nested keys %@", NestedValue2, NestedKeys2);
    
    
    // Modify (swap) nested values
    [SPPersistence setNestedValue:NestedValue2 forPersistenceKey:PersistenceKey nestedKeys:NestedKeys1];
    [SPPersistence setNestedValue:NestedValue1 forPersistenceKey:PersistenceKey nestedKeys:NestedKeys2];
    
    // Retrieve swapped values
    NSNumber *afterSwapValue1 = [SPPersistence nestedValueWithPersistenceKey:PersistenceKey
                                                                  nestedKeys:NestedKeys1
                                                           defaultingToValue:DefaultValue];
    STAssertTrue([afterSwapValue1 isEqualToNumber:NestedValue2], @"Expected value %@ for nested keys %@", NestedValue2, NestedKeys1);
    
    NSNumber *afterSwapValue2 = [SPPersistence nestedValueWithPersistenceKey:PersistenceKey
                                                                  nestedKeys:NestedKeys2
                                                           defaultingToValue:DefaultValue];
    STAssertTrue([afterSwapValue2 isEqualToNumber:NestedValue1], @"Expected value %@ for nested keys %@", NestedValue1, NestedKeys2);
    
}

- (void)testActionCallbackPersistence
{
    static NSString *const ActionID1 = @"ACTION_ID_1";
    static const BOOL SuccessStatus1 = YES;
    
    static NSString *const ActionID2 = @"ACTION_ID_2";
    static const BOOL SuccessStatus2 = YES;

    BOOL mustBeNO = YES, mustBeSuccessStatus1 = !SuccessStatus1, mustBeSuccessStatus2 = !SuccessStatus2;

    // Test for NO after reset
    mustBeNO = [SPPersistence didActionCallbackSucceedForActionId:ActionID1];
    STAssertEquals(mustBeNO, NO, @"After reset value of action callback success should be NO");
    mustBeNO = [SPPersistence didActionCallbackSucceedForActionId:ActionID2];
    STAssertEquals(mustBeNO, NO, @"After reset value of action callback success should be NO");

    // Set values
    [SPPersistence setDidActionCallbackSucceed:SuccessStatus1 forActionId:ActionID1];
    mustBeSuccessStatus1 = [SPPersistence didActionCallbackSucceedForActionId:ActionID1];
    STAssertEquals(mustBeSuccessStatus1, SuccessStatus1, @"Set and read action callback status values don't match");
    
    // Second action ID not interfered by first
    mustBeNO = [SPPersistence didActionCallbackSucceedForActionId:ActionID2];
    STAssertEquals(mustBeNO, NO, @"Second action ID success must not be interfered by first");

    [SPPersistence setDidActionCallbackSucceed:SuccessStatus2 forActionId:ActionID2];
    mustBeSuccessStatus2 = [SPPersistence didActionCallbackSucceedForActionId:ActionID2];
    STAssertEquals(mustBeSuccessStatus2, SuccessStatus2, @"Set and read action callback status values don't match");
    
    // Swap values
    [SPPersistence setDidActionCallbackSucceed:SuccessStatus2 forActionId:ActionID1];
    mustBeSuccessStatus2 = [SPPersistence didActionCallbackSucceedForActionId:ActionID1];
    STAssertEquals(mustBeSuccessStatus2, SuccessStatus2, @"Set and read action callback status values don't match");
    
    [SPPersistence setDidActionCallbackSucceed:SuccessStatus1 forActionId:ActionID2];
    mustBeSuccessStatus1 = [SPPersistence didActionCallbackSucceedForActionId:ActionID2];
    STAssertEquals(mustBeSuccessStatus1, SuccessStatus1, @"Set and read action callback status values don't match");
}
@end
