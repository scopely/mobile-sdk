//
//  SPvirtualCurrencyServerConnectorTest.m
//  SponsorPaySample
//
//  Created by David on 10/16/12.
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import "SPvirtualCurrencyServerConnectorTest.h"

@interface SPvirtualCurrencyServerConnectorTest()

@property (nonatomic, retain) NSMutableSet *pendingVCSConnections;

@end

@implementation SPvirtualCurrencyServerConnectorTest

@synthesize pendingVCSConnections;

BOOL waitForDelegate = YES;

- (void)testMemoryManagement
{
    SPVirtualCurrencyServerConnector *connector = [[SPVirtualCurrencyServerConnector alloc]
                                                   initWithUserId:@"tester" appId:@"1245" secretToken:@"888"];
    connector.delegate = self;
    connector.shouldLogVerbosely = YES;
    
    [self.pendingVCSConnections addObject:connector];

    [connector fetchDeltaOfCoins];

    [connector release];
    
    while (waitForDelegate) {
        [[NSRunLoop currentRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:1]];
    }
    
    [self.pendingVCSConnections removeAllObjects];
    
    [[NSRunLoop currentRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:2]];
    
}

- (void)virtualCurrencyConnector:(SPVirtualCurrencyServerConnector *)connector
  didReceiveDeltaOfCoinsResponse:(double)deltaOfCoins
             latestTransactionId:(NSString *)transactionId
{
    NSLog(@"delegate receive response");
    waitForDelegate = NO;
}


- (void)virtualCurrencyConnector:(SPVirtualCurrencyServerConnector *)connector
                 failedWithError:(SPVirtualCurrencyRequestErrorType)error
                       errorCode:(NSString *)errorCode
                    errorMessage:(NSString *)errorMessage
{
    NSLog(@"delegate receive response");
    waitForDelegate = NO;

}



@end
