//
//  SPvirtualCurrencyServerConnectorTest.h
//  SponsorPaySample
//
//  Created by David on 10/16/12.
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>
#import "SPVirtualCurrencyServerConnector.h"

@interface SPvirtualCurrencyServerConnectorTest : SenTestCase <SPVirtualCurrencyConnectionDelegate> {
    @private
    NSMutableSet *pendingVCSConnections;
}

@end
