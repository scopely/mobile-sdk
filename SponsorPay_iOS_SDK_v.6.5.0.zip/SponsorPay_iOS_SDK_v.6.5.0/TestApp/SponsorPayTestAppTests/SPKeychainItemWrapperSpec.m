//
//  SPKeychainItemWrapperSpec.m
//  SponsorPayTestApp
//
//  Created by Piotr  on 01/07/14.
//  Copyright 2014 SponsorPay. All rights reserved.
//

#import "Specta.h"
#define EXP_SHORTHAND
#import <Expecta/Expecta.h>

#import "SPKeychainItemWrapper.h"

SpecBegin(SPKeychainItemWrapper)

// Test for checking functionality of the keychain
// The following test are performed:
// 1. Chck the data is added to keychain
// 2. Enter new data for the same identifier in keychain and check it was replaced
// 3. Check data return from keychain is NSString type
// 4. Remove data completely from keychain and verify

describe(@"SPKeychainItemWrapper adding values to keychain", ^{
    
    __block SPKeychainItemWrapper *keychainWrapper;
    __block NSString *adapter;
    __block NSString *key;
    __block NSString *secret1;
    
    beforeAll(^{
        adapter = @"InMobi";
        key = @"SPInMobiAppId";
        keychainWrapper = [[SPKeychainItemWrapper alloc] initWithAdapter:adapter key:key accessGroup:nil]; // Apps that are built for the simulator aren't signed, so there's no keychain access group
        secret1 = @"9e09f722cfd04cc09e38366c8fa3a4a0";
        [keychainWrapper setObject:secret1 forKey:(__bridge id)kSecValueData];
    });
    
    it(@"SPKeychainItemWrapper add value to keychain and verify", ^{
        NSString *secret = [keychainWrapper objectForKey:(__bridge id)kSecValueData];
        // Secret returned from keychain should not be nil
        expect(secret).notTo.beNil;
        
        // Expect data type to be NSString
        expect(secret).to.beKindOf([NSString class]);
        
        // Value should be equal to secret1
        expect(secret).to.equal(secret1);
    });
    
    describe(@"SPKeychainItemWrapper replace secret", ^{
        __block SPKeychainItemWrapper *keychainWrapper2;
        __block NSString *secret2;
        
        beforeAll(^{
            keychainWrapper2 = [[SPKeychainItemWrapper alloc] initWithAdapter:adapter key:key accessGroup:nil]; // Apps that are built for the simulator aren't signed, so there's no keychain access group
            secret2 = @"89f9355dfe232ea03d76caada788a10d";
            [keychainWrapper setObject:secret2 forKey:(__bridge id)kSecValueData];
        });
        
        
        it(@"SPKeychainItemWrapper replace value in keychain and verify", ^{
            NSString *secret = [keychainWrapper objectForKey:(__bridge id)kSecValueData];
            // Secret returned from keychain should not be nil
            expect(secret).notTo.beNil;
            
            // Expect data type to be NSString
            expect(secret).to.beKindOf([NSString class]);
            
            // Value should not be equal to secret1
            expect(secret).notTo.equal(secret1);
        });
        
        it(@"SPKeychainItemWrapper remove secret", ^{
            [keychainWrapper2 resetKeychainItem];
            
            NSString *secret = [keychainWrapper2 objectForKey:(__bridge id)kSecValueData];
            // Expect returned data to be empty
            expect(secret).to.equal(@"");
        });
    });
    
    afterAll(^{
        keychainWrapper = nil;
        adapter = nil;
        key = nil;
    });
});

SpecEnd
