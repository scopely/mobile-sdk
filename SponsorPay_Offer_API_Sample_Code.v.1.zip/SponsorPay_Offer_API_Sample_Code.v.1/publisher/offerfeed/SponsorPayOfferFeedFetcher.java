/**
 * SponsorPay Android SDK
 *
 * Copyright 2012 SponsorPay. All rights reserved.
 */

package com.sponsorpay.sdk.android.publisher.offerfeed;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;

import android.content.Context;
import android.util.Log;

import com.sponsorpay.sdk.android.HostInfo;
import com.sponsorpay.sdk.android.SignatureTools;
import com.sponsorpay.sdk.android.publisher.AbstractConnector;
import com.sponsorpay.sdk.android.publisher.AbstractResponse;
import com.sponsorpay.sdk.android.publisher.AbstractResponse.RequestErrorType;
import com.sponsorpay.sdk.android.publisher.AsyncRequest;
import com.sponsorpay.sdk.android.publisher.offerfeed.OfferFeedResponse.SponsorPayOfferFeedRequestListener;

/**
 * Retrieves and parses the SponsorPay's offer feed, returning a list of offers that can be
 * displayed to the user.
 */
public class SponsorPayOfferFeedFetcher extends AbstractConnector implements
		SponsorPayOfferFeedRequestListener {
	private static final String SP_OFFER_FEED_BASE_URL = "http://api.sponsorpay.com/feed/v1/offers.json";

	/**
	 * User's code will be notified asynchronously when the offers are fetched by a registered
	 * listener implementing the {@link SponsorPayOfferFeedRequestListener} interface.
	 */
	private SponsorPayOfferFeedRequestListener mUserListener;

	/**
	 * Private constructor.
	 * 
	 * @param context
	 *            Android application context.
	 * @param userId
	 *            Unique user ID
	 * @param userListener
	 *            Listener provided by the user code to be notified when offers are retrieved.
	 * @param hostInfo
	 *            Contains data about the host device and application.
	 * @param securityToken
	 *            Security token to validate requests and responses to and from the SponsorPay's
	 *            backend.
	 */
	private SponsorPayOfferFeedFetcher(Context context, String userId,
			SponsorPayOfferFeedRequestListener userListener, HostInfo hostInfo, String securityToken) {
		super(context, userId, hostInfo, securityToken);

		mUserListener = userListener;
	}

	/**
	 * Sends the request for the offer feed. Returns immediately, the results will be delivered to
	 * the registered listener.
	 */
	private void startLoadingOffers() {
		// Create a dictionary of the parameters which will be sent on this request. Add
		// all of them except the hash
		HashMap<String, String> requestParams = new HashMap<String, String>();
		requestParams.put("appid", mHostInfo.getAppId());
		requestParams.put("uid", mUserId);
		requestParams.put("locale", Locale.getDefault().getLanguage());
		requestParams.put("device_id", mHostInfo.getUDID());
		requestParams.put("timestamp", getCurrentUnixTimestampAsString());
		requestParams.put("android_id", mHostInfo.getAndroidId());
		// requestParams.put("offer_types", "101");

		String signature = SignatureTools.generateSignatureForParameters(requestParams,
				mSecurityToken);

		// Now add the hash
		requestParams.put("hashkey", signature);

		List<NameValuePair> params = new ArrayList<NameValuePair>();
		for (Entry<String, String> entry : requestParams.entrySet()) {
			String value = entry.getValue();
			params.add(new BasicNameValuePair(entry.getKey(), value));
		}
		
		String requestUrl = SP_OFFER_FEED_BASE_URL + "?" + URLEncodedUtils.format(params, "UTF-8");

		Log.d(getClass().getSimpleName(), "Offer feed request url: " + requestUrl);

		AsyncRequest requestTask = new AsyncRequest(requestUrl, this);
		requestTask.execute();
	}

	@Override
	public void onAsyncRequestComplete(AsyncRequest request) {
		OfferFeedResponse response = new OfferFeedResponse();
		if (request.didRequestThrowError()) {
			response.setErrorType(RequestErrorType.ERROR_NO_INTERNET_CONNECTION);
		} else {
			response.setResponseData(request.getHttpStatusCode(), request.getResponseBody(),
					request.getResponseSignature());
		}

		response.setResponseListener(this);
		response.parseAndCallListener(mSecurityToken);
	}

	@Override
	public void onSponsorPayOfferFeedFetched(OfferFeedResponse response) {
		mUserListener.onSponsorPayOfferFeedFetched(response);
	}

	@Override
	public void onSponsorPayOfferFeedFetchError(AbstractResponse response) {
		mUserListener.onSponsorPayOfferFeedFetchError(response);
	}

	private static OfferFeedResponse lastSuccessfulResponse;
	private static AbstractResponse lastErrorResponse;
	private static boolean waitingForResponse = false;
	private static Set<SponsorPayOfferFeedRequestListener> waitingUserListeners;

	private static Set<SponsorPayOfferFeedRequestListener> getWaitingUserListeners() {
		if (waitingUserListeners == null) {
			waitingUserListeners = new HashSet<OfferFeedResponse.SponsorPayOfferFeedRequestListener>();
		}
		return waitingUserListeners;
	}

	/**
	 * <p>
	 * Fetches the offers returned by the SponsorPay's offer feed. It always returns immediately,
	 * and the results are always communicated to the passed listener. If the preloading of the
	 * offers is complete, the listener is invoked immediately.
	 * </p>
	 * 
	 * <p>
	 * {@link #preloadOffers(Context, String, String, String)} has to be invoked at least once
	 * before invoking this method, otherwise this call has no effect.
	 * </p>
	 * 
	 * @param listener
	 */
	public static void getOffers(SponsorPayOfferFeedRequestListener listener) {
		if (lastSuccessfulResponse != null) {
			// Call the listener immediately with a successful response
			listener.onSponsorPayOfferFeedFetched(lastSuccessfulResponse);
		} else if (waitingForResponse) {
			// The listener will be called when there are results available.
			getWaitingUserListeners().add(listener);
		} else if (lastErrorResponse != null) {
			// Call the listener immediately with an erroneous response
			listener.onSponsorPayOfferFeedFetchError(lastErrorResponse);
		}
	}

	/**
	 * Starts preloading SponsorPay offers to shorten or eliminate the waiting time when they're
	 * requested via {@link #getOffers(SponsorPayOfferFeedRequestListener)}.
	 * 
	 * @param context
	 *            Android application context.
	 * @param userId
	 *            Unique user ID.
	 * @param appId
	 *            App ID.
	 * @param key
	 *            Key to verify the request and response.
	 */
	public static void preloadOffers(Context context, String userId, String appId, String key) {
		Log.d(SponsorPayOfferFeedFetcher.class.getSimpleName(), "Pre-loading SponsorPay offers");

		HostInfo hostInfo = new HostInfo(context);
		hostInfo.setOverriddenAppId(appId);

		SponsorPayOfferFeedRequestListener listener = new SponsorPayOfferFeedRequestListener() {
			@Override
			public void onSponsorPayOfferFeedFetched(OfferFeedResponse response) {
				lastSuccessfulResponse = response;
				waitingForResponse = false;
				// Notify all waiting listeners of the received response and remove them of the
				// waiting listeners set.
				for (SponsorPayOfferFeedRequestListener listener : getWaitingUserListeners()) {
					listener.onSponsorPayOfferFeedFetched(response);
					waitingUserListeners.remove(listener);
				}
			}

			@Override
			public void onSponsorPayOfferFeedFetchError(AbstractResponse response) {
				Log.e(SponsorPayOfferFeedFetcher.class.getSimpleName(),
						"onSponsorPayOfferFeedFetchError: " + response.getErrorCode() + " "
								+ response.getErrorType() + " " + response.getErrorMessage());
				lastErrorResponse = response;
				waitingForResponse = false;
				// Notify all the pending listeners of the error and remove them from the waiting
				// listeners set.
				for (SponsorPayOfferFeedRequestListener listener : getWaitingUserListeners()) {
					listener.onSponsorPayOfferFeedFetchError(response);
					waitingUserListeners.remove(listener);
				}
			}
		};

		SponsorPayOfferFeedFetcher instance = new SponsorPayOfferFeedFetcher(context, userId,
				listener, hostInfo, key);
		waitingForResponse = true;
		instance.startLoadingOffers();
	}

	/**
	 * Unregisteners a listener registered with
	 * {@link #getOffers(SponsorPayOfferFeedRequestListener)} before the results are delivered.
	 * 
	 * @param listener
	 */
	public static void unregisterListener(SponsorPayOfferFeedRequestListener listener) {
		if (getWaitingUserListeners().contains(listener))
			waitingUserListeners.remove(listener);
	}
}
