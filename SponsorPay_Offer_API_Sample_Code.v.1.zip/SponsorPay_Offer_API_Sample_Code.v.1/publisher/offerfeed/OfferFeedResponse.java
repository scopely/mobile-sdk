/**
 * SponsorPay Android SDK
 *
 * Copyright 2012 SponsorPay. All rights reserved.
 */

package com.sponsorpay.sdk.android.publisher.offerfeed;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

import com.sponsorpay.sdk.android.publisher.AbstractResponse;

/**
 * Encapsulates a response to the SponsorPay's offer feed request. Parses the received offers into
 * offer model objects.
 */
public class OfferFeedResponse extends AbstractResponse {

	private ArrayList<SponsorPayOffer> mRetrievedOffers;
	private SponsorPayOfferFeedRequestListener mResponseListener;

	@Override
	public void parseSuccessfulResponse() {
		try {
			JSONObject responseJson = new JSONObject(mResponseBody);

			JSONObject informationJson = responseJson.getJSONObject("information");
			String currencyName = informationJson.getString("virtual_currency");

			JSONArray offers = responseJson.getJSONArray("offers");

			int cntReceivedOffers = offers.length();
			mRetrievedOffers = new ArrayList<SponsorPayOffer>(cntReceivedOffers);

			Log.d(getClass().getSimpleName(), "Retrieved " + cntReceivedOffers + " offers");

			for (int i = 0; i < cntReceivedOffers; i++) {
				JSONObject thisOfferJson = offers.getJSONObject(i);

				SponsorPayOffer thisOffer = new SponsorPayOffer();

				thisOffer.currencyName = currencyName;
				thisOffer.title = thisOfferJson.getString("title");
				thisOffer.payout = thisOfferJson.getString("payout");
				thisOffer.action = thisOfferJson.getString("required_actions");
				thisOffer.link = thisOfferJson.getString("link");
				JSONObject thumbnailsJson = thisOfferJson.getJSONObject("thumbnail");
				thisOffer.lowResThumbnailUrl = thumbnailsJson != null ? thumbnailsJson
						.getString("lowres") : "";

				mRetrievedOffers.add(thisOffer);
			}
			mErrorType = RequestErrorType.NO_ERROR;
		} catch (JSONException e) {
			mErrorType = RequestErrorType.ERROR_INVALID_RESPONSE;
		}
	}

	@Override
	public void onSuccessfulResponseParsed() {
		AsyncTask<Void, Void, Void> imagesLoaderTask = new AsyncTask<Void, Void, Void>() {
			@Override
			protected Void doInBackground(Void... params) {
				for (SponsorPayOffer thisOffer : mRetrievedOffers) {
					Bitmap bm = null;
					try {
						Log.d(getClass().getSimpleName(), "Loading thumbnail for offer. URL: "
								+ thisOffer.lowResThumbnailUrl);

						URL thumbnailUrl = new URL(thisOffer.lowResThumbnailUrl);
						URLConnection thumbnailRetrievalConnection = thumbnailUrl.openConnection();
						thumbnailRetrievalConnection.connect();

						InputStream is = thumbnailRetrievalConnection.getInputStream();
						BufferedInputStream bis = new BufferedInputStream(is);
						bm = BitmapFactory.decodeStream(bis);

						thisOffer.image = bm;

						bis.close();
						is.close();

					} catch (IOException e) {
						Log.e(getClass().getName(), "Couldn't retrieve thumbnail with url: "
								+ thisOffer.lowResThumbnailUrl, e);
					}

				}
				return null;
			}

			protected void onPostExecute(Void result) {
				mResponseListener.onSponsorPayOfferFeedFetched(OfferFeedResponse.this);
			};
		};

		imagesLoaderTask.execute();
	}

	@Override
	public void onErrorTriggered() {
		mResponseListener.onSponsorPayOfferFeedFetchError(OfferFeedResponse.this);
	}

	@Override
	public boolean verifySignature(String securityToken) {
		return true;
	}

	/**
	 * Interface to be implemented by offer model objects which will provide data to be displayed on
	 * a ListView.
	 * 
	 */
	public interface CommonOfferInterface {
		String getTitle();

		String getMessage();

		Bitmap getImage();

		String getPayout();

		void accept(Activity activity);
	}

	public static class SponsorPayOffer implements CommonOfferInterface {
		String currencyName = "";
		String title = "";
		String payout = "";
		String action = "";
		String link = "";
		String lowResThumbnailUrl = "";
		Bitmap image;

		@Override
		public String getTitle() {
			return title;
		}

		@Override
		public String getMessage() {
			return String.format("%s - %s %s!", action, payout, currencyName);
		}

		@Override
		public Bitmap getImage() {
			return image;
		}

		@Override
		public String getPayout() {
			return payout;
		}

		@Override
		public void accept(Activity activity) {
			// Accepting a SponsorPay offer opens a new Intent following the offer link
			Intent followOfferLink = new Intent(Intent.ACTION_VIEW, Uri.parse(link));
			activity.startActivity(followOfferLink);
		}
	}

	void setErrorType(RequestErrorType errorType) {
		mErrorType = errorType;
	}

	void setResponseListener(SponsorPayOfferFeedRequestListener listener) {
		mResponseListener = listener;
	}

	/**
	 * Interface to be implemented by parties interested of being notified when the response to the
	 * request for the offer feed is received and parsed.
	 * 
	 */
	public interface SponsorPayOfferFeedRequestListener {
		/**
		 * Invoked when a successful response for the offer feed is received and parsed.
		 * 
		 * @param response
		 */
		void onSponsorPayOfferFeedFetched(OfferFeedResponse response);

		/**
		 * Invoked when an error is triggered by the request or response for the SponsorPay offer
		 * feed.
		 * 
		 * @param response
		 *            The type of error can be accessed by invoking
		 *            {@link AbstractResponse#getErrorType()}. Additional information about the
		 *            error can often be obtained by invoking
		 *            {@link AbstractResponse#getErrorCode()} and
		 *            {@link AbstractResponse#getErrorMessage()}
		 */
		void onSponsorPayOfferFeedFetchError(AbstractResponse response);
	}

	/**
	 * Returns a list of parsed offer model objects.
	 */
	public List<SponsorPayOffer> getOffers() {
		return mRetrievedOffers;
	}
}
