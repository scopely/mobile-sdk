//
//  SPSDKFeaturesProvider.h
//  SponsorPayTestApp
//
//  Created by Daniel Barden on 12/03/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import "SPUrlParametersProvider.h"

@interface SPSDKFeaturesProvider : NSObject <SPURLParametersProvider>

@end
