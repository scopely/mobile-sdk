//
//  SPAppiaInterstitialAdapter.m
//  SponsorPayTestApp
//
//  Created by Daniel Barden on 04/12/13.
//  Copyright (c) 2013 SponsorPay. All rights reserved.
//

#import "SPAppiaInterstitialAdapter.h"
#import "SPSystemVersionChecker.h"
#import <objc/runtime.h>
#import <AppiaSDK/Appia.h>

// Customizations for AIBannerAd
@interface SPAIBannerAd : AIBannerAd

@property (weak, nonatomic) id<SPAIBannerAdDelegate> delegate;
@end

@implementation SPAIBannerAd

- (void)presentFromMainWindow
{
    [self.delegate bannerDidAppear];
    [super presentFromMainWindow];
}

- (void)dismiss
{
    [super dismiss];
    [self.delegate bannerDidClose];
}

@end

// Adapter implementation
@interface SPAppiaInterstitialAdapter ()
{
    BOOL _shouldRestoreStatusBar;
}

@property (weak, nonatomic) id<SPInterstitialNetworkAdapterDelegate> delegate;
@property (strong, nonatomic) NSDictionary *parameters;
@property (strong, nonatomic) SPAIBannerAd *ad;

@end

@implementation SPAppiaInterstitialAdapter

# pragma mark - SPInterstitialNetworkAdapter methods
- (NSString *)networkName
{
    return @"Appia";
}

- (void)startWrappedSDK
{
    AIAppia *appia = [AIAppia sharedInstance];
    appia.siteId = _parameters[@"SPAppiaSiteId"];
}

- (BOOL)canShowInterstitial
{
    if (!self.ad) {
        AIAdParameters *adParameters = [[AIAdParameters alloc] init];
        [adParameters setAppiaParameters:@{@"placementId": self.parameters[@"SPAppiaPlacementId"]}];
        SPAIBannerAd *ad = (SPAIBannerAd *)[[AIAppia sharedInstance] createBannerAdWithSize:AIBannerAdFullScreen parameters:adParameters];
        object_setClass(ad, [SPAIBannerAd class]);
        ad.delegate = self;

        self.ad = ad;
    }
    return YES;
}

- (void)showInterstitialFromViewController:(UIViewController *)viewController
{
    if (![UIApplication sharedApplication].statusBarHidden) {
        _shouldRestoreStatusBar = YES;
        [[UIApplication sharedApplication] setStatusBarHidden:YES];
    }

    if (viewController && [SPSystemVersionChecker runningOniOS6OrNewer]) {
        [self.ad useInAppAppStoreWithViewController:viewController];
    }

    [self.ad presentFromMainWindow];
}

#pragma mark - SPAIBannerDelegate Methods
- (void)bannerDidAppear
{
    [self.delegate adapterDidShowInterstitial:self];
}

- (void)bannerDidClose
{
    [self.delegate adapter:self didDismissInterstitialWithReason:SPInterstitialDismissReasonUserClosedAd];
    if (_shouldRestoreStatusBar) {
        [[UIApplication sharedApplication] setStatusBarHidden:NO];
    }
    self.ad = nil;
}

@end
