//
//  SPAppLovingInterstitialAdapter.h
//  SponsorPayTestApp
//
//  Created by David Davila on 01/11/13.
//  Copyright (c) 2013 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SPInterstitialNetworkAdapter.h"
#import "ALSdk.h"

NSString *const SPAppLovinSDKAppKey;

@interface SPAppLovinInterstitialAdapter : NSObject <SPInterstitialNetworkAdapter, ALAdLoadDelegate, ALAdDisplayDelegate>

@end
