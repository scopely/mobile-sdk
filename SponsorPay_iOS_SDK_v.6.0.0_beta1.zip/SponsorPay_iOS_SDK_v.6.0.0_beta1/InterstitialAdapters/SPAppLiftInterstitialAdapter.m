//
//  SPAppLiftInterstitialAdapter.m
//  SponsorPayTestApp
//
//  Created by Daniel Barden on 20/11/13.
//  Copyright (c) 2013 SponsorPay. All rights reserved.
//

#import "SPAppLiftInterstitialAdapter.h"
#import "SPLogger.h"

//TODO: Define this macro inside SPLogger
#define LogInvokation NSLog(@"%s", __PRETTY_FUNCTION__)

@interface SPAppLiftInterstitialAdapter() {
    BOOL _adLoaded;
}

@property (weak, nonatomic) id<SPInterstitialNetworkAdapterDelegate> delegate;
@property (nonatomic, copy) NSString *appId;
@property (nonatomic, copy) NSString *securityToken;

@end

@implementation SPAppLiftInterstitialAdapter

#pragma mark - SPInterstitialNetworkAdapter delegate methods
- (NSString *)networkName
{
    return @"AppLift";
}

- (void)startWrappedSDK
{
    [SPLogger log:@"Starting Applift SDK version %@", [PlayAdsSDK versionString]];
    [PlayAdsSDK startPlayAdsSDKForApp:self.appId secretToken:self.securityToken delegate:self];
}

- (void)setParameters:(NSDictionary *)parameters
{
    self.appId = parameters[@"appId"];
    self.securityToken = parameters[@"securityToken"];
}

- (BOOL)canShowInterstitial
{
    LogInvokation;
    if (!_adLoaded) {
        [PlayAdsSDK prepareInterstitialWithDelegate:self];
    }

    return _adLoaded;
}

- (void)showInterstitialFromViewController:(UIViewController *)viewController
{
    LogInvokation;
    [PlayAdsSDK showPreparedInterstitial];
}

#pragma mark - AppLift delegate methods
- (void)playAdsStartDidEnd
{
    [PlayAdsSDK prepareInterstitialWithDelegate:self];
}

- (void)playAdsInterstitialReady
{
    LogInvokation;
    // The AppLift interstitial AppLiftLightViewController is not supported in the iPad when used in landscape mode. Since we can't
    // garantee that the user won't change the orientation between -[SPAppLiftInterstitialAdapter canShowInterstitial] and
    // -[SPAppLiftInterstitialAdapter showInterstitialFromViewController:], we'll disable this interstitial for the iPad.
    UIViewController *currentInterstitial = [PlayAdsSDK currentInterstitial];
    NSString *interstitialClassName = NSStringFromClass([currentInterstitial class]);
    if ([interstitialClassName isEqualToString:@"AppLiftLightViewController"] && UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        [SPLogger log:@"Discarding interstitial - AppLiftLightViewController is not supported. Fetching again"];
        [PlayAdsSDK prepareInterstitialWithDelegate:self];
    } else {
        _adLoaded = YES;
    }
}

- (void)playAdsInterstitialDidShown
{
    LogInvokation;
    _adLoaded = NO;
    [self.delegate adapterDidShowInterstitial:self];
}

- (void)playAdsInterstitialDidFailWithError:(NSError*)error
{
    LogInvokation;
    [self.delegate adapter:self didFailWithError:error];
}

- (void)playAdsInterstitialDidClose
{
    LogInvokation;
    [self.delegate adapter:self didDismissInterstitialWithReason:SPInterstitialDismissReasonUserClosedAd];
    [PlayAdsSDK prepareInterstitialWithDelegate:self];
}

@end
