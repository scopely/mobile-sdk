//
//  SPInterstitialEvent.m
//  SponsorPayTestApp
//
//  Created by Daniel Barden on 07/11/13.
//  Copyright (c) 2013 SponsorPay. All rights reserved.
//

#import "SPInterstitialEvent.h"
#import "SponsorPaySDK.h"

static NSString *const EventTypeToString[] = {
    [SPInterstitialEventTypeRequest] = @"request",
    [SPInterstitialEventTypeFill] = @"fill",
    [SPInterstitialEventTypeNoFill] = @"no_fill",
    [SPInterstitialEventTypeImpression] = @"impression",
    [SPInterstitialEventTypeClick] = @"click",
    [SPInterstitialEventTypeClose] = @"close",
    [SPInterstitialEventTypeError] = @"error",
};

@implementation SPInterstitialEvent


- (id)initWithEventType:(SPInterstitialEventType)eventType network:(NSString *)network adId:(NSString *)adId
{
    self = [super init];
    if (self) {
        self.type = eventType;
        self.network = network;
        self.adId = adId;
    }
    return self;
}

// Maps the event type to event name
- (NSString *)typeToString
{
    return EventTypeToString[self.type];
}

- (NSDictionary *)dictionaryWithKeyValueParameters
{
    NSMutableDictionary *paramDict = [[NSMutableDictionary alloc] init];
    [paramDict setValue:[self typeToString] forKey:@"event"];
    [paramDict setValue:self.adId forKey:@"ad_id"];
    if (self.network.length) {
        [paramDict setValue:self.network forKey:@"provider_type"];
    }
    return [NSDictionary dictionaryWithDictionary:paramDict];
}

- (NSString *)description
{
    return [NSString stringWithFormat:@"SPInterstitial event type: %@, provider: %@ adId: %@", EventTypeToString[self.type], self.network, self.adId];
}

@end
