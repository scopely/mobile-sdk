//
//  SPInterstitialAdapterConfiguration.m
//  SponsorPayTestApp
//
//  Created by David Davila on 10/22/13.
//  Copyright (c) 2013 SponsorPay. All rights reserved.
//

#import "SPInterstitialAdapterConfiguration.h"
#import "SPLogger.h"

static NSString *const SPInterstitialMediationAdaptersDictKey = @"SPInterstitialMediationAdapters";
static NSString *const SPInterstitialAdapterNameDictKey = @"SPAdapterName";
static NSString *const SPInterstitialAdapterParametersDictKey = @"SPAdapterParameters";

@interface SPInterstitialAdapterConfiguration()

@property (strong, nonatomic) NSString *adapterClassName;
@property (strong, nonatomic) NSDictionary *parameters;

@end

@implementation SPInterstitialAdapterConfiguration

+ (instancetype)configurationWithAdapterName:(NSString *)name parameters:(NSDictionary *)parameters
{
    return [[self alloc] initWithAdapterName:name parameters:parameters];
}

- (instancetype)initWithAdapterName:(NSString *)name parameters:(NSDictionary *)parameters
{
    self = [super init];
    if (self) {
        self.adapterClassName = name;
        self.parameters = parameters;
    }
    return self;
}

+ (NSArray *)configurationsFromApplicationBundle
{
    NSArray* adapters = [[NSBundle mainBundle] infoDictionary][SPInterstitialMediationAdaptersDictKey];

    if (![adapters isKindOfClass:[NSArray class]]) {
        [SPLogger log:@"Expected a dictionary as the value of %@. Got %@ instead",
         SPInterstitialMediationAdaptersDictKey, adapters];
        return nil;
    }

    NSMutableArray *returnAdapters = [NSMutableArray arrayWithCapacity:adapters.count];

    for (NSDictionary *adapter in adapters) {
        SPInterstitialAdapterConfiguration *config = [self configurationFromDictionary:adapter];
        if (config) {
            [returnAdapters addObject:config];
        }
        else {
            [SPLogger log:@"Cannot instantiate adapter for plist data: %@", adapter];
        }
    }
    return returnAdapters;
}

+ (instancetype)configurationFromDictionary:(NSDictionary *)configDictionary
{
    NSString *adapterName = configDictionary[SPInterstitialAdapterNameDictKey];

    if (![adapterName isKindOfClass:[NSString class]]) {
        [SPLogger log:@"Expected a string as the value of %@. Got %@ instead",
         SPInterstitialAdapterNameDictKey, adapterName];
        return nil;
    }

    NSDictionary *parameters = configDictionary[SPInterstitialAdapterParametersDictKey];
    if (![parameters isKindOfClass:[NSDictionary class]]) {
        [SPLogger log:@"Parameters for %@=%@", adapterName, parameters];
        parameters = nil;
    }

    return [[self alloc] initWithAdapterName:adapterName parameters:parameters];
}

@end
