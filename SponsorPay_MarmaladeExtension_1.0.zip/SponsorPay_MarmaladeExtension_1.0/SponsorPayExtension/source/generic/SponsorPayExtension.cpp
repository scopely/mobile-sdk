/*
Generic implementation of the SponsorPayExtension extension.
This file should perform any platform-indepedentent functionality
(e.g. error checking) before calling platform-dependent implementations.
*/

/*
 * NOTE: This file was originally written by the extension builder, but will not
 * be overwritten (unless --force is specified) and is intended to be modified.
 */


#include "SponsorPayExtension_internal.h"
s3eResult SponsorPayExtensionInit()
{
    //Add any generic initialisation code here
    return SponsorPayExtensionInit_platform();
}

void SponsorPayExtensionTerminate()
{
    //Add any generic termination code here
    SponsorPayExtensionTerminate_platform();
}

s3eResult SP_SendAdvertiserCallbackNow(const char* appId)
{
	return SP_SendAdvertiserCallbackNow_platform(appId);
}

s3eResult SP_SendAdvertiserCallbackWithDelay(const char* appId, int delayMin)
{
	return SP_SendAdvertiserCallbackWithDelay_platform(appId, delayMin);
}

s3eResult SP_LaunchOfferWall(const char* appId, const char* userId)
{
	return SP_LaunchOfferWall_platform(appId, userId);
}

s3eResult SP_LaunchInterstitial(const char* appId, const char* userId)
{
	return SP_LaunchInterstitial_platform(appId, userId);
}

s3eResult SP_RequestNewCoins(const char* appId, const char* userId, const char* securityToken)
{
	return SP_RequestNewCoins_platform(appId, userId, securityToken);
}

s3eResult SP_RequestOfferBanner(const char* appId, const char* userId, const char* currencyName)
{
	return SP_RequestOfferBanner_platform(appId, userId, currencyName);
}

s3eResult SP_ShowLastReceivedOfferBanner(SP_BannerPosition position)
{
	return SP_ShowLastReceivedOfferBanner_platform(position);
}

s3eResult SP_RemoveOfferBanner()
{
	return SP_RemoveOfferBanner_platform();
}

s3eResult SP_RequestUnlockItemsStatus(const char* appId, const char* userId, const char* securityToken)
{
	return SP_RequestUnlockItemsStatus_platform(appId, userId, securityToken);
}

s3eResult SP_LaunchUnlockOfferWall(const char* appId, const char* userId, const char* itemId, const char* itemName)
{
	return SP_LaunchUnlockOfferWall_platform(appId, userId, itemId, itemName);
}
