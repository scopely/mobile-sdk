//
//  SPAdColonyAdapter.h
//  SponsorPay iOS SDK
//
// Copyright 2011-2013 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SPTPNVideoAdapter.h"
#import "../AdNetworkSettings.h"

#ifdef SPAdColonySDKAvailable_2_0_1_33
#define AdColonyProtocols , AdColonyDelegate, AdColonyTakeoverAdDelegate
#else
#define AdColonyProtocols
#endif


@interface SPAdColonyAdapter : NSObject <SPTPNVideoAdapter AdColonyProtocols>

- (id)initWithAppId:(NSString *)appId
             zoneId:(NSString *)zoneId
          secretKey:(NSString *)secretKey;

@end
