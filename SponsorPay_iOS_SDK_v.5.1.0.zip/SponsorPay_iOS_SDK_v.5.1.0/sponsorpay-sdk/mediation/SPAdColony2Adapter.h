//
//  SPAdColony2Adapter.h
//  SponsorPay iOS SDK
//
// Copyright 2011-2013 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SPTPNVideoAdapter.h"
#import "../AdNetworkSettings.h"

#ifdef SPAdColonySDKAvailable_2_2_2
#define AdColony2Protocols , AdColonyDelegate, AdColonyAdDelegate
#else
#define AdColony2Protocols
#endif


@interface SPAdColony2Adapter : NSObject <SPTPNVideoAdapter AdColony2Protocols>

- (id)initWithAppId:(NSString *)appId
zoneId:(NSString *)zoneId
secretKey:(NSString *)secretKey;

@end
