//
//  SPAdColony2Adapter.m
//  SponsorPay iOS SDK
//
// Copyright 2011-2013 SponsorPay. All rights reserved.
//

#import "SPAdColony2Adapter.h"
#import "SPLogger.h"

@interface SPAdColony2Adapter()

@property (retain) NSString *appId;
@property (retain) NSString *zoneId;
@property (retain) NSString *secretKey;

@property (assign) SPTPNValidationResult validationResult;
@property (assign) BOOL adColonySDKInitialized;
@property (assign) SPTPNProviderPlayingState playingState;

@property (copy) SPTPNVideoEventsHandlerBlock videoEventsCallback;

@end

@implementation SPAdColony2Adapter

- (id)initWithAppId:(NSString *)appId
             zoneId:(NSString *)zoneId
          secretKey:(NSString *)secretKey
{
    self = [super init];

    if (self) {
        self.appId = appId;
        self.zoneId = zoneId;
        self.secretKey = secretKey;
    }

    return self;
}

- (NSString *)providerName
{
    return @"adcolony";
}

- (void)startProvider
{
#ifdef SPAdColonySDKAvailable_2_2_2

    if (!self.adColonySDKInitialized) {
        [SPLogger log:@"Initializing AdColony 2 SDK"];

        [AdColony configureWithAppID:self.appId zoneIDs:@[self.zoneId] delegate:self logging:YES];
        self.adColonySDKInitialized = YES;
    }
#endif
}

- (void)videosAvailable:(SPTPNValidationResultBlock)callback
{
    callback(self.providerName, self.validationResult);
}

- (void)playVideoWithParentViewController:(UIViewController *) parentVC
                        notifyingCallback:(SPTPNVideoEventsHandlerBlock)eventsCallback
{
#ifdef SPAdColonySDKAvailable_2_2_2

    self.videoEventsCallback = eventsCallback;

    [AdColony playVideoAdForZone:self.zoneId
                    withDelegate:self
                withV4VCPrePopup:NO
                andV4VCPostPopup:NO];

    self.playingState = SPTPNProviderPlayingStateWaitingForPlayStart;
    [self startTimeoutChecker];
#endif
}

- (void)startTimeoutChecker
{
#ifdef SPAdColonySDKAvailable_2_2_2
    void(^timeoutBlock)(void) = ^(void) {
        if (self.playingState == SPTPNProviderPlayingStateWaitingForPlayStart) {
            [AdColony cancelAd];
            self.playingState = SPTPNProviderPlayingStateNotPlaying;
        }
    };

    double delayInSeconds = SPTPNTimeoutInterval;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), timeoutBlock);
#endif
}


#pragma mark - AdColonyDelegate protocol implementation

// See AdColony's header doc
- (void)onAdColonyAdAvailabilityChange:(BOOL)available inZone:(NSString*)zoneID
{
    if (![zoneID isEqualToString:self.zoneId])
        return;

    self.validationResult = available ? SPTPNValidationSuccess : SPTPNValidationNoVideoAvailable;
}

// See AdColony's header doc
- (void)onAdColonyV4VCReward:(BOOL)success
                currencyName:(NSString*)currencyName
              currencyAmount:(int)amount
                      inZone:(NSString*)zoneID
{

}


#pragma mark - AdColonyAdDelegate protocol implementation

// See AdColony's header doc
- (void)onAdColonyAdStartedInZone:(NSString *)zoneID
{
    if (![zoneID isEqualToString:self.zoneId])
        return;

    [SPLogger log:@"%s", __PRETTY_FUNCTION__];
    self.playingState = SPTPNProviderPlayingStatePlaying;
    self.videoEventsCallback(self.providerName, SPTPNVideoEventStarted);
}

// See AdColony's header doc
- (void)onAdColonyAdAttemptFinished:(BOOL)shown inZone:(NSString *)zoneID
{
    if (![zoneID isEqualToString:self.zoneId])
        return;

    [SPLogger log:@"%s shown=%d", __PRETTY_FUNCTION__, shown];
    self.playingState = SPTPNProviderPlayingStateNotPlaying;

    if (shown) {
        self.videoEventsCallback(self.providerName, SPTPNVideoEventFinished);
        self.videoEventsCallback(self.providerName, SPTPNVideoEventClosed);
    } else {
        self.videoEventsCallback(self.providerName, SPTPNVideoEventError);
    }
}

@end
