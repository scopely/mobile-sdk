/**
 * SponsorPay Android SDK
 *
 * Copyright 2011 - 2014 SponsorPay. All rights reserved.
 */

package com.sponsorpay.mediation;

public enum SPMediationAdFormat {
	
	RewardedVideo,
	Interstitial
	
}
