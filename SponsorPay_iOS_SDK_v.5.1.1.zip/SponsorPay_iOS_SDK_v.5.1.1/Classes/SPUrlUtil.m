//
//  SPCustomParamsUtil.m
//  SponsorPay Sample App
//
//  Created by David on 9/14/12.
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import "SPUrlUtil.h"

static SPUrlUtil *__defaultUrlUtil;

@interface SPUrlUtil ()

@property (assign, nonatomic) id<SPUrlOverriderDelegate> delegate;

@end

@implementation SPUrlUtil

@synthesize keysArray;
@synthesize paramsDictionary;



-(NSMutableArray *)keysArray
{
    if(!keysArray) {
        keysArray = [[NSMutableArray alloc] init];
    }
    return keysArray;
}

-(NSMutableDictionary *)paramsDictionary
{
    if (!paramsDictionary) {
        paramsDictionary = [[NSMutableDictionary alloc] initWithCapacity:10];
    }
    return paramsDictionary;
}

-(void)addValue:(NSString *)value forKey:(NSString *)key {
    if (![self.paramsDictionary valueForKey:key]) {
        [keysArray addObject:key];
    }
    [self.paramsDictionary setValue:value forKey:key];
}

-(void)removeObjectForKey:(NSString *)key {
    if([self.paramsDictionary valueForKey:key]) {
        [self.keysArray removeObject:key];
        [self.paramsDictionary removeObjectForKey:key];
    }
}

-(void)removeObjectForIndex:(NSUInteger)index
{
    if([keysArray count] >= index+1 ) {
        [paramsDictionary removeObjectForKey:[keysArray objectAtIndex:index]];
        [keysArray removeObjectAtIndex:index];
    }
}

-(NSString *)objectDescriptionForIndex:(int)index
{
    NSString *description = @"";
    if([keysArray count] >= index+1 ) {
        NSString *key = [keysArray objectAtIndex:index];
        NSString *value = [paramsDictionary objectForKey:key];
        description = [NSString stringWithFormat:@"%@ - %@", key, value];
    }
    return description;
}

-(NSString *)objectAtIndex:(int)index {
    return [self.paramsDictionary objectForKey:[keysArray objectAtIndex:index]];
}

-(NSString *)keyAtIndex:(int)index {
    return [self.keysArray objectAtIndex:index];
}

-(NSDictionary *)dictionaryWithKeyValueParameters
{
    return [NSDictionary dictionaryWithDictionary:paramsDictionary];
}

-(void)setDelegate:(id<SPUrlOverriderDelegate>)delegate
{
    _delegate = delegate;
   [self notifyDelegate];
}

-(void)setUrlOverride:(NSString *)urlOverride
{
    _urlOverride = urlOverride;
    [self storeValues];
}

-(void)setShouldOverride:(BOOL)shouldOverride
{
    _shouldOverride = shouldOverride;
    [self notifyDelegate];
    [self storeValues];
}

-(void) notifyDelegate
{
    if (_delegate)
    {
        [_delegate overrideUrlWith:_shouldOverride ? _urlOverride : nil];
    }
}

static NSString *const SPPersistedUrlOverride = @"SPPersistedUrlOverride";
static NSString *const SPPersistedOverrideOn = @"SPPersistedOverrideOn";


- (void)storeValues
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setValue:_urlOverride forKey:SPPersistedUrlOverride];
    [defaults setBool:_shouldOverride forKey:SPPersistedOverrideOn];
    [defaults synchronize];
}

-(void)loadStoredValues
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    _urlOverride = [defaults valueForKey:SPPersistedUrlOverride];
    [self setShouldOverride:[defaults boolForKey:SPPersistedOverrideOn]];
}

-(void) dealloc {
    self.keysArray = nil;
    self.paramsDictionary = nil;
    self.urlOverride = nil;
    [super dealloc];
}


#pragma mark Singleton implementation

+ (SPUrlUtil *)defaultUrlUtil
{
    if (!__defaultUrlUtil) {
        __defaultUrlUtil = [[SPUrlUtil alloc] init];
        [SPURLGenerator setGlobalCustomParametersProvider:__defaultUrlUtil];
        [__defaultUrlUtil loadStoredValues];
    }
    
    return __defaultUrlUtil;
}

@end
