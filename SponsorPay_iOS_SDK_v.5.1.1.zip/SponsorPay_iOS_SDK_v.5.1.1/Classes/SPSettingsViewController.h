//
//  SPSettingsViewController.h
//  SponsorPay Sample App
//
//  Created by David on 9/14/12.
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SPUrlUtil.h"

@interface SPSettingsViewController : UIViewController <UITextFieldDelegate, UITableViewDataSource, UITableViewDelegate> {

//    SPCustomParamsUtil *additionalParameters;
    
    UITextField *keyTextField;
    UITextField *valueTextField;
    
    UITableView *paramsTableView;
    
    UITextField *urlOverriderTextField;
    UISwitch *overrideSwitch;
}

//@property (assign) SPCustomParamsUtil *additionalParameters;

@property (retain) IBOutlet UITextField *keyTextField;
@property (retain) IBOutlet UITextField *valueTextField;
@property (retain) IBOutlet UITableView *paramsTableView;
@property (retain) IBOutlet UITextField *urlOverriderTextField;
@property (retain) IBOutlet UISwitch *overrideSwitch;

-(IBAction)doneButtonTapped:(id)sender;
-(IBAction)addButtonTapped:(id)sender;
-(IBAction)textFieldReturn:(id)sender;
-(IBAction)urlOverriderSwitchValueChanged:(UISwitch *)sender;
-(IBAction)urlOverrideTextFiledChanged:(UITextField *)sender;

@end
