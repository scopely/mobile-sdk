//
//  SPOpenUDIDProvider.h
//  SponsorPaySample
//
//  Created by David Davila on 11/1/12.
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SPURLParametersProvider.h"

@interface SPOpenUDIDProvider : NSObject <SPURLParametersProvider>

@end