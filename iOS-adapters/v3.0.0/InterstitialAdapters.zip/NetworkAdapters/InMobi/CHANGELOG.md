# InMobi - adapter changelog

####3.0.0

 - Added rewarded video mediation adapter
 - Added support for Fyber SDK 7.0.0

####2.0.2
 
 - Added support for InMobi SDK 4.5.1
 - Minor changes

####2.0.0

- Added interstitial mediation adapter