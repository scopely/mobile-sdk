# Ebuzzing - adapter changelog


####2.0.0

- Added rewarded video mediation adapter