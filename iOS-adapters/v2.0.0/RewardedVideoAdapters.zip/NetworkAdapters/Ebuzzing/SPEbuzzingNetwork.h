//
//  SPEbuzzingNetwork.m
//
//  Created on 07/05/14.
//  Copyright (c) 2014 Fyber. All rights reserved.
//

#import "SPBaseNetwork.h"

@interface SPEbuzzingNetwork : SPBaseNetwork

@end
