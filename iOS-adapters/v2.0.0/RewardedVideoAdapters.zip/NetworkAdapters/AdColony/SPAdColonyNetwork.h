//
//  SPAdColonyNetwork.m
//  SponsorPayTestApp
//
//  Created by Daniel Barden on 07/05/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SPBaseNetwork.h"

FOUNDATION_EXPORT NSString *const SPAdColonyV4VCZoneId;
FOUNDATION_EXPORT NSString *const SPAdColonyInterstitialZoneId;

@interface SPAdColonyNetwork : SPBaseNetwork

@end
