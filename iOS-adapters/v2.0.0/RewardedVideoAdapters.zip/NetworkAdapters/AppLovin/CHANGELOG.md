# AppLovin - adapter changelog

####2.2.0

 - Add verbose logging option toggle to the `.plist` file.
 
####2.1.0
 
- Supports AppLovin 2.5.3

####2.0.0

- Added interstitial mediation adapter