//
//  SponsorPay iOS SDK - UnityAds Adapter v.2.1.0
//
//  Created on 13/01/14.
//  Copyright (c) 2014 Fyber. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SPBaseNetwork.h"

@class SPUnityAdsNetwork;
@compatibility_alias SPApplifierNetwork SPUnityAdsNetwork;

//#define UNITY_ADS_TEST_MODE

@interface SPUnityAdsNetwork : SPBaseNetwork

@end
