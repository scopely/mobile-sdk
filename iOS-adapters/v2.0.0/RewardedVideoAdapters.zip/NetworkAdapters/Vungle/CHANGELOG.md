# Vungle - adapter changelog

####2.2.0

 - Removed legacy code.

####2.1.0

 - Supports Vungle SDK 3.0.9
 - Added `SPVungleOrientation` and `SPVungleShowClose` options to to the `.plist` file.
 
####2.0.0

- Added rewarded video mediation adapter