# Flurry for Advertisers - adapter changelog

####2.2.0 

- Added interstitial mediation adapter

####2.1.0 

 - Supports Flurry 5.3.0 and higher
 - Added an option which allows to change Flurry log level in the `.plist` file.
 
####2.0.0

- Added rewarded video mediation adapter