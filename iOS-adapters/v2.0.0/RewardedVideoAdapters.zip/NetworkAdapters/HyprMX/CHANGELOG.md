# HyprMX - adapter changelog

####2.1.1

- Insignificant changes

####2.1.0

- Supports HyprMX SDK 17 and higher

####2.0.1

- Minor changes

####2.0.0

- Added rewarded video mediation adapter