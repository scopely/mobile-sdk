# HyprMX - adapter changelog

####2.1.3

 - Added workaround to fix an issue which caused screen to be cropped on Unity platform
  
####2.1.2

- Prevent from starting adapter more than once.
- This is recommended version for Fyber SDK 7.x (please check the **Migration guide from Fyber SDK 6.x to 7.x** section in [README.md](./README.md) file)

####2.1.1

- Insignificant changes
- Added support for HyprMX SDK 18

####2.1.0

- Added support for HyprMX SDK 17

####2.0.1

- Minor changes

####2.0.0

- Added rewarded video mediation adapter