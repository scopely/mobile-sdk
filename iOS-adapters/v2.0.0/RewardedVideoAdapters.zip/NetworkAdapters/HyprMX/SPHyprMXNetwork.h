//
//  SPHyprMXNetwork.m
//  SponsorPayTestApp
//
//  Created by Pierre Bongen on 22.05.14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import "SPBaseNetwork.h"



#pragma mark  

@interface SPHyprMXNetwork : SPBaseNetwork

#pragma mark  
#pragma mark Public Methods -

#pragma mark  
#pragma mark Initialisation

- (instancetype)init;

@end

#pragma mark  
