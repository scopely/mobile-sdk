| Network | Adapter version | Third party SDK version | Fyber SDK version |
|:----------:|:-------------:|:-----------------------:|:------------:|
| Appia | 2.0.0 | 2013-11-06 | 6.5.2 |