# Appia - adapter changelog

####2.0.0

- Added interstitial mediation adapter