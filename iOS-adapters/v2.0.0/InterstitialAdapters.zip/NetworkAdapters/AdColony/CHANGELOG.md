# AdColony - adapter changelog

####2.1.3

 - Fixed behaviour of error reporting

####2.1.2

- Added Support for AdColony 2.4.13
- Fixed bug that caused unexpected behaviour when the same zoneID was used for interstitials and rewarded video mediations

####2.1.1

- Minor changes

####2.1.0

- Added interstitial mediation adapter
- Added rewarded video mediation adapter