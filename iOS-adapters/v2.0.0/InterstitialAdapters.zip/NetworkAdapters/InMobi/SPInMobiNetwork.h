//
//  SPInMobiNetwork.h
//
//  Copyright (c) 2014 Fyber. All rights reserved.
//

#import "SPBaseNetwork.h"
#import "InMobi.h"

@interface SPInMobiNetwork : SPBaseNetwork

@property (copy, nonatomic, readonly) NSString *appId;

@end
