# AdMob - adapter changelog


####2.0.2
 
- Minor changes

####2.0.1
 
- Minor changes

####2.0.0

- Added interstitial mediation adapter