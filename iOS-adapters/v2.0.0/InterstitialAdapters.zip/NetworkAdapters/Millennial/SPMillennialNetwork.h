//
//  SPMillennialNetwork.h
//  SponsorPayTestApp
//
//  Created by Daniel Barden on 18/02/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import "SPBaseNetwork.h"

@interface SPMillennialNetwork : SPBaseNetwork

@property (copy, nonatomic) NSString *apid;

@end
