# Millennial Media - adapter changelog

####2.0.2

 - Fixed bug that could cause double log messages in rare conditions.

####2.0.1

- Removed support for iOS 5
- Supports Millennial Media SDK 5.4.1

####2.0.0

- Added interstitial mediation adapter