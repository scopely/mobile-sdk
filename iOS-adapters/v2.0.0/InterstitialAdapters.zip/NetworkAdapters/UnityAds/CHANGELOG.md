# UnityAds - adapter changelog

####2.2.0

- Added interstitial mediation adapter

####2.1.0

- Transition from Applifier to UnityAds
- Supports UnityAds SDK 1.3.8

####2.0.0

- Added rewarded video mediation adapter