//
//  SPEbuzzingNetwork.m
//  SponsorPayTestApp
//
//  Created by Daniel Barden on 07/05/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import "SPBaseNetwork.h"

@interface SPEbuzzingNetwork : SPBaseNetwork

@end
