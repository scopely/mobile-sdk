# AppLovin - adapter changelog

####2.3.0

- Added support for AppLovin 2.5.4

####2.2.0

- Added verbose logging option toggle to the `.plist` file.
 
####2.1.0
 
- Added support for AppLovin 2.5.3

####2.0.0

- Added interstitial mediation adapter