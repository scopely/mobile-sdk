package com.sponsorpay.utils;


public class SPTimeLogger {

	
	public static long logStart(String tag, String description) {
    	SponsorPayLogger.e(tag, "======================= " + description + " =======================");
    	long currentTimeMillis = System.currentTimeMillis();
		SponsorPayLogger.e(tag, "=========== "+ currentTimeMillis + " =========");
		return currentTimeMillis;
	}
	
	
	public static void logEnd(String tag, String description, long timeInMillis) {
		long currentTimeMillis = System.currentTimeMillis();
		SponsorPayLogger.e(tag, "=========== "+ currentTimeMillis + " =========");
		SponsorPayLogger.e(tag, "=========== "+ (currentTimeMillis - timeInMillis) + " =========");
        SponsorPayLogger.e(tag, "======================= " + description + " =======================");
	}
	
}
