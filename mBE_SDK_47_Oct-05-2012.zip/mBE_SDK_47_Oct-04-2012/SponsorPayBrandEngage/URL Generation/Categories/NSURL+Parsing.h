//
//  NSURL+Parsing.h
//  SponsorPay Mobile Brand Engage SDK
//

#import <Foundation/Foundation.h>

@interface NSURL (Parsing)

- (NSDictionary *)queryDictionary;


@end
