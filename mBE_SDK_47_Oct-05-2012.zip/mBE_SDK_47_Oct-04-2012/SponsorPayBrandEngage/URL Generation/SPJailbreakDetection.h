//
//  SPJailbreakDetection.h
//  SponsorPay iOS SDK
//
//  Copyright 2011 SponsorPay. All rights reserved.
//


#import <Foundation/Foundation.h>


@interface SPJailbreakDetection : NSObject {

}

/** Checks to see if the device is jailbroken. */
+ (BOOL) isJailBroken;

@end
