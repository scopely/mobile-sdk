//
//  SPLogger.h
//  SponsorPay Mobile Brand Engage SDK
//
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SPLogger : NSObject

+ (SPLogger *)defaultLogger;

@property BOOL shouldOutputToSystemLog;
@property BOOL shouldBufferLogMessages;
@property (readonly) NSString *bufferedMessagesString;

- (void)log:(NSString *)format, ...;

- (void)logFormat:(NSString *)format arguments:(va_list)arguments;

- (void)shutUp;

+ (void)log:(NSString *)format, ...;

@end
