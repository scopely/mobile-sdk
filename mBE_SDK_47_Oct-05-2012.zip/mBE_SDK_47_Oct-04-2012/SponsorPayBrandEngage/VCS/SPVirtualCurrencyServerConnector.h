//
//  SPVirtualCurrencyConnector.h
//  SponsorPay Mobile Brand Engage SDK
//
//  Copyright (c) 2011 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 The SPVirtualCurrencyServerConnector class provides functionality to query SponsorPay's Virtual Currency Servers to obtain the number of virtual coins the user has earned.
 
 It keeps track of the last time the amount of earned coins was requested for a given user, reporting newly earned amounts between successive requests, even across application sessions.
 
 The client is authenticated to the virtual currency server by signing URL requests with the secret token or key that SponsorPay has assigned to your publisher account, and that you must provide upon initialization of an instance or by setting the secretToken property.
 
 Answers to the requests are asynchronously reported to your registered delegate through the selectors defined in the SPVirtualCurrencyConnectionDelegate protocol.
*/
@class SPVirtualCurrencyServerConnector;

/* Handler that can be run when a successful answer to the delta of coins request (fetchDeltaOfCoins) is received.
 
 This is used by the Mobile Brand Engage SDK to show a toast-like notification to the user without interfering with your registered delegate.
 
 @see addFetchDeltaOfCoinsCompletionBlock

 */
typedef BOOL (^SPVCSDeltaOfCoinsRequestCompletionBlock)(double deltaOfCoins,
                                                        NSString *latestTransactionId);

@interface SPVirtualCurrencyServerConnector : NSObject {
    NSString *_appId;
	NSString *_userId;
	NSString *secretToken;
    
    int responseStatusCode;
    NSMutableData *responseData;
    NSString *responseSignature;

    id delegate;
    BOOL shouldLogVerbosely;
    
    NSURLConnection *currentConnection;
    
    NSMutableArray *_fetchDeltaOfCoinsCompletionBlocks;
}

/** @name Setting publisher parameters */

/** Your SponsorPay application ID.
 This is the app ID assigned to you by SponsorPay.
 */
@property (retain) NSString *appId;

/** ID of the current user of your application.
 This string must uniquely identify the current user to the BrandEngage and virtual currency server systems.
 */
@property (retain) NSString *userId;


/** @name Authenticating the request and the signature */

/** The token to access your account on SponsorPay's virtual currency server.
 This token is used to sign requests to the SponsorPay currency server.
 */
@property (retain) NSString *secretToken;

/** Signature of the last response received from the server
 This is used in combination with secretToken to validate the authenticity of the response.
 */
@property (retain) NSString *responseSignature;

/** Obtaining the last transaction ID */

/** Latest transaction ID for your user and app IDs, as reported by the server.
 This is used to keep track of new transactions between invocations to fetchDeltaOfCoins.
 */
@property (retain) NSString *latestTransactionId;

/** @name Being notified asyncronously of server responses and errors */

/** Delegate to be notified of answers to requests and error conditions.
 Answers to the requests are asynchronously reported to your registered delegate through the selectors defined in the SPVirtualCurrencyConnectionDelegate protocol.
*/
@property (retain) id delegate;

/** @name Controlling log verbosity */

/** Enables verbose log messages.
 Leave its value to NO to be notified only of important events related to the communication with the VCS.
 
 @see SPLogger
 */
@property BOOL shouldLogVerbosely;

/** Initializes a new instance with the specified user ID, app ID and secret VCS token.
 @param userId ID of the current user of your application.
 @param appId Your SponsorPay application ID.
 @returns a fresh SPVirtualCurrencyServerConnector instance.
 */
- (id)initWithUserId:(NSString *)userId
               appId: (NSString *)appId
         secretToken:(NSString *)secretToken;

/** Fetches the amount of coins earned since the last time this method was invoked for the current user ID / app ID combination.
 
 This involves a network call which will be performed in the background. When the answer from the server is received, your registered delegate will be notified.
 */
- (void)fetchDeltaOfCoins;

/** Adds a completion handler that will be run when a successful answer to fetchDeltaOfCoins is received.
 
 This is used by the Mobile Brand Engage SDK to show a toast-like notification to the user without interfering with your registered delegate.
 
 Though you could use this method to obtain the same functionality that registering a SPVirtualCurrencyConnectionDelegate offers for being notified of the amount of coins earned by the user, relying on the delegate is the recommended way of being notified of the results of the request, as it can handle error conditions.
 
 The supplied handler will be run in the main thread. Multiple completion handlers can be specified in successive calls and they will run in the order in which they were added.
 
 @param completionBlock Block to be run when a successful answer to the delta of coins request is received.
 */
- (void)addFetchDeltaOfCoinsCompletionBlock:(SPVCSDeltaOfCoinsRequestCompletionBlock)completionBlock;

+ (void)overrideVCSBaseURLWithURLString:(NSString *)overridingURL;
+ (void)restoreDefaultVCSBaseURL;

@end

typedef enum {
    NO_ERROR,
    ERROR_NO_INTERNET_CONNECTION,
    ERROR_INVALID_RESPONSE,
    ERROR_INVALID_RESPONSE_SIGNATURE,
    SERVER_RETURNED_ERROR,
    ERROR_OTHER
} SPVirtualCurrencyRequestErrorType;

/** Defines selectors that a delegate of SPVirtualCurrencyServerConnector can implement for being notified of answers to requests and triggered errors.
 */
@protocol SPVirtualCurrencyConnectionDelegate
@optional

/** Sent when SPVirtualCurrencyServerConnector receives an answer from the server for the amount of coins newly earned by the user.
 @param connector SPVirtualCurrencyServerConnector instance of SPVirtualCurrencyServerConnector that sent this message.
 @param deltaOfCoins Amount of coins earned by the user.
 @param transactionId Transaction ID of the last known operation involving your virtual currency for this user.
 */
- (void)virtualCurrencyConnector:(SPVirtualCurrencyServerConnector *)connector
  didReceiveDeltaOfCoinsResponse:(double)deltaOfCoins
             latestTransactionId:(NSString *)transactionId;

/** Sent when SPVirtualCurrencyServerConnector detects an error condition.
 @param connector SPVirtualCurrencyServerConnector instance of SPVirtualCurrencyServerConnector that sent this message.
 @param deltaOfCoins Type of the triggered error. @see SPVirtualCurrencyRequestErrorType
 @param errorCode if this is an error received from the back-end, error code as reported by the server.
 @param errorMessage if this is an error received from the back-end, error message as reported by the server.
*/
- (void)virtualCurrencyConnector:(SPVirtualCurrencyServerConnector *)connector
                 failedWithError:(SPVirtualCurrencyRequestErrorType)error
                       errorCode:(NSString *)errorCode
                    errorMessage:(NSString *)errorMessage;
@end