//
//  MBETestAppViewController.m
//  MBE TestApp
//
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import "MBETestAppViewController.h"
#import "SPBrandEngageClient.h"
#import "SPLogger.h"
#import "MBETestAppSettings.h"

@interface MBETestAppViewController ()

- (void)hideKeyboardIfNecessary;
- (void)configureBrandEngageClient;
- (void)configureBrandEngageCoreURL:(NSString *)urlString;
- (void)configureVCSConnectorStagingURL:(BOOL)useStaging;
- (void)adjustUIToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation;

@end

@implementation MBETestAppViewController {
    SPBrandEngageClient *_brandEngageClient;
}

@synthesize appIdTextField;
@synthesize userIdTextField;
@synthesize currencyNameTextField;
@synthesize VCSKeyTextField;
@synthesize logMessagesTextView;
@synthesize activityIndicator;

#pragma mark - Housekeeping

- (void)dealloc {
    [[SPLogger defaultLogger] removeObserver:self
                                  forKeyPath:@"bufferedMessagesString"];
    
    [self setAppIdTextField:nil];
    [self setUserIdTextField:nil];
    [self setActivityIndicator:nil];
    [self setCurrencyNameTextField:nil];
    [self setVCSKeyTextField:nil];
    [self setLogMessagesTextView:nil];
    
    [appIdTextField release];
    [userIdTextField release];
    [activityIndicator release];
    [currencyNameTextField release];
    [VCSKeyTextField release];
    [logMessagesTextView release];
    [_appIdLabel release];
    [_currencyNameLabel release];
    [_userIdLabel release];
    [_VCSKeyLabel release];
    [_requestCoinsButton release];
    [_requestOffersButton release];
    [_startMBEButton release];
    [super dealloc];
}

- (void)configureBrandEngageClient {
    NSString *appId = self.appIdTextField.text;
    NSString *userId = self.userIdTextField.text;
    
    if (!_brandEngageClient) {
        _brandEngageClient = [[SPBrandEngageClient alloc] initWithAppId:appId
                                                                 userId:userId
                                                               delegate:self];
        
        _brandEngageClient.shouldSendUDID = [MBETestAppSettings persistedBoolForKey:kSPShouldSendUDIDDefaultsKey];
        
        _brandEngageClient.shouldShowRewardNotificationOnEngagementCompleted =
            [MBETestAppSettings persistedBoolForKey:kSPShouldShowRewardNotificationDefaultsKey];
        _brandEngageClient.shouldShowPayoffNotificationOnVirtualCoinsReceived =
            [MBETestAppSettings persistedBoolForKey:kSPShouldShowPayoffNotificationDefaultsKey];
        _brandEngageClient.payoffNotificationRoundingMode =
            [MBETestAppSettings persistedIntegerForKey:kSPPayoffNotificationCurrencyRoundingModeDefaultsKey];
        
        [self configureBrandEngageCoreURL:[MBETestAppSettings overridenMBEURL]];
        [self configureVCSConnectorStagingURL:[MBETestAppSettings persistedBoolForKey:kSPVCSStagingDefaultsKey]];
    } else {
        _brandEngageClient.appId = appId;
        _brandEngageClient.userId = userId;
    }
    
    _brandEngageClient.currencyName = self.currencyNameTextField.text;
    _brandEngageClient.VCSKey = self.VCSKeyTextField.text;
}


#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [[SPLogger defaultLogger] addObserver:self
                               forKeyPath:@"bufferedMessagesString"
                                  options:NSKeyValueObservingOptionOld
                                  context:nil];
}

- (void)viewWillAppear:(BOOL)animated
{
    [self adjustUIToInterfaceOrientation:[[UIApplication sharedApplication] statusBarOrientation]];
}

#pragma mark - Orientation handling

#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 60000

- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskAll;
}

#endif


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}

- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
                                duration:(NSTimeInterval)duration
{
    [self adjustUIToInterfaceOrientation:toInterfaceOrientation];
}

- (void)adjustUIToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    BOOL isLandscape = UIInterfaceOrientationIsLandscape(interfaceOrientation);
    
    self.appIdLabel.text = isLandscape ? @"App ID:" : @"App:";
    self.currencyNameLabel.text = isLandscape ? @"Currency Name:" : @"Currency:";
    self.userIdLabel.text = isLandscape ? @"User ID:" : @"User:";
    self.VCSKeyLabel.text = isLandscape ? @"VCS Key:" : @"Key:";
    [self.requestCoinsButton setTitle: isLandscape ? @"Request Coins" : @"Coins" forState:UIControlStateNormal];
    [self.requestOffersButton setTitle: isLandscape ? @"Request Offers" : @"Offers" forState:UIControlStateNormal];
    [self.startMBEButton setTitle: isLandscape ? @"Start MBE" : @"Start" forState:UIControlStateNormal];
    
}

#pragma mark - User interaction

- (IBAction)requestOffersButtonTapped:(id)sender {
    [self hideKeyboardIfNecessary];

    [self.activityIndicator startAnimating];
    [SPLogger log:@"Requesting offers..."];

    [self configureBrandEngageClient];
 
    [_brandEngageClient requestOffers];
}

- (IBAction)startMBEButtonTapped:(id)sender {
    [self hideKeyboardIfNecessary];
    
    [self configureBrandEngageClient];
    
    [_brandEngageClient startWithParentViewController:self];
}


- (IBAction)requestCoinsButtonTapped:(id)sender
{
    [self hideKeyboardIfNecessary];

    [self configureBrandEngageClient];

    _brandEngageClient.VCSConnector.delegate = self;
    [_brandEngageClient.VCSConnector fetchDeltaOfCoins];
    
    [self.activityIndicator startAnimating];
}

- (IBAction)infoButtonTapped:(id)sender
{
    if (!_brandEngageClient)
        [self configureBrandEngageClient]; // Make sure it's instantiated because we may modify its instance settings
    
    MBETestAppInfoSettingsViewController *infoSettingsViewController =
        [[MBETestAppInfoSettingsViewController alloc] init];
    
    // Custom mBE URL setting
    infoSettingsViewController.baseURLState = [MBETestAppSettings overridenMBEURL];
    infoSettingsViewController.baseURLChangeHandler =
    ^void(id newValue, NSDictionary *meta) {
        [SPLogger log:@"Setting base URL for mBE to %@",
         [newValue isEqualToString:@""] ? @"[empty, will use production URL]" : newValue];
        [self configureBrandEngageCoreURL:newValue];
        [MBETestAppSettings setOverridenMBEURL:newValue];
    };
    
    // VCS staging setting
    infoSettingsViewController.VCSStagingState = [MBETestAppSettings persistedBoolForKey:kSPVCSStagingDefaultsKey];
    infoSettingsViewController.VCSStagingChangeHandler =
    ^void(id newValue, NSDictionary *meta) {
        BOOL shouldUseStagingVCS = [newValue boolValue];
        [self configureVCSConnectorStagingURL:shouldUseStagingVCS];
        [MBETestAppSettings persistBool:shouldUseStagingVCS forKey:kSPVCSStagingDefaultsKey];
    };
    
    // Show reward notification setting
    infoSettingsViewController.showRewardNotificationState =
        _brandEngageClient.shouldShowRewardNotificationOnEngagementCompleted;
    infoSettingsViewController.showRewardNotificationChangeHandler =
    ^void(id newValue, NSDictionary *meta) {
        BOOL showRewardNotification = [newValue boolValue];
        [SPLogger log:@"Setting shouldShowRewardNotificationOnEngagementCompleted to %@",
         showRewardNotification ? @"YES" : @"NO"];
        _brandEngageClient.shouldShowRewardNotificationOnEngagementCompleted = showRewardNotification;
        [MBETestAppSettings persistBool:showRewardNotification forKey:kSPShouldShowRewardNotificationDefaultsKey];
    };
    
    // Show payoff notification setting
    infoSettingsViewController.showPayoffCoinsNotificationState =
        _brandEngageClient.shouldShowPayoffNotificationOnVirtualCoinsReceived;
    infoSettingsViewController.showPayoffNotificationChangeHandler =
    ^void(id newValue, NSDictionary *meta) {
        BOOL showPayoffNotification = [newValue boolValue];
        [SPLogger log:@"Setting shouldShowPayoffNotificationOnVirtualCoinsReceived to %@",
         showPayoffNotification ? @"YES" : @"NO"];
        _brandEngageClient.shouldShowPayoffNotificationOnVirtualCoinsReceived = showPayoffNotification;
        [MBETestAppSettings persistBool:showPayoffNotification forKey:kSPShouldShowPayoffNotificationDefaultsKey];
    };
    
    // Fetch and send UDID setting
    infoSettingsViewController.sendUDIDState = _brandEngageClient.shouldSendUDID;
    infoSettingsViewController.sendUDIDChangeHandler =
    ^void(id newValue, NSDictionary *meta) {
        BOOL sendUDID = [newValue boolValue];
        [SPLogger log:@"Setting shouldSendUDID to %@", sendUDID ? @"YES" : @"NO"];
        _brandEngageClient.shouldSendUDID = sendUDID;
        [MBETestAppSettings persistBool:sendUDID forKey:kSPShouldSendUDIDDefaultsKey];
    };
    
    // Payoff notification rounding mode setting
    infoSettingsViewController.payoffNotificationCurrencyRoundingModeState =
        _brandEngageClient.payoffNotificationRoundingMode;
    infoSettingsViewController.payoffNotificationRoundingModeChangeHandler =
    ^void(id newValue, NSDictionary *meta) {
        SPCurrencyRoundingMode roundingMode = [newValue integerValue];
        
        NSString *roundingModeDescription;
        switch (roundingMode) {
            case SPCurrencyRoundingModeRound:
                roundingModeDescription = @"SPCurrencyRoundingModeRound";
                break;
            case SPCurrencyRoundingModeFloor:
                roundingModeDescription = @"SPCurrencyRoundingModeFloor";
                break;
            case SPCurrencyRoundingModeCeil:
                roundingModeDescription = @"SPCurrencyRoundingModeCeil";
                break;
            default:
                roundingModeDescription = [NSString stringWithFormat:@"%d", roundingMode];
                break;
        }
        [SPLogger log:@"Setting payoffNotificationRoundingMode to %@", roundingModeDescription];
        _brandEngageClient.payoffNotificationRoundingMode = roundingMode;
        [MBETestAppSettings persistInteger:roundingMode
                                    forKey:kSPPayoffNotificationCurrencyRoundingModeDefaultsKey];
    };

    [self presentViewController:infoSettingsViewController animated:YES completion:nil];
    
    [infoSettingsViewController release];
}

#pragma mark - SPBrandEngageClientDelegate methods

- (void)brandEngageClient:(SPBrandEngageClient *)brandEngageClient
         didReceiveOffers:(BOOL)areOffersAvailable
{
    [self.activityIndicator stopAnimating];
 
    [SPLogger log:areOffersAvailable ? @"Offers are available" : @"No offers available"];
}

- (void)brandEngageClient:(SPBrandEngageClient *)brandEngageClient
          didChangeStatus:(SPBrandEngageClientStatus)newStatus
{
    NSString *statusName;
    
    switch (newStatus) {
        case STARTED: statusName = @"STARTED"; break;
        case CLOSE_FINISHED: statusName = @"CLOSE_FINISHED"; break;
        case CLOSE_ABORTED: statusName = @"CLOSE_ABORTED"; break;
        case ERROR: statusName = @"ERROR"; break;
    }
    [SPLogger log:@"Brand engage client changed status to: %@", statusName];
    
    [self.activityIndicator stopAnimating];
}


#pragma mark - Keyboard management

- (void)hideKeyboardIfNecessary
{
    NSArray *textFields = [NSArray arrayWithObjects:self.appIdTextField,
                           self.userIdTextField, self.currencyNameTextField,
                           self.VCSKeyTextField, nil];
    
    [textFields enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        if ([obj isFirstResponder]) {
            *stop = YES;
            [obj resignFirstResponder];
        }
    }];
}


- (IBAction)textFieldDidEndOnExit:(id)sender
{
    [sender resignFirstResponder];
}


#pragma mark - SPVirtualCurrencyConnectionDelegate methods

- (void)virtualCurrencyConnector:(SPVirtualCurrencyServerConnector *)vcConnector
  didReceiveDeltaOfCoinsResponse:(double)deltaOfCoins
             latestTransactionId:(NSString *)transactionId
{
    [self.activityIndicator stopAnimating];
    
    [SPLogger log:@"VCS Response Received: ---- \nDelta of Coins: %f\nReturned Latest Transaction ID: %@",
     deltaOfCoins, transactionId];
}

- (void)virtualCurrencyConnector:(SPVirtualCurrencyServerConnector *)vcConnector
                 failedWithError:(SPVirtualCurrencyRequestErrorType)error
                       errorCode:(NSString *)errorCode
                    errorMessage:(NSString *)errorMessage
{
    [self.activityIndicator stopAnimating];
    
    NSString *errorType;
    
    switch (error) {
        case NO_ERROR:
            errorType = @"NO_ERROR";
            break;
        case ERROR_NO_INTERNET_CONNECTION:
            errorType = @"ERROR_NO_INTERNET_CONNECTION";
            break;
        case ERROR_INVALID_RESPONSE:
            errorType = @"ERROR_INVALID_RESPONSE";
            break;
        case ERROR_INVALID_RESPONSE_SIGNATURE:
            errorType = @"ERROR_INVALID_RESPONSE_SIGNATURE";
            break;
        case SERVER_RETURNED_ERROR:
            errorType = @"SERVER_RETURNED_ERROR";
            break;
        case ERROR_OTHER:
            errorType = @"ERROR_OTHER";
            break;
        default:
            errorType = [NSString stringWithFormat:@"%d", error];
            break;
    }
    
    [SPLogger log:@"Error in VCS Request / Response ---- \n%@\n%@\n%@", errorType, errorCode, errorMessage];
}

#pragma mark - Property change observing

- (void)observeValueForKeyPath:(NSString *)keyPath
                      ofObject:(id)object
                        change:(NSDictionary *)change
                       context:(void *)context
{
    if (object == [SPLogger defaultLogger]
        && [keyPath isEqualToString:@"bufferedMessagesString"]) {
        
        NSString *logMessages = [SPLogger defaultLogger].bufferedMessagesString;
        logMessagesTextView.text = logMessages;
        
        NSString *previousLogMessages = [change objectForKey:NSKeyValueChangeOldKey];
        
        if (![previousLogMessages isKindOfClass:[NSNull class]]) {
//            NSUInteger previousLogLength = previousLogMessages.length;
            NSUInteger currentLogLength = logMessages.length;
            
            NSRange newMessageRange = NSMakeRange(currentLogLength - 1,
                                                  1);
            [self.logMessagesTextView scrollRangeToVisible:newMessageRange];
        }
    }
}

#pragma mark -

- (void)configureBrandEngageCoreURL:(NSString *)urlString
{
    if (urlString && ![urlString isEqualToString:@""])
        [SPBrandEngageClient overrideMBEJSCoreURLWithURLString:urlString];
    else {
        [SPLogger log:@"Using production URL for MBE"];
        [SPBrandEngageClient restoreDefaultMBEJSCoreURL];
    }
}

- (void)configureVCSConnectorStagingURL:(BOOL)useStaging
{
    if (useStaging)
        [SPVirtualCurrencyServerConnector overrideVCSBaseURLWithURLString:kSPVCSBaseURL_Staging];
    else
        [SPVirtualCurrencyServerConnector restoreDefaultVCSBaseURL];

    [SPLogger log:@"Using %@ URL for VCS", useStaging ? @"staging" : @"production"];
}
- (void)viewDidUnload {
    [self setAppIdLabel:nil];
    [self setCurrencyNameLabel:nil];
    [self setUserIdLabel:nil];
    [self setVCSKeyLabel:nil];
    [self setRequestCoinsButton:nil];
    [self setRequestOffersButton:nil];
    [self setStartMBEButton:nil];
    [super viewDidUnload];
}
@end
