//
//  MBETestAppInfoSettingsViewController.m
//  MBE TestApp
//
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import "MBETestAppInfoSettingsViewController.h"

@interface MBETestAppInfoSettingsViewController ()

- (void)baseURLTextFieldValueDidChange;
- (void)adjustUIToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation;

@end

@implementation MBETestAppInfoSettingsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    [self adjustUIToInterfaceOrientation:[[UIApplication sharedApplication] statusBarOrientation]];

    self.baseURLTextField.text = self.baseURLState;
    self.VCSStagingSwitch.on = self.VCSStagingState;
    self.showRewardNotificationSwitch.on = self.showRewardNotificationState;
    self.showPayoffNotificationSwitch.on = self.showPayoffCoinsNotificationState;
    self.sendUDIDSwitch.on = self.sendUDIDState;
    self.currencyRoundingModeSegmentedControl.selectedSegmentIndex =
        self.payoffNotificationCurrencyRoundingModeState;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}

- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
                                duration:(NSTimeInterval)duration
{
    [self adjustUIToInterfaceOrientation:toInterfaceOrientation];
}

- (void)adjustUIToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    BOOL isLandscape = UIInterfaceOrientationIsLandscape(interfaceOrientation);
    
    self.navigationBar.topItem.title = isLandscape ? @"SponsorPay mBE Test App" : @"SponsorPay mBE";
    self.baseURLLabel.text = isLandscape ? @"Base URL:" : @"URL:";
    self.rewardNotificationLabel.text = isLandscape ? @"Reward Notification After Offer Completion" : @"Reward Notification";
    self.payoffNotificationLabel.text = isLandscape ? @"Payoff Notification When Coins Received" : @"Payoff Notification";
    self.roundingModeLabel.text = isLandscape ? @"Rounding Mode for Currency Shown in the Payoff Toast:" : @"Currency Rounding Mode:";

    [self.currencyRoundingModeSegmentedControl setTitle: isLandscape ? @"Normal Round" : @"Normal"
                                      forSegmentAtIndex:0];
    [self.currencyRoundingModeSegmentedControl setTitle: isLandscape ? @"Round Down" : @"Down"
                                      forSegmentAtIndex:1];
    [self.currencyRoundingModeSegmentedControl setTitle: isLandscape ? @"Round Up" : @"Up"
                                      forSegmentAtIndex:2];
}

- (IBAction)baseURLTextFieldEditingDidEnd:(id)sender
{
    [self baseURLTextFieldValueDidChange];
}

- (IBAction)setStagingURLbuttonTapped:(id)sender
{
    self.baseURLTextField.text = kSPMBEJSCoreURL_Staging;
    [self baseURLTextFieldValueDidChange];
}

- (IBAction)VCSStagingValueChanged:(UISwitch *)sender
{
    self.VCSStagingState = sender.on;
    self.VCSStagingChangeHandler([NSNumber numberWithBool:sender.on], nil);
}

- (void)baseURLTextFieldValueDidChange
{
    self.baseURLState = self.baseURLTextField.text;
    self.baseURLChangeHandler(self.baseURLState, nil);
}

- (IBAction)showRewardNotificationSwitchValueChanged:(UISwitch *)sender
{
    self.showRewardNotificationState = sender.on;
    self.showRewardNotificationChangeHandler([NSNumber numberWithBool:sender.on], nil);
}

- (IBAction)showPayoffNotificationValueChanged:(UISwitch *)sender
{
    self.showPayoffCoinsNotificationState = sender.on;
    self.showPayoffNotificationChangeHandler([NSNumber numberWithBool:sender.on], nil);
}

- (IBAction)sendUDIDValueChanged:(UISwitch *)sender
{
    self.sendUDIDState = sender.on;
    self.sendUDIDChangeHandler([NSNumber numberWithBool:sender.on], nil);
}

- (IBAction)currencyRoundingModeSegmentedControlValueChanged:(UISegmentedControl *)sender
{
    self.payoffNotificationCurrencyRoundingModeState = sender.selectedSegmentIndex;
    self.payoffNotificationRoundingModeChangeHandler([NSNumber numberWithInteger:sender.selectedSegmentIndex], nil);
}

- (IBAction)textFieldDidEndOnExit:(id)sender
{
    [sender resignFirstResponder];
}

- (IBAction)doneButtonTapped:(id)sender
{
    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
}

- (void)dealloc
{
    [self setBaseURLTextField:nil];
    [self setVCSStagingSwitch:nil];
    [self setSendUDIDSwitch:nil];
    [self setCurrencyRoundingModeSegmentedControl:nil];
    [_showRewardNotificationSwitch release];
    [_showPayoffNotificationSwitch release];
    [_sendUDIDSwitch release];
    [_currencyRoundingModeSegmentedControl release];
    [_baseURLTextField release];
    [_VCSStagingSwitch release];
    [_baseURLLabel release];
    [_VCSStagingLabel release];
    [_rewardNotificationLabel release];
    [_payoffNotificationLabel release];
    [_sendUDIDLabel release];
    [_roundingModeLabel release];
    [_navigationBar release];
    [super dealloc];
}

- (void)viewDidUnload {
    [self setBaseURLLabel:nil];
    [self setVCSStagingLabel:nil];
    [self setRewardNotificationLabel:nil];
    [self setPayoffNotificationLabel:nil];
    [self setSendUDIDLabel:nil];
    [self setRoundingModeLabel:nil];
    [self setNavigationBar:nil];
    [super viewDidUnload];
}
@end
