//
//  MBETestAppAppDelegate.h
//  MBE TestApp
//
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MBETestAppViewController;

@interface MBETestAppAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) MBETestAppViewController *viewController;

@end
