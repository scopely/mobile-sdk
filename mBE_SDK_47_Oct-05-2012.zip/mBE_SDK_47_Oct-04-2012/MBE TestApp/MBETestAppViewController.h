//
//  MBETestAppViewController.h
//  MBE TestApp
//
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SPBrandEngageClient.h"
#import "SPVirtualCurrencyServerConnector.h"
#import "MBETestAppInfoSettingsViewController.h"

@interface MBETestAppViewController : UIViewController <SPBrandEngageClientDelegate, SPVirtualCurrencyConnectionDelegate>
@property (retain, nonatomic) IBOutlet UITextField *appIdTextField;
@property (retain, nonatomic) IBOutlet UITextField *userIdTextField;
@property (retain, nonatomic) IBOutlet UITextField *currencyNameTextField;
@property (retain, nonatomic) IBOutlet UITextField *VCSKeyTextField;
@property (retain, nonatomic) IBOutlet UITextView *logMessagesTextView;
@property (retain, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (retain, nonatomic) IBOutlet UILabel *appIdLabel;
@property (retain, nonatomic) IBOutlet UILabel *currencyNameLabel;
@property (retain, nonatomic) IBOutlet UILabel *userIdLabel;
@property (retain, nonatomic) IBOutlet UILabel *VCSKeyLabel;
@property (retain, nonatomic) IBOutlet UIButton *requestCoinsButton;
@property (retain, nonatomic) IBOutlet UIButton *requestOffersButton;
@property (retain, nonatomic) IBOutlet UIButton *startMBEButton;

- (IBAction)requestOffersButtonTapped:(id)sender;
- (IBAction)startMBEButtonTapped:(id)sender;
- (IBAction)requestCoinsButtonTapped:(id)sender;
- (IBAction)infoButtonTapped:(id)sender;
- (IBAction)textFieldDidEndOnExit:(id)sender;

@end
