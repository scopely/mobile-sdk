package com.sponsorpay.sdk.android.testapp.fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sponsorpay.sdk.android.testapp.R;

public class LauncherFragment extends Fragment {
	

	public static final String SHOW_MOCK_KEY = "show.mock.key";
	public static final String SHOW_MEDIATION_KEY = "show.mediation.key";

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		 // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_settings_launcher, container, false);
		
		return view;
	}
	
	
	
	
}
