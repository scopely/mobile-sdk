package com.sponsorpay.sdk.android.testapp.utils;

import com.sponsorpay.sdk.android.utils.SPUrlProvider;
import com.sponsorpay.sdk.android.utils.StringUtils;

public class TestAppUrlsProvider implements SPUrlProvider {

	public static TestAppUrlsProvider INSTANCE = new TestAppUrlsProvider();
	
	private String mOverridingUrl;
	
	private TestAppUrlsProvider() {
	}
	
	@Override
	public String getBaseUrl(String product) {
		if (StringUtils.notNullNorEmpty(mOverridingUrl)) {
			return mOverridingUrl;
		}
		return null;
	}

	public void setOverridingUrl(String mOverrideUrl) {
		this.mOverridingUrl = mOverrideUrl;
	}
	
}
