//
//  SPInterstitialLaunchViewController.m
//  SponsorPayTestApp
//
//  Created by David Davila on 02/11/13.
//  Copyright (c) 2013 SponsorPay. All rights reserved.
//

#import "SPInterstitialLaunchViewController.h"

#define LogInvocation SPLogDebug(@"%s", __PRETTY_FUNCTION__)

@interface SPInterstitialLaunchViewController ()

@property (readonly, strong, nonatomic) SPInterstitialClient *interstitialClient;

@end

@implementation SPInterstitialLaunchViewController
{
    SPInterstitialClient *_interstitialClient;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidDisappear:(BOOL)animated
{
    _interstitialClient = nil;
    [super viewDidDisappear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (SPInterstitialClient *)interstitialClient
{
    if (!_interstitialClient) {
        @try {
            _interstitialClient = [SponsorPaySDK interstitialClient];
            _interstitialClient.delegate = self;
        }
        @catch (NSException *e) {
            [self showSDKException:e];
        }
    }
    return _interstitialClient;
}

- (IBAction)requestInterstitial:(id)sender
{
    [self showActivityIndication];
    [self.interstitialClient checkInterstitialAvailable];
}

- (IBAction)launchInterstitial:(id)sender
{
    [self.interstitialClient showInterstitialFromViewController:self];
}

#pragma mark - SPInterstitialClientDelegate

- (void)interstitialClient:(SPInterstitialClient *)client
       canShowInterstitial:(BOOL)canShowInterstitial
{
    LogInvocation;
    self.launchInterstitialButton.enabled = canShowInterstitial;
    [self stopActivityIndication];
}

- (void)interstitialClientDidShowInterstitial:(SPInterstitialClient *)client
{
    LogInvocation;
}

- (void)interstitialClient:(SPInterstitialClient *)client
didDismissInterstitialWithReason:(SPInterstitialDismissReason)dismissReason
{
    LogInvocation;
    self.launchInterstitialButton.enabled = NO;
    NSString *desc = [NSString stringWithFormat:@"Interstitial dismissed with reason: %@",
                             SPStringFromInterstitialDismissReason(dismissReason)];
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Interstitial dismissed"
                                                       message:desc
                                                      delegate:nil cancelButtonTitle:@"OK"
                                             otherButtonTitles:nil];
    double delayInSeconds = 0.5;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [alertView show];
    });

}

- (void)interstitialClient:(SPInterstitialClient *)client
          didFailWithError:(NSError *)error
{
    LogInvocation;
    NSLog(@"error=%@", error);
    NSString *desc = [NSString stringWithFormat:@"Interstitial client failed with error: %@", error];
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Interstitial error"
                                                        message:desc
                                                       delegate:nil cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
    [alertView show];
}

@end
