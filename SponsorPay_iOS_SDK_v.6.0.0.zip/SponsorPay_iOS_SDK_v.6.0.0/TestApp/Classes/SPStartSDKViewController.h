//
//  SPStartSDKViewController.h
//  SponsorPay Sample App
//
//  Created by David Davila on 1/14/13.
// Copyright 2011-2013 SponsorPay. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SPTestAppBaseViewController.h"

@interface SPStartSDKViewController : SPTestAppBaseViewController <UIAlertViewDelegate>

@property (strong, nonatomic) IBOutlet UITextField *appIdField;
@property (strong, nonatomic) IBOutlet UITextField *userIdField;
@property (strong, nonatomic) IBOutlet UITextField *vcsKeyField;
@property (strong, nonatomic) IBOutlet UITextField *currencyNameField;
@property (strong, nonatomic) IBOutlet UISwitch *showCoinsNotificationSwitch;
@property (strong, nonatomic) IBOutlet UIView *startSDKGroup;
@property (strong, nonatomic) IBOutlet UIView *credentialsSettingsGroup;
@property (strong, nonatomic) IBOutlet UIView *stagingSettingsGroup;

- (IBAction)startSDK;
- (IBAction)userDidEnterCurrencyName:(UITextField *)sender;
- (IBAction)showCoinsNotificationValueChanged:(UISwitch *)sender;
- (IBAction)clearPersistedSDKData;
- (IBAction)openSettings;

@end
