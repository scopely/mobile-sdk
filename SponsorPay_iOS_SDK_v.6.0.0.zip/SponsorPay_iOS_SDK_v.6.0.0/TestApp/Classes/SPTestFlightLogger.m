//
//  SPTestFlightLogger.m
//  SponsorPayTestApp
//
//  Created by Daniel Barden on 07/02/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import "SPTestFlightLogger.h"
#import "TestFlight.h"

@implementation SPTestFlightLogger

+ (instancetype)logger
{
    static SPTestFlightLogger *sharedInstance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[SPTestFlightLogger alloc] init];
        [TestFlight setOptions:@{ TFOptionLogToConsole : @NO }];
        [TestFlight setOptions:@{ TFOptionLogToSTDERR : @NO }];
    });

    return sharedInstance;
}

- (void)logFormat:(NSString *)format arguments:(va_list)arguments
{
    TFLogv(format, arguments);
}
@end
