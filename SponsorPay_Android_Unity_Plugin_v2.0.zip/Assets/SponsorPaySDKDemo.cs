using UnityEngine;
using System;
using System.Collections;
using System.Runtime.InteropServices;

public class SponsorPaySDKDemo : MonoBehaviour {
	AndroidJavaObject androidActivity;

	bool mustKeepPollingForCoins = false;
	bool mustKeepPollingForBannerStatus = false;

	string appId = "1246"; // Leave empty to use the APP ID defined in your Android Manifest
	string userId = "test_user_id_1";
	string securityToken = "12345678";
	string delayForAdvertiserCallback = "0";
	string customCurrencyName = "TestCoins";

	AndroidJavaObject spUnlock;

	string unlockItemId = "TEST_ITEM_ID";
	string unlockItemName = "";
	string unlockItemStatusResults = "Results will appear here.";

	// Use this for initialization
	void Start() {
		AndroidJNI.AttachCurrentThread();

		// Get the Android Activity which will be used in subsequent calls to the SponsorPay plugin
		AndroidJavaClass jc = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
		androidActivity = jc.GetStatic<AndroidJavaObject>("currentActivity");

		androidActivity.Call("setAppId", appId);
	}
	
	void OnGUI() {
		// This will draw the test GUI to show the buttons and fields which let you test the SDK features
		drawTestUI();

		// Check whether we've received any answer from SponsorPay regarding
		// Virtual Currency and Offer Banners, if necessary.
		pollForCoinsStatus();
		pollForBannerStatus();
	}

	void launchSPOfferWall() {
		androidActivity.Call("launchSPOfferWall", userId);
	}
	
	void launchSPInterstitial() {
		androidActivity.Call("launchSPInterstitial", userId);
	}
	
	void sendSPCallbackNow() {
		androidActivity.Call("sendSPCallbackNow");
	}
	
	void sendSPCallbackWithDelay(int delayMin) {
		androidActivity.Call("sendSPCallbackWithDelay", delayMin);
	}
	
	void sendSPDeltaOfCoinsRequest() {
		androidActivity.Call("requestNewCoins", userId, securityToken);
		mustKeepPollingForCoins = true;
	}

	void requestAndShowOfferBanner() {
		androidActivity.Call("requestAndShowOfferBanner", userId, "BOTTOM", customCurrencyName);
		mustKeepPollingForBannerStatus = true;
	}

	void pollForCoinsStatus() {
		if (mustKeepPollingForCoins) {
			if (androidActivity.Call<bool>("didReceiveVCSResponse")) {
				mustKeepPollingForCoins = false;
			
				if (androidActivity.Call<bool>("didLastVCSRequestFail"))
					coinsLabel = "Delta of coins request failed";
				else
					coinsLabel = "Delta of coins: " +
						(androidActivity.Call<double>("getLastReceivedDeltaOfCoins")).ToString() +
						". Transaction ID: " +
						androidActivity.Call<string>("getLastReceivedTransactionId");
			}
		}
	}

	void pollForBannerStatus() {
		if (mustKeepPollingForBannerStatus) {
			if (androidActivity.Call<bool>("didReceiveBannerResponse")) {
				mustKeepPollingForBannerStatus = false;
				
				if (androidActivity.Call<bool>("didLastBannerRequestFail"))
					bannerStatusLabel = "Banner request failed";
				else if (androidActivity.Call<bool>("didLastBannerRequestReturnBanner"))
					bannerStatusLabel = "Banner available";
				else
					bannerStatusLabel = "Banner not available";
			}
		}
	}


	// Test user interface drawing code starts here

	static readonly float ScrollBarWidth = 20;
	static readonly float HorizontalMargin = 8;
	static readonly float GuiRectWidth = 0.7f * (Screen.width - (2 * HorizontalMargin) - ScrollBarWidth);
	static readonly float GuiLabelHeight = 25;
	static readonly float GuiTapTargetHeight = 45;
	static readonly float GuiRectSmallPadding = 0;
	static readonly float GuiRectBigPadding = 15;
	static readonly	float HorizontalPadding = 5;
	static readonly	float BannerHeight = 110;

	string coinsLabel = "";
	string bannerStatusLabel = "";

    Vector2 scrollPosition = Vector2.zero;
    string unlockRequestStatusLabel = "Request Unlock Items status";

	void drawTestUI() {
		float y = 5.0f; // Top margin
		float x = HorizontalMargin;

		Rect outerScrollRect = new Rect(0, 0, Screen.width, Screen.height - BannerHeight);
		Rect innerScrollRect = new Rect(0, 0, Screen.width - ScrollBarWidth, 1200);
        scrollPosition = GUI.BeginScrollView(outerScrollRect, scrollPosition, innerScrollRect, false, true);

		GUI.Label(new Rect(x, y, GuiRectWidth, GuiLabelHeight),  "App ID: (leave empty to use the App ID defined in the manifest)");
		y += GuiLabelHeight + GuiRectSmallPadding;

		string previousAppId = appId;
		appId = GUI.TextField(new Rect(x, y, GuiRectWidth, GuiTapTargetHeight), appId);
		y += GuiTapTargetHeight + GuiRectBigPadding;
		if (!previousAppId.Equals(appId)) {
			androidActivity.Call("setAppId", appId);
		}

		GUI.Label(new Rect(x, y, GuiRectWidth, GuiLabelHeight),  "User ID: ");
		y += GuiLabelHeight + GuiRectSmallPadding;

		userId = GUI.TextField(new Rect(x, y, GuiRectWidth, GuiTapTargetHeight), userId);
		y += GuiTapTargetHeight + GuiRectBigPadding;

		GUI.Label(new Rect(x, y, GuiRectWidth, GuiLabelHeight),  "Security Token: ");
		y += GuiLabelHeight + GuiRectSmallPadding;

		securityToken = GUI.TextField(new Rect(x, y, GuiRectWidth, GuiTapTargetHeight), securityToken);
		y += GuiTapTargetHeight + GuiRectBigPadding;

		if (GUI.Button(new Rect (x, y, GuiRectWidth, GuiTapTargetHeight), "Send advertiser callback now")) {
			sendSPCallbackNow();
		}
		y += GuiTapTargetHeight + GuiRectBigPadding;

		float delayLabelWidth = 300;
		GUI.Label(new Rect(x, y, GuiRectWidth, GuiLabelHeight),  "Delay for advertiser callback (in minutes): ");
		x += delayLabelWidth + HorizontalPadding;

		Int16 delayValue = 0;
		if (!Int16.TryParse(delayForAdvertiserCallback, out delayValue)) {
			delayForAdvertiserCallback = "[invalid value entered]";
		}

		delayForAdvertiserCallback =
			GUI.TextField(new Rect(x, y, GuiRectWidth - x, GuiTapTargetHeight), delayForAdvertiserCallback);
		x = HorizontalMargin;
		y += GuiTapTargetHeight + GuiRectBigPadding;

		if (GUI.Button(new Rect (x, y, GuiRectWidth, GuiTapTargetHeight), "Send advertiser callback with delay of "
			+ delayValue + " minutes")) {
			sendSPCallbackWithDelay(delayValue);
		}
		y += GuiTapTargetHeight + GuiRectBigPadding;

		float buttonWidth = (GuiRectWidth / 3.0f) - (HorizontalPadding);

		if (GUI.Button(new Rect (x, y, buttonWidth, GuiTapTargetHeight), "Launch OfferWall")) {
			launchSPOfferWall();
		}
		x += buttonWidth + HorizontalPadding;

		if (GUI.Button(new Rect (x, y, buttonWidth, GuiTapTargetHeight), "Launch Interstitial")) {
			launchSPInterstitial();
		}
		x += buttonWidth + HorizontalPadding;

		if (GUI.Button(new Rect (x, y, buttonWidth, GuiTapTargetHeight), "Get delta of coins")) {
			coinsLabel = "Waiting for response from VCS...";
			sendSPDeltaOfCoinsRequest();
		}
		x = HorizontalMargin;
		y += GuiTapTargetHeight + GuiRectSmallPadding;

		GUI.Label(new Rect(x, y, GuiRectWidth, GuiLabelHeight),  coinsLabel);
		y += GuiLabelHeight + GuiRectBigPadding;

		GUI.Label(new Rect(x, y, GuiRectWidth, GuiLabelHeight),  "Custom currency name: (leave empty to use default)");
		y += GuiLabelHeight + GuiRectSmallPadding;

		customCurrencyName = GUI.TextField(new Rect(x, y, GuiRectWidth, GuiTapTargetHeight), customCurrencyName);
		y += GuiTapTargetHeight + GuiRectBigPadding;

		if (GUI.Button(new Rect (x, y, GuiRectWidth, GuiTapTargetHeight), "Request and show Offer Banner")) {
			bannerStatusLabel = "Waiting for banner...";
			requestAndShowOfferBanner();
		}
		y += GuiTapTargetHeight + GuiRectSmallPadding;

		GUI.Label(new Rect(x, y, GuiRectWidth, GuiLabelHeight),  bannerStatusLabel);
		y += GuiLabelHeight + GuiRectSmallPadding;

		GUI.Label(new Rect(x, y, buttonWidth, GuiLabelHeight),  "Item ID:");
		x += buttonWidth + HorizontalPadding;

		GUI.Label(new Rect(x, y, buttonWidth, GuiLabelHeight),  "Item Name:");
		x = HorizontalMargin;
		y += GuiLabelHeight + GuiRectSmallPadding;

		unlockItemId = GUI.TextField(new Rect(x, y, buttonWidth, GuiTapTargetHeight), unlockItemId);
		x += buttonWidth + HorizontalPadding;

		unlockItemName = GUI.TextField(new Rect(x, y, buttonWidth, GuiTapTargetHeight), unlockItemName);
		x += buttonWidth + HorizontalPadding;

		if (GUI.Button(new Rect (x, y, buttonWidth, GuiTapTargetHeight), "Launch Unlock OW")) {
			launchSPUnlockOfferWall();
		}
		x = HorizontalMargin;
		y += GuiTapTargetHeight + GuiRectBigPadding;

		if (GUI.Button(new Rect (x, y, GuiRectWidth, GuiTapTargetHeight), unlockRequestStatusLabel)) {
			unlockRequestStatusLabel = "Waiting for unlock status request response...";
			requestSPUnlockItemsStatus();
		}

		y += GuiTapTargetHeight + GuiRectBigPadding;

		GUI.Label(new Rect(x, y, GuiRectWidth, GuiLabelHeight),  "Unlock Items status response:");
		y += GuiLabelHeight + GuiRectSmallPadding;

		unlockItemStatusResults = GUI.TextArea(new Rect(x, y, GuiRectWidth, 350), unlockItemStatusResults);

		GUI.EndScrollView();
	}

	void initSPUnlock() {
		spUnlock = new AndroidJavaObject("com.sponsorpay.sdk.android.unity.SPUnlock");
		spUnlock.Call("setListenerObjectName", "GameObject");
	}

	void updateSPUnlock() {
 		if (null == spUnlock) {
			initSPUnlock();
		}		

		spUnlock.Call("setAppId", appId);
		spUnlock.Call("setUserId", userId);
		spUnlock.Call("setSecurityToken", securityToken);
	}

	void launchSPUnlockOfferWall() {
		updateSPUnlock();
		spUnlock.Call("launchUnlockOfferWall", unlockItemId, unlockItemName);
	}

	void requestSPUnlockItemsStatus() {
		updateSPUnlock();
		spUnlock.Call("requestItemsStatus");
	}

	// Called asynchronously from the SponsorPay SDK when an answer to the request for Unlock Items status is received.
	void onSPUnlockItemsStatusResponseReceived(String message) {
		// Determine whether the request was successful
		bool success = message.Equals(spUnlock.GetStatic<String>("REQUEST_RESULT_SUCCESS"));

		// Restore the label of the UI button used to trigger this call.
		unlockRequestStatusLabel = "Request Unlock Items status";

		// Get an array of all the Unlock Item IDs
		String[] ids = spUnlock.Call<String[]>("getUnlockItemIDs");

		String resultsAsString;
		if (success) {
			// Update the UI with the success message and a the list of Unlock Items received.
			resultsAsString = String.Format("Response: {0}, Item count: {1}\n---------------\n", message, ids.Length);

			for (int i = 0; i < ids.Length; i++) {
				// We get the data from each item through calls to the Java side
				String itemId = ids[i];
				String itemName = spUnlock.Call<String>("getNameForItem", itemId);
				bool unlocked = spUnlock.Call<bool>("getUnlockStatusForItem", itemId);
				long unlockTimestamp = spUnlock.Call<long>("getUnlockTimestampForItem", itemId);

				// Add line to the results box on the UI
				resultsAsString += String.Format("\nItem ID: [{0}] Name: [{1}] Unlocked: [{2}] Timestamp: [{3}]\n",
					itemId, itemName, unlocked, unlockTimestamp); 
			}
		} else {
			// Update the UI with information about the error
			String errorType = spUnlock.Call<String>("getLastErrorType");
			if (null == errorType) errorType = "- - -";

			String errorCode = spUnlock.Call<String>("getLastErrorCode");
			if (null == errorCode) errorCode = "- - -";

			String errorMessage = spUnlock.Call<String>("getLastErrorMessage");
			if (null == errorMessage) errorMessage = "- - -";

			resultsAsString = String.Format("Response: {0}\n---------------\nError Type: {1}\nError Code: {2}\nError Message: {3}\n",
				message, errorType, errorCode, errorMessage);
		}

		unlockItemStatusResults = resultsAsString;
	}
}
