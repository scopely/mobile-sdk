package com.sponsorpay.sdk.android.unity.SPUnityDemo;

import android.os.Bundle;
import com.unity3d.player.*;

import android.os.Looper;
import android.os.Handler;
import android.util.Log;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Gravity;
import android.widget.LinearLayout;

import com.sponsorpay.sdk.android.publisher.SponsorPayPublisher;
import com.sponsorpay.sdk.android.advertiser.SponsorPayAdvertiser;
import com.sponsorpay.sdk.android.publisher.currency.CurrencyServerAbstractResponse;
import com.sponsorpay.sdk.android.publisher.currency.CurrencyServerDeltaOfCoinsResponse;
import com.sponsorpay.sdk.android.publisher.currency.SPCurrencyServerListener;
import com.sponsorpay.sdk.android.publisher.currency.VirtualCurrencyConnector;
import com.sponsorpay.sdk.android.publisher.OfferBanner;
import com.sponsorpay.sdk.android.publisher.OfferBannerRequest;
import com.sponsorpay.sdk.android.publisher.SPOfferBannerListener;

public class SPActivity extends UnityPlayerActivity {
	private static final String SPONSORPAY_ACTIVITY_LOG_TAG = "SPActivity";
	private static final String BANNER_POSITION_TOP = "TOP";
	private static final String BANNER_POSITION_BOTTOM = "BOTTOM";

	Handler mMainThreadHandler = new Handler(Looper.getMainLooper());

	String mAppId = null;

	LinearLayout bannerContainer;

	protected void onCreate (Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.d(SPONSORPAY_ACTIVITY_LOG_TAG, "onCreate called (7)");
	}
	
	private void setAppId(String appId) {
		mAppId = appId;
	}

	public void launchSPOfferWall(String userId) {
		Intent offerWallIntent = SponsorPayPublisher.getIntentForOfferWallActivity(getApplicationContext(),
			userId, true, mAppId);
		startActivityForResult(offerWallIntent, SponsorPayPublisher.DEFAULT_OFFERWALL_REQUEST_CODE);
	}
	
	public void launchSPInterstitial(final String userId) {		
		mMainThreadHandler.post( new Runnable() {
			public void run() {
				SponsorPayPublisher.loadShowInterstitial(SPActivity.this, userId, null, false, null, null, 0, mAppId);
			}
		});		
	}
	
	public void sendSPCallbackNow() {
		mMainThreadHandler.post( new Runnable() {
			public void run() {
				SponsorPayAdvertiser.register(SPActivity.this.getApplicationContext(), mAppId);
			}
		});
	}

	public void sendSPCallbackWithDelay(final int delayMin) {
		mMainThreadHandler.post(new Runnable() {
			public void run() {
				SponsorPayAdvertiser.registerWithDelay(SPActivity.this.getApplicationContext(), delayMin, mAppId);
			}			
		});
	}

	boolean mDidReceiveVCSResponse = false;
	boolean mDidLastVCSRequestFail = false;
	double mLastReceivedDeltaOfCoins = 0.0;
	String mLastReceivedTransactionId = "";

	public void requestNewCoins(final String userId, final String securityToken) {
		mDidReceiveVCSResponse = false;

		final SPCurrencyServerListener requestListener = new SPCurrencyServerListener() {
			@Override
			public void onSPCurrencyServerError(CurrencyServerAbstractResponse response) {
				mDidReceiveVCSResponse = true;
				mDidLastVCSRequestFail = true;
			}

			@Override
			public void onSPCurrencyDeltaReceived(CurrencyServerDeltaOfCoinsResponse response) {
				mDidReceiveVCSResponse = true;
				mDidLastVCSRequestFail = false;
				mLastReceivedDeltaOfCoins = response.getDeltaOfCoins();
				mLastReceivedTransactionId = response.getLatestTransactionId();
			}
		};

		mMainThreadHandler.post ( new Runnable() {
			public void run() {
				SponsorPayPublisher.requestNewCoins(SPActivity.this.getApplicationContext(), userId,
					requestListener, null, securityToken, mAppId);
			}
		});
	}

	public boolean didLastVCSRequestFail() {
		return mDidLastVCSRequestFail;
	}

	public boolean didReceiveVCSResponse() {
		return mDidReceiveVCSResponse;
	}

	public double getLastReceivedDeltaOfCoins() {
		return mLastReceivedDeltaOfCoins;
	}

	public String getLastReceivedTransactionId() {
		return mLastReceivedTransactionId != null ? mLastReceivedTransactionId : "";
	}

	private boolean mDidReceiveBannerResponse = false;
	private boolean mDidLastBannerRequestFail = false;
	private boolean mDidLastBannerRequestReturnBanner = false;

	public void requestAndShowOfferBanner(final String userId, final String position, final String currencyName) {
		mDidReceiveBannerResponse = false;

		final SPOfferBannerListener listener = new SPOfferBannerListener() {
			@Override
			public void onSPOfferBannerAvailable(OfferBanner banner) {
				mDidReceiveBannerResponse = true;
				mDidLastBannerRequestFail = false;
				mDidLastBannerRequestReturnBanner = true;

				if (bannerContainer == null) {
					bannerContainer = new LinearLayout(getApplicationContext());
					bannerContainer.setOrientation(LinearLayout.VERTICAL);
					
					getWindow().addContentView(bannerContainer,
						new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT,
												   ViewGroup.LayoutParams.FILL_PARENT));
				}
				bannerContainer.removeAllViews();

				if (BANNER_POSITION_TOP.equals(position))
					bannerContainer.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.TOP);
				else if (BANNER_POSITION_BOTTOM.equals(position))
					bannerContainer.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM);

				View bannerView = banner.getBannerView(SPActivity.this);
				bannerContainer.addView(bannerView,
					new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
											   ViewGroup.LayoutParams.WRAP_CONTENT));
			}
			@Override
			public void onSPOfferBannerNotAvailable(OfferBannerRequest bannerRequest) {
				mDidReceiveBannerResponse = true;
				mDidLastBannerRequestFail = false;
				mDidLastBannerRequestReturnBanner = false;
			}
			@Override
			public void onSPOfferBannerRequestError(OfferBannerRequest bannerRequest) {
				mDidReceiveBannerResponse = true;
				mDidLastBannerRequestFail = true;
				mDidLastBannerRequestReturnBanner = false;
			}
		};
	
		mMainThreadHandler.post( new Runnable() {
			public void run() {
				SponsorPayPublisher.requestOfferBanner(getApplicationContext(), userId, listener, null,
					currencyName, mAppId);
				}
			});
	}

	public boolean didReceiveBannerResponse() {
		return mDidReceiveBannerResponse;
	}

	public boolean didLastBannerRequestFail() {
		return mDidLastBannerRequestFail;
	}

	public boolean didLastBannerRequestReturnBanner() {
		return mDidLastBannerRequestReturnBanner;
	}

	public void removeOfferBanner() {
		if (bannerContainer != null) {
			bannerContainer.removeAllViews();
		}
	}
}