package com.sponsorpay.sdk.android.unity;

import java.util.Map;

import android.os.Looper;
import android.os.Handler;
import android.content.Intent;
import android.util.Log;

import com.unity3d.player.*;

import com.sponsorpay.sdk.android.publisher.SponsorPayPublisher;
import com.sponsorpay.sdk.android.publisher.unlock.SPUnlockResponseListener;
import com.sponsorpay.sdk.android.publisher.AbstractResponse;
import com.sponsorpay.sdk.android.publisher.unlock.UnlockedItemsResponse;

public class SPUnlock {

	public static final String REQUEST_RESULT_ERROR = "REQUEST_RESULT_ERROR";
	public static final String REQUEST_RESULT_SUCCESS = "REQUEST_RESULT_SUCCESS";

	private String mUserId;
	private String mSecurityToken;
	private String mAppId;
	private String mListenerObjectName;

	private Handler mMainThreadHandler;

	private AbstractResponse lastSPUnlockErrorResponse;
	private UnlockedItemsResponse lastSPUnlockSuccessResponse;

	public void setUserId(String userId) {
		mUserId = userId;
	}

	public void setSecurityToken(String securityToken) {
		mSecurityToken = securityToken;
	}

	public void setAppId(String appId) {
		mAppId = appId;
	}

	public void setListenerObjectName(String listenerObjectName) {
		mListenerObjectName = listenerObjectName;
	}

	public SPUnlock() {
		this(null, null, null, null);
	}

	public SPUnlock(String userId, String securityToken, String appId, String listenerObjectName) {
		setUserId(userId);
		setSecurityToken(securityToken);
		setAppId(appId);
		setListenerObjectName(listenerObjectName);
	}

	private void checkUserId() {
		if (!checkStringFieldValue(mUserId)) {
			throw illegalStateExceptionForMissingValueOfFieldWithName("userId");
		}
	}

	private void checkSecurityToken() {
		if (!checkStringFieldValue(mSecurityToken)) {
			throw illegalStateExceptionForMissingValueOfFieldWithName("securityToken");
		}
	}

	private void checkListenerObjectName() {
		if (!checkStringFieldValue(mListenerObjectName)) {
			throw illegalStateExceptionForMissingValueOfFieldWithName("listenerObjectName");
		}
	}

	private static boolean checkStringFieldValue(String value) {
		return null != value && !"".equals(value);
	}

	private static IllegalStateException illegalStateExceptionForMissingValueOfFieldWithName(String fieldName) {
		String className = SPUnlock.class.getSimpleName();
		String message = String.format("SponsorPay SDK: no valid %s has been provided to this %s instance. ",
			fieldName, className);
			
		return new IllegalStateException(message);		
	}

	public void requestItemsStatus() {

		checkUserId();
		checkSecurityToken();
		checkListenerObjectName();
		// App ID might have been provided in the manifest

		final SPUnlockResponseListener listener = new SPUnlockResponseListener() {
			@Override
			public void onSPUnlockRequestError(AbstractResponse response) {
				lastSPUnlockErrorResponse = response;
				// Notify the Unity side of the error status
				UnityPlayer.UnitySendMessage(mListenerObjectName, "onSPUnlockItemsStatusResponseReceived",
					REQUEST_RESULT_ERROR);
			}

			@Override
			public void onSPUnlockItemsStatusResponseReceived(UnlockedItemsResponse response) {
				lastSPUnlockSuccessResponse = response;
				// Notify the Unity side of the response
				UnityPlayer.UnitySendMessage(mListenerObjectName, "onSPUnlockItemsStatusResponseReceived",
					REQUEST_RESULT_SUCCESS);
			}
		};

		if (null == mMainThreadHandler) {
			mMainThreadHandler = new Handler(Looper.getMainLooper());
		}
 		
		mMainThreadHandler.post ( new Runnable() {
			public void run() {
				SponsorPayPublisher.requestUnlockItemsStatus(UnityPlayer.currentActivity.getApplicationContext(),
					mUserId, listener, mSecurityToken, mAppId, null);
			}
		});
	}

	public Map<String, UnlockedItemsResponse.Item> extractItemsFromSuccessResponse() {
		if (null == lastSPUnlockSuccessResponse) {
			return null;
		}

		Map<String, UnlockedItemsResponse.Item> items = lastSPUnlockSuccessResponse.getItems();

		return items;
	}

	public String[] getUnlockItemIDs() {
		Map<String, UnlockedItemsResponse.Item> items = extractItemsFromSuccessResponse();

		if (null == items) {
			return null;
		}

		String[] itemIDs = new String[items.size()];

		itemIDs = items.keySet().toArray(itemIDs);
		return itemIDs;
	}

	public UnlockedItemsResponse.Item getItem(String itemID) {
		Map<String, UnlockedItemsResponse.Item> items = extractItemsFromSuccessResponse();

		if (null == items) {
			return null;
		}

		return items.get(itemID);		
	}

	public String getNameForItem(String itemID) {
		UnlockedItemsResponse.Item item = getItem(itemID);
		return item == null ? null : item.getName();
	}

	public boolean getUnlockStatusForItem(String itemID) {
		UnlockedItemsResponse.Item item = getItem(itemID);
		return item == null ? null : item.isUnlocked();
	}

	public long getUnlockTimestampForItem(String itemID) {
		UnlockedItemsResponse.Item item = getItem(itemID);
		return item == null ? null : item.getTimestamp();
	}

	public void launchUnlockOfferWall(String unlockItemId, String unlockItemName) {
		checkUserId();

		Log.d(getClass().getSimpleName(), "launching unlock offerwall for item id: " + unlockItemId + " item name: " + unlockItemName);

		Intent unlockOfferWallIntent =
			SponsorPayPublisher.getIntentForUnlockOfferWallActivity(UnityPlayer.currentActivity.getApplicationContext(),
				mUserId, unlockItemId, unlockItemName, mAppId, null);
		UnityPlayer.currentActivity.startActivityForResult(unlockOfferWallIntent,
			SponsorPayPublisher.DEFAULT_UNLOCK_OFFERWALL_REQUEST_CODE);
	}

	public String getLastErrorType() {
		if (lastSPUnlockErrorResponse == null) {
			return null;
		}
		if (lastSPUnlockErrorResponse.getErrorType() == null) {
			return null;
		}
		return lastSPUnlockErrorResponse.getErrorType().toString();
	}

	public String getLastErrorCode() {
		if (lastSPUnlockErrorResponse == null) {
			return null;
		}
		return lastSPUnlockErrorResponse.getErrorCode();
	}

	public String getLastErrorMessage() {
		if (lastSPUnlockErrorResponse == null) {
			return null;
		}
		return lastSPUnlockErrorResponse.getErrorMessage();
	}
}