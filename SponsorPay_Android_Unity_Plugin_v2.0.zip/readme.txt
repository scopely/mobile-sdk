The SponsorPay Unity plugin for Android comes with a sample Unity project which can be run to see a demonstration of how to use SponsorPay SDK's features from Unity, like:

* Sending the Advertiser Callback right away or with a customized delay
* Launching the OfferWall
* Launching the Interstitial
* Communicate with the VCS to get the Delta of Coins
* Request and show an Offer Banner

Follow these steps to integrate SponsorPay into your Unity Android project:

** SDK SETUP **

This process varies depending on whether you are already using an Android plugin from your Unity project or not.

*** If you don't have any other Android plugin in your Unity project / you don't have an Assets/Plugins/Android folder inside your Unity project, follow these steps:

1. Copy the Assets/Plugins/Android folder (which you can find inside the SponsorPayUnityAndroid project folder) into the Assets/Plugins folder of your own Unity project (if your Assets folder doesn't contain a Plugins folder, just create it).

2. Inside the Assets/Plugins/Android folder, modify the AndroidManifest file:
	
	- Change the package manifest attribute to reflect your own package name
	- Change the Application ID in the meta-data (SPONSORPAY_APP_ID) to you own one 
	- Make sure that application's name and icon point to the right resources

3. Reflect your own package name as well in the provided overriden Android Activity (Assets/Plugins/Android/src/SPActivity.java). Optionally, rename the Activity itself (both the Activity class name and the file name must match, and you'll have to check that the right main activity name is set in your Android manifest), and in your Unity's Bundle Identifier.

4. To build the provided Android project into a JAR file that Unity can make use of, edit the Android/build.properties file to reflect the location of your Android platform JAR file and your Unity Player classes.jar file, and use Ant to build the project:
	
	$ ant create_JAR



***  If you already are using an Android plugin for Unity, and have a Plugins/Android folder, follow these steps:

1. Add to your existing Android Application Manifest the following content inside the <application> element, replacing the provided sample Application ID with your own one:

	<!-- Activity used to show SponsorPay's Mobile Offer Wall -->
	<activity android:name="com.sponsorpay.sdk.android.publisher.OfferWallActivity"
		android:configChanges="orientation" />

	<!-- Activity used to show SponsorPay's Mobile Interstitial -->
	<activity android:name="com.sponsorpay.sdk.android.publisher.InterstitialActivity"
		android:configChanges="orientation" />

	<!-- The publisher ID assigned by SponsorPay -->
	<meta-data android:value="2070" android:name="SPONSORPAY_APP_ID" />

2. Make sure your application manifest requests the permission to access the Internet:

		<uses-permission android:name="android.permission.INTERNET" />

3. In addition, if you want the SponsorPay SDK to be able to access some hardware unique identifiers, add the following permissions:

	<uses-permission android:name="android.permission.READ_PHONE_STATE" />
	<uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />

4. Add the sponsorpay-android-sdk.jar file to your Java build path.

5. Merge the contents of the provided SPActivity.java with your own overriden Application Activity.

6. Build the Android part of your Unity project as usually.


** USING THE SDK **

An example script which uses each of the SDK features is provided in the sample project as Assets/SponsorPaySDKDemo.cs.

Most of the methods included in this script can be partially reused in your own code. It demonstrates how to send the advertiser callback, launch the SponsorPay OfferWall and the Interstitial, request and show an Offer Banner and request the delta of coins as well as the status of the Unlock Items, and how to get responses back from the SDK.

It also includes code to draw a test UI which triggers calls to the SDK and displays its responses.
