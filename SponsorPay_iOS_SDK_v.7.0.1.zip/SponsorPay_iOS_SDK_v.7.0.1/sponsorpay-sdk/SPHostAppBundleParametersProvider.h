//
//  SPHostAppBundleParametersProvider.h
//  SponsorPay iOS SDK
//
//  Created by David Davila on 11/2/12.
//  Copyright (c) 2012 SponsorPay. All rights reserved.
//

#import "SPURLParametersProvider.h"

@interface SPHostAppBundleParametersProvider : NSObject<SPURLParametersProvider>

@end
