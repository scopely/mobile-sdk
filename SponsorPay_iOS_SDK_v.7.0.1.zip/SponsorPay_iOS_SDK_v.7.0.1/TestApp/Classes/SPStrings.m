//
//  SPStrings.m
//  SponsorPayTestApp
//
//  Created by Pierre Bongen on 27.05.14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import "SPStrings.h"

