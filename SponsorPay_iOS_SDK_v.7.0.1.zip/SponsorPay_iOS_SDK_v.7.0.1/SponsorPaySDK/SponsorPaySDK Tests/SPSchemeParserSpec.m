//
//  SPSchemeParserSpec.m
//  SponsorPaySDK
//
//  Created by Titouan on 19/06/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import <Specta/Specta.h>
#define EXP_SHORTHAND
#import <Expecta/Expecta.h>

#import "SPSchemeParser.h"
#import "SPScheme.h"
#import "NSString+SPURLEncoding.h"

SpecBegin(SPSchemeParser) describe(@"SPSchemeParser", ^{
    __block SPScheme *returnedScheme;

    beforeEach(^{});

    // Parsing

    it(@"returns nil if passed nil", ^{
        returnedScheme = [SPSchemeParser parseUrl:nil];
        expect(returnedScheme).to.beNil();
    });

    it(@"returns nil if passed something else than NSURL|NSString", ^{
        returnedScheme = [SPSchemeParser parseUrl:[NSArray new]];
        expect(returnedScheme).to.beNil();
    });

    it(@"returns a scheme with a urlScheme that is not sponsorpay if the passed url's scheme is not sponsorpay", ^{
        returnedScheme = [SPSchemeParser parseUrl:@"http://iframe.sponsorpay.com/"];
        expect([returnedScheme isSponsorPayScheme]).to.beFalsy;
    });

    it(@"returns a scheme with a urlScheme that is sponsorpay if the passed url's scheme is sponsorpay", ^{
        returnedScheme = [SPSchemeParser parseUrl:@"sponsorpay://start"];
        expect([returnedScheme isSponsorPayScheme]).to.beTruthy;
    });


    describe(@"Command Types", ^{
        it(@"returns the SPSchemeCommandTypeRequestOffers commandType", ^{
            returnedScheme = [SPSchemeParser parseUrl:@"sponsorpay://requestOffers"];
            expect([returnedScheme commandType]).to.equal(SPSchemeCommandTypeRequestOffers);
        });

        it(@"returns the SPSchemeCommandTypeStart commandType", ^{
            returnedScheme = [SPSchemeParser parseUrl:@"sponsorpay://start"];
            expect([returnedScheme commandType]).to.equal(SPSchemeCommandTypeStart);
        });

        it(@"returns the SPSchemeCommandTypeExit commandType", ^{
            returnedScheme = [SPSchemeParser parseUrl:@"sponsorpay://exit"];
            expect([returnedScheme commandType]).to.equal(SPSchemeCommandTypeExit);
        });

        it(@"returns the SPSchemeCommandTypeInstall commandType", ^{
            returnedScheme = [SPSchemeParser parseUrl:@"sponsorpay://install"];
            expect([returnedScheme commandType]).to.equal(SPSchemeCommandTypeInstall);
        });

        it(@"returns the SPSchemeCommandTypeValidate commandType", ^{
            returnedScheme = [SPSchemeParser parseUrl:@"sponsorpay://validate"];
            expect([returnedScheme commandType]).to.equal(SPSchemeCommandTypeValidate);
        });

        it(@"returns the SPSchemeCommandTypePlayLocal commandType", ^{
            returnedScheme = [SPSchemeParser parseUrl:@"sponsorpay://play?tpn=local"];
            expect([returnedScheme commandType]).to.equal(SPSchemeCommandTypePlayLocal);
        });

        it(@"returns the SPSchemeCommandTypePlayTPN commandType", ^{
            returnedScheme = [SPSchemeParser parseUrl:@"sponsorpay://play?tpn=anytpn"];
            expect([returnedScheme commandType]).to.equal(SPSchemeCommandTypePlayTPN);
        });
    });


    describe(@"Parameters", ^{
        it(@"appId with 'install' command", ^{
            NSString *appId = @"12397";
            returnedScheme = [SPSchemeParser parseUrl:[NSString stringWithFormat:@"sponsorpay://install?id=%@", appId]];
            expect(returnedScheme.appId).to.equal(appId);
        });

        it(@"appId with other command", ^{
            NSString *appId = @"13756";
            returnedScheme = [SPSchemeParser parseUrl:[NSString stringWithFormat:@"sponsorpay://start?id=%@", appId]];
            expect(returnedScheme.appId).to.equal(nil);
        });

        it(@"status", ^{
            NSString *status = @"STARTED";
            returnedScheme = [SPSchemeParser parseUrl:[NSString stringWithFormat:@"sponsorpay://start?status=%@", status]];
            expect(returnedScheme.status).to.equal(status);
        });

        it(@"tpnName", ^{
            NSString *tpnName = @"applovin";
            returnedScheme = [SPSchemeParser parseUrl:[NSString stringWithFormat:@"sponsorpay://validate?tpn=%@", tpnName]];
            expect(returnedScheme.tpnName).to.equal(tpnName);
        });

        it(@"tpnId", ^{
            NSString *tpnId = @"21763";
            NSDictionary *contextData = @{ @"id": tpnId };

            returnedScheme = [SPSchemeParser parseUrl:[NSString stringWithFormat:@"sponsorpay://play?id=%@", tpnId]];
            expect(returnedScheme.tpnId).to.equal(tpnId);
            expect(returnedScheme.contextData).to.equal(contextData);
        });

        it(@"externalDestination & urlString", ^{
            NSString *urlString = @"http%3A%2F%2Fwww2.balao.de%2FSHB2E%3Faff_sub%3Dd9763712f7c511e3846a803490c06636%26aff_sub4%"
            @"3D8058%26aff_sub5%3D658972598%26params%3D%252526adv_sub%"
            @"25253Dd9763712f7c511e3846a803490c06636%252526PID%25253D658972598";
            NSString *expectedString = [[urlString SPURLDecodedString] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            returnedScheme = [SPSchemeParser parseUrl:[NSString stringWithFormat:@"sponsorpay://exit?url=%@", urlString]];
            expect(returnedScheme.urlString).to.equal(expectedString);
        });

        it(@"showAlert", ^{
            returnedScheme = [SPSchemeParser parseUrl:[NSString stringWithFormat:@"sponsorpay://play?showAlert=true"]];
            expect(returnedScheme.showAlert).to.beTruthy();
        });
        
        it(@"alertMessage", ^{
            NSString *alertMessage = @"If you leave now, you won't get rewarded";
            NSString *alertMessageEncoded = [alertMessage SPURLEncodedString];
            returnedScheme = [SPSchemeParser parseUrl:[NSString stringWithFormat:@"sponsorpay://play?alertMessage=%@", alertMessageEncoded]];
            expect(returnedScheme.alertMessage).to.equal(alertMessage);
        });
        
        it(@"numberOfOffers", ^{
            NSInteger numberOfOffers = 1;
            returnedScheme = [SPSchemeParser parseUrl:[NSString stringWithFormat:@"sponsorpay://requestOffers?n=%ld", (long)numberOfOffers]];
            expect(returnedScheme.numberOfOffers).to.equal(numberOfOffers);
        });
    });
    
    it(@"requests closing on the offer wall", ^{
        returnedScheme = [SPSchemeParser parseUrl:@"sponsorpay://exit"];
        expect(returnedScheme.requestsClosing).to.beFalsy;
        returnedScheme.shouldRequestCloseWhenOpeningExternalURL = YES;
        expect(returnedScheme.requestsClosing).to.beTruthy;
    });
    
    afterEach(^{ returnedScheme = nil; });
});

SpecEnd
