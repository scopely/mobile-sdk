//
//  SPMobileBrandEngage.m
//  SponsorPaySDK
//
//  Created by tito on 30/09/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#define EXP_SHORTHAND
#import <Specta/Specta.h>
#import <Expecta/Expecta.h>

#import "SPBrandEngageClient.h"
#import "SponsorPaySDK.h"

@interface SPBrandEngageClient ()

- (NSURL *)requestURLForMBE;

@end


SpecBegin(SPMobileBrandEngage)

describe(@"SPMobileBrandEngage", ^{
    __block SPBrandEngageClient *sut;

    beforeEach(^{
        sut = [[SPBrandEngageClient alloc] init];
    });

    it(@"should set the placementId of the client when using the +[SponsorPaySDK requestBrandEngageOffersNotifyingDelegate] method", ^{
        NSString *placementId = @"";
        NSString *credentials = [SponsorPaySDK startForAppId:@"8058"
                              userId:@"someRandomId"
                       securityToken:nil];

        [SponsorPaySDK brandEngageClientForCredentials:credentials];
        [SponsorPaySDK requestBrandEngageOffersNotifyingDelegate:nil];
        expect([SponsorPaySDK brandEngageClient].placementId).to.equal(placementId);
    });

    it(@"should set the placementId of the client to @\"\" when using the +[SponsorPaySDK requestBrandEngageOffersNotifyingDelegate:placementId] method", ^{
        NSString *placementId = @"PLACEMENT_ID";
        NSString *credentials = [SponsorPaySDK startForAppId:@"8058"
                                                      userId:@"someRandomId"
                                               securityToken:nil];

        [SponsorPaySDK brandEngageClientForCredentials:credentials];
        [SponsorPaySDK requestBrandEngageOffersNotifyingDelegate:nil placementId:placementId];
        expect([SponsorPaySDK brandEngageClient].placementId).to.equal(placementId);
    });

    it(@"should set the placementId of the client when using the -checkInterstitialAvailableForPlacementId method", ^{
        NSString *placementId = @"PLACEMENT_ID";
        [sut requestOffersForPlacementId:placementId];
        expect(sut.placementId).to.equal(placementId);
    });

    it(@"should set the placementId of the client to @\"\" when using the -checkInterstitialAvailable method", ^{
        NSString *placementId = @"";
        [sut requestOffersForPlacementId:placementId];
        expect(sut.placementId).to.equal(placementId);
    });

    it(@"the placement_id request param should be an empty string if not provided by the publisher", ^{
        NSString *placementId = nil;
        sut.placementId = placementId;

        NSURL *URL = [sut requestURLForMBE];
        NSString *query = [URL query];
        NSString *param = [NSString stringWithFormat:@"placement_id=%@", @""];
        expect(query).to.contain(param);
    });

    it(@"the placement_id request param should contain the provided value otherwise", ^{
        NSString *placementId = @"PLACEMENT_ID";
        sut.placementId = placementId;

        NSURL *URL = [sut requestURLForMBE];
        NSString *query = [URL query];
        NSString *param = [NSString stringWithFormat:@"placement_id=%@", placementId];
        expect(query).to.contain(param);
    });

});

SpecEnd
