//
//  SPVirtualCurrencyServerConnectorSpecDelegate.h
//  SponsorPaySDK
//
//  Created by Daniel Barden on 18/09/14.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SPVirtualCurrencyServerConnector.h"

@interface SPVirtualCurrencyServerConnectorSpecDelegate : NSObject <SPVirtualCurrencyConnectionDelegate>

@property (nonatomic, strong, readonly) SPVirtualCurrencyServerConnector *vcs;
@property (nonatomic, assign, readonly) NSInteger deltaOfCoins;
@property (nonatomic, copy, readonly) NSString *currencyName;

@property (nonatomic, assign, readonly) SPVirtualCurrencyRequestErrorType errorType;
@property (nonatomic, strong, readonly) NSString *errorCode;
@property (nonatomic, strong, readonly) NSString *errorMessage;

@end
