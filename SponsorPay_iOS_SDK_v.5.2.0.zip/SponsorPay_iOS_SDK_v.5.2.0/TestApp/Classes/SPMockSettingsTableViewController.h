//
//  SPMockSettingsTableViewController.h
//  SponsorPay Sample App
//
//  Created by David Davila on 6/14/13.
// Copyright 2011-2013 SponsorPay. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SPMockTPNAdapter.h"

@interface SPMockSettingsTableViewController : UITableViewController

@property (weak) SPMockTPNAdapter *mockAdapter;

@end

@interface SPMockAdapterSetting : NSObject

@property (strong, readonly) NSString *caption;

@property (readonly) SPMockValidationBehavior validationBehavior;
@property (readonly) SPTPNValidationResult validationResult;

@property (readonly) SPMockPlayingBehavior playingBehavior;
@property (readonly) SPTPNVideoEvent finalVideoEvent;

+ (instancetype)settingWithCaption:(NSString *)caption
                validationBehavior:(SPMockValidationBehavior)validationBehavior
                  validationResult:(SPTPNValidationResult)validationResult;


+ (instancetype)settingWithCaption:(NSString *)caption
                  validationResult:(SPTPNValidationResult)validationResult;


+ (instancetype)settingWithCaption:(NSString *)caption
                   playingBehavior:(SPMockPlayingBehavior)playingBehavior
                   finalVideoEvent:(SPTPNVideoEvent)finalVideoEvent;

@end