//
//  SPMockSettingsTableViewController.m
//  SponsorPay Sample App
//
//  Created by David Davila on 6/14/13.
// Copyright 2011-2013 SponsorPay. All rights reserved.
//

#import "SPMockSettingsTableViewController.h"

static NSString * const kCellIdentifier = @"Cell";

static NSString *validationBehaviorToString(SPMockValidationBehavior validationBehavior);
static NSString *playingBehaviorToString(SPMockPlayingBehavior playingBehavior);

@interface SPMockSettingsTableViewController ()

@property (strong, nonatomic) NSArray *settings;

@end

@implementation SPMockSettingsTableViewController
{
    NSMutableArray *_settings;
}

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
//        if ([self.tableView respondsToSelector:@selector(registerClass:forCellReuseIdentifier:)])
//            [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:kCellIdentifier];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.clearsSelectionOnViewWillAppear = NO;

    UIBarButtonItem *doneButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Done"
                                                                       style:UIBarButtonItemStyleDone
                                                                      target:self action:@selector(doneButtonPressed)];
    self.navigationItem.rightBarButtonItem = doneButtonItem;

}

- (void)doneButtonPressed
{
    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.settings.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.settings[section] count];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return @"Validation Events";
    }
    if (section == 1) {
        return @"Video Playing Events";
    }
return @"";
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section
{
    if (section == 0) {
        return @"If one of the above events is selected the Video Playing phase won't be reached";
    }

    if (section == 1) {
        return @"Selecting a Video Playing Event sets the Validation Event to Success - Video Available";
    }
    return @"";
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kCellIdentifier];

    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kCellIdentifier];
    }

    SPMockAdapterSetting *setting = self.settings[indexPath.section][indexPath.row];
    cell.textLabel.text = setting.caption;
    
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    SPMockAdapterSetting *setting = self.settings[indexPath.section][indexPath.row];

    NSLog(@"%s selected setting: %@", __PRETTY_FUNCTION__, setting);

    self.mockAdapter.validationBehavior = setting.validationBehavior;
    self.mockAdapter.validationResultToTrigger = setting.validationResult;
    self.mockAdapter.playingBehavior = setting.playingBehavior;
    self.mockAdapter.videoEventToTrigger = setting.finalVideoEvent;

    [self.presentingViewController dismissViewControllerAnimated:YES completion:nil];
}

- (NSArray *)settings
{
    Class s = [SPMockAdapterSetting class];
    if (!_settings) {
        NSArray *validationSettings =
        @[[s settingWithCaption:@"Timeout (SP SDK side)"
             validationBehavior:SPMockValidationBehaviorTimeOut
               validationResult:0],
          [s settingWithCaption:@"Timeout (3rd party SDK side)" validationResult:SPTPNValidationTimeout],
          [s settingWithCaption:@"No video available" validationResult:SPTPNValidationNoVideoAvailable],
          [s settingWithCaption:@"Network error" validationResult:SPTPNValidationNetworkError],
          [s settingWithCaption:@"Disk error" validationResult:SPTPNValidationDiskError],
          [s settingWithCaption:@"Other error" validationResult:SPTPNValidationError]];

        NSArray *playingSettings =
        @[
          // TODO
//          [s settingWithCaption:@"Timeout (SP SDK side)"
//                playingBehavior:SPMockPlayingBehaviorTimeOut
//                finalVideoEvent:0],

          [s settingWithCaption:@"Timeout (3rd party SDK side)"
                playingBehavior:SPMockPlayingBehaviorTriggerResultOnce
                finalVideoEvent:SPTPNVideoEventTimeout],

//          [s settingWithCaption:@"Started + Timeout (SP SDK side)"
//                playingBehavior:SPMockPlayingBehaviorTriggerStartAndTimeOut
//                finalVideoEvent:0],

          [s settingWithCaption:@"Started + Timeout (3rd party SDK)"
                playingBehavior:SPMockPlayingBehaviorTriggerStartAndFinalResult
                finalVideoEvent:SPTPNVideoEventTimeout],

          [s settingWithCaption:@"Started + Aborted"
                playingBehavior:SPMockPlayingBehaviorTriggerStartAndFinalResult
                finalVideoEvent:SPTPNVideoEventAborted],

          [s settingWithCaption:@"Started + Finished + Closed"
                playingBehavior:SPMockPlayingBehaviorTriggerStartAndFinalResult
                finalVideoEvent:SPTPNVideoEventFinished],

          [s settingWithCaption:@"No video on play"
                playingBehavior:SPMockPlayingBehaviorTriggerResultOnce
                finalVideoEvent:SPTPNVideoEventNoVideo],

          [s settingWithCaption:@"Other error"
                playingBehavior:SPMockPlayingBehaviorTriggerResultOnce
                finalVideoEvent:SPTPNVideoEventError],

          [s settingWithCaption:@"Started + other error"
                playingBehavior:SPMockPlayingBehaviorTriggerStartAndFinalResult
                finalVideoEvent:SPTPNVideoEventError]
          ];

        self.settings = @[validationSettings, playingSettings];
    }

    return _settings;
}


@end

@interface SPMockAdapterSetting()

@property (strong) NSString *caption;

@property (assign) SPMockValidationBehavior validationBehavior;
@property (assign) SPTPNValidationResult validationResult;

@property (assign) SPMockPlayingBehavior playingBehavior;
@property (assign) SPTPNVideoEvent finalVideoEvent;

@end

@implementation SPMockAdapterSetting

- (id)initWithCaption:(NSString *)caption
   validationBehavior:(SPMockValidationBehavior)validationBehavior
     validationResult:(SPTPNValidationResult)validationResult
{
    self = [super init];

    if (self) {
        self.caption = caption;
        self.validationBehavior = validationBehavior;
        self.validationResult = validationResult;
    }
    return self;
}

- (id)initWithCaption:(NSString *)caption
      playingBehavior:(SPMockPlayingBehavior)playingBehavior
      finalVideoEvent:(SPTPNVideoEvent)finalVideoEvent
{
    self = [self initWithCaption:caption
              validationBehavior:SPMockValidationBehaviorTriggerResult
                validationResult:SPTPNValidationSuccess];

    if (self) {
        self.playingBehavior = playingBehavior;
        self.finalVideoEvent = finalVideoEvent;
    }

    return self;
}

- (NSString *)description
{
    return [NSString stringWithFormat:@"%@\n{\tcaption:\"%@\"\n\t"
            "validationBehavior: %@\n\t"
            "validationResult: %@\n\t"
            "playingBehavior: %@\n\t"
            "finalVideoEvent: %@\n"
            "}", [super description], self.caption,
            validationBehaviorToString(self.validationBehavior),
            SPTPNValidationResultToString(self.validationResult),
            playingBehaviorToString(self.playingBehavior),
            SPTPNVideoEventToString(self.finalVideoEvent)];
}

+ (instancetype)settingWithCaption:(NSString *)caption
                validationBehavior:(SPMockValidationBehavior)validationBehavior
                  validationResult:(SPTPNValidationResult)validationResult
{
    id s = [[self alloc] initWithCaption:caption
                      validationBehavior:validationBehavior
                        validationResult:validationResult];
    return s;
}

+ (instancetype)settingWithCaption:(NSString *)caption
                  validationResult:(SPTPNValidationResult)validationResult
{
    return [self settingWithCaption:caption
                 validationBehavior:SPMockValidationBehaviorTriggerResult
                   validationResult:validationResult];
}

+ (instancetype)settingWithCaption:(NSString *)caption
                   playingBehavior:(SPMockPlayingBehavior)playingBehavior
                   finalVideoEvent:(SPTPNVideoEvent)finalVideoEvent
{
    id s = [[self alloc] initWithCaption:caption
                         playingBehavior:playingBehavior
                         finalVideoEvent:finalVideoEvent];

    return s;
}

@end

static NSString *validationBehaviorToString(SPMockValidationBehavior validationBehavior)
{
    switch (validationBehavior) {
        case SPMockValidationBehaviorTimeOut:
            return @"SPMockValidationBehaviorTimeOut";
        case SPMockValidationBehaviorTriggerResult:
            return @"SPMockValidationBehaviorTriggerResult";
    }
}

static NSString *playingBehaviorToString(SPMockPlayingBehavior playingBehavior)
{
    switch (playingBehavior) {
        case SPMockPlayingBehaviorTimeOut:
            return @"SPMockPlayingBehaviorTimeOut";
        case SPMockPlayingBehaviorTriggerResultOnce:
            return @"SPMockPlayingBehaviorTriggerResultOnce";
        case SPMockPlayingBehaviorTriggerStartAndTimeOut:
            return @"SPMockPlayingBehaviorTriggerStartAndTimeOut";
        case SPMockPlayingBehaviorTriggerStartAndFinalResult:
            return @"SPMockPlayingBehaviorTriggerStartAndFinalResult";
    }
}